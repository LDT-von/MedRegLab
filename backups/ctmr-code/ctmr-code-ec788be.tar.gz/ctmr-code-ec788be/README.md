# CT-MR 跨模态配准 — 方案二实验脚手架

> 赛事：跨模态图像配准算法挑战赛（CT 固定 / MR 浮动，腹部）
> 主线方案：**先翻译、后配准**（CycleGAN MR→CT + VoxelMorph 式配准）
> 评分：主指标 **DSC**（肝/脾/肾均值），次指标 **DSC30**（最差 30% 病例均值）

本仓库是一个**可运行、可扩展、带实验记录**的工程骨架。没有 GPU 也能先跑通：
`python -m ctmr.selftest`（7 项自检）与 `bash scripts/smoke_test.sh`（合成数据端到端）。

---

## 目录结构

```
CT_MR医学/
├── docs/                     # 文档 + 实验记录（每个方案的分数自动追加到这里）
│   ├── README.md             # 文档索引
│   ├── CONTEXT.md            # 赛题与方案上下文
│   ├── EXPERIMENTS.md        # 实验记录表
│   ├── 跨模态图像配准算法挑战赛.{pdf,md}
│   └── 跨模态图像配准算法创新挑战赛测试集提交规范与评分说明.{pdf,md}
├── configs/
│   ├── base.yaml              # 公共配置（路径/设备/数据）
│   ├── cyclegan.yaml          # 阶段一：翻译
│   ├── registration.yaml      # 阶段二：配准
│   └── smoke.yaml             # 冒烟测试覆盖
├── ctmr/
│   ├── data/                  # IO、预处理、数据准备、数据集
│   ├── models/                # CycleGAN、VoxelMorph、空间变换
│   ├── losses/                # 对抗/循环一致性、NCC/平滑/Dice
│   ├── train/                 # 两个训练入口
│   ├── inference/             # 预测位移场
│   ├── eval/                  # Dice / DSC30
│   ├── utils/                 # 配置、日志、实验记录、位移场、打包
│   ├── selftest.py            # CPU 自检
│   └── smoke_data.py          # 合成数据生成
├── scripts/                   # 一键脚本
├── experiments/               # 运行产物（日志/权重/预测，gitignore）
├── requirements.txt
└── README.md
```

---

## 0. 环境

### 本地 macOS（CPU 冒烟）

```bash
bash scripts/setup_env.sh
```

脚本会用 `python3.12` 建 `.venv`，并按 `PIP_INDEX_URL`（默认清华源）安装依赖，最后跑自检。
若本机网络直连 PyPI 正常，可 `PIP_INDEX_URL=https://pypi.org/simple bash scripts/setup_env.sh`。

### GPU 机器

先装匹配 CUDA 的 torch（示例，按实际 CUDA 版本调整）：

```bash
pip install torch torchvision --index-url https://download.pytorch.org/whl/cu121
pip install -r requirements.txt
python -m ctmr.selftest
```

代码通过 `runtime.device: auto` 自动选择 CUDA；`runtime.amp: true` 在 CUDA 上启用混合精度。

---

## 1. 数据布局

### 原始数据（`data/`）

```
data/
├── paired/001/{ct,mr,label_ct,label_mr}.nii.gz     # 24 例配对
├── paired/...
├── unpaired/ct/*.nii.gz                            # 约 50 例
├── unpaired/mr/*.nii.gz                            # 约 40 例
└── test/025/{ct,mr}.nii.gz                         # 8 例测试（025–032）
```

文件名可容忍小差异（`find_image` / `find_label` 会兜底匹配）。

### 预处理后（`data_prepared/`）

```bash
python -m ctmr.data.prepare --config configs/base.yaml --mode all
```

- 配对：MR 与 MR 标签重采样到 **CT 网格**（这是形变场能直接作用于原始 CT 的前提）；
- 未配对：CT/MR 统一重采样到一个目标网格（默认取首例 CT，可在 `base.yaml` 显式指定）。

> 原始数据下载：百度网盘 `https://pan.baidu.com/s/1j-COKoMeQs4Xgcf1WV-11Q?pwd=h76d`（提取码 `h76d`）。

---

## 2. 不需要真实数据的冒烟测试

```bash
bash scripts/smoke_test.sh
```

会依次执行：合成数据 → 预处理 → CycleGAN 2 步 → 配准 2 步 → 推理 → 评分 → 打包，
并在 `experiments_smoke/` 下留下日志与 `submission.zip`。用于确认环境与代码路径正常。

---

## 3. 真实数据流程（方案二）

### 3.1 训练翻译网络（MR → CT）

```bash
python -m ctmr.train.train_cyclegan \
  --config configs/base.yaml configs/cyclegan.yaml
```

产物：`experiments/runs/<run_id>/checkpoints/latest.pt`（其中 `g_ab` 即 MR→CT 生成器）。

### 3.2 打开翻译开关并训练配准

编辑 `configs/registration.yaml`：

```yaml
translation:
  enabled: true
  ckpt: experiments/runs/<上一步run_id>/checkpoints/latest.pt
```

然后：

```bash
python -m ctmr.train.train_registration \
  --config configs/base.yaml configs/registration.yaml
```

### 3.3 推理测试集

```bash
REG_CKPT=experiments/runs/<reg_run_id>/checkpoints/latest.pt \
TRANS_CKPT=experiments/runs/<cg_run_id>/checkpoints/latest.pt \
OUT=experiments/outputs/submit_v1 \
bash scripts/predict.sh
```

输出 `OUT/<case_id>/displacement_field.nii.gz`（float32、毫米、几何与 `ct.nii` 一致）。

### 3.4 在验证集上评分

```bash
PRED_ROOT=experiments/outputs/val_v1 \
DATA_ROOT=data_prepared/paired \
SCHEME=cyclegan_v1 \
bash scripts/evaluate.sh
```

加 `RECORD=1` 可把 DSC / DSC30 自动写入 `docs/`。

### 3.5 打包提交

```bash
PRED_ROOT=experiments/outputs/submit_v1 \
OUT=submission.zip \
DATA_ROOT=data/test \
CASES="025 026 027 028 029 030 031 032" \
bash scripts/package_submission.sh
```

生成 `submission/025/displacement_field.nii.gz ...` 结构并做几何/NaN 自检。

---

## 4. 方案二数据流

```
MR ──► G_AB(CycleGAN) ──► 合成 CT ──┐
                                    ├──► VoxelMorph ──► flow ──► 位移场(mm) ──► 提交
CT ─────────────────────────────────┘
```

- 网络输入通道：`[CT, 合成CT]`；
- 输出 `flow`：CT 体素单位、通道 `(x, y, z)`，语义 `p_mr = p_ct + flow`；
- 最终通过 `make_displacement_field` + `canonicalize_field` 转成物理毫米位移场。

---

## 5. 实验记录机制

每次评估加 `--record`，会同时写入：

- `docs/experiments.csv`：机器可读（方案、run_id、DSC、DSC30、备注、配置、日志、权重路径）；
- `docs/EXPERIMENTS.md`：人读的 Markdown 表格。

也可以手动追加结论：

```python
from ctmr.utils.tracker import ExperimentTracker
ExperimentTracker("docs").note("2026-10-23：CycleGAN 100 epoch，验证集 DSC 0.81")
```

---

## 6. 提交格式要点（摘自赛题文档二）

| 项 | 要求 |
|---|---|
| 结构 | `submission/<case>/displacement_field.nii.gz`，每目录仅一个文件 |
| 类型 | float32（推荐）或 float64 |
| 单位 | 物理毫米，相对位移 `p_mr = p_ct + D(p_ct)` |
| 几何 | size/spacing/origin/direction 与原始 `ct.nii` 完全一致 |
| 生成 | 推荐 `sitk.TransformToDisplacementField`（本仓库已封装） |

> 注意：SimpleITK 的 `DisplacementFieldTransform` 只接受 **vector float64**，
> 本仓库在 `ctmr/utils/field.py` 里自动 Cast，最终仍输出 float32。

---

## 7. 已知限制 / 下一步

- `MIND` 描述子、`DSC30` 困难样本重加权、测试时增强（TTA）尚未实现；
- 2D 逐切片翻译在整幅体积上较慢，GPU 上建议**离线预生成合成 CT** 再训练配准；
- `direction` 非恒等时已做矩阵换算，但建议用真实数据再验证一次；
- 未做配准折叠加权/多模型集成，可作为后续提升 DSC30 的抓手。

---

## 8. 常用命令速查

```bash
python -m ctmr.selftest                              # 自检
python -m ctmr.smoke_data --out data_smoke           # 合成数据
python -m ctmr.data.prepare --config configs/base.yaml
python -m ctmr.train.train_cyclegan  --config configs/base.yaml configs/cyclegan.yaml
python -m ctmr.train.train_registration --config configs/base.yaml configs/registration.yaml
python -m ctmr.inference.predict --config configs/base.yaml configs/registration.yaml --registration-ckpt <path>
python -m ctmr.eval.evaluate --pred-root <dir> --data-root data_prepared/paired --record
python -m ctmr.utils.submit --pred-root <dir> --out submission.zip --data-root data/test
```
