#!/usr/bin/env bash
# 打包 submission.zip 并自检。
# 必需：PRED_ROOT=<预测目录> OUT=<zip 路径>
# 可选：DATA_ROOT=<测试集目录> CASES="025 026 ..."
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
PY="$ROOT/.venv/bin/python"
[ -x "$PY" ] || PY=python3

: "${PRED_ROOT:?请设置 PRED_ROOT=<预测目录>}"
: "${OUT:?请设置 OUT=<submission.zip>}"

ARGS=(--pred-root "$PRED_ROOT" --out "$OUT")
[ -n "${DATA_ROOT:-}" ] && ARGS+=(--data-root "$DATA_ROOT")
[ -n "${CASES:-}" ] && ARGS+=(--cases ${CASES})

exec "$PY" -m ctmr.utils.submit "${ARGS[@]}" "$@"
