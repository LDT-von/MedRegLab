#!/usr/bin/env bash
# 推理测试集，生成位移场。
# 必需：REG_CKPT=<配准权重>
# 可选：TRANS_CKPT=<CycleGAN 权重> TEST_ROOT=<测试集目录> OUT=<输出目录> CASES="025 026"
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
PY="$ROOT/.venv/bin/python"
[ -x "$PY" ] || PY=python3

: "${REG_CKPT:?请设置 REG_CKPT=<配准权重 latest.pt>}"

ARGS=(--config configs/base.yaml configs/registration.yaml --registration-ckpt "$REG_CKPT")
[ -n "${TRANS_CKPT:-}" ] && ARGS+=(--translation-ckpt "$TRANS_CKPT")
[ -n "${TEST_ROOT:-}" ] && ARGS+=(--test-root "$TEST_ROOT")
[ -n "${OUT:-}" ] && ARGS+=(--out "$OUT")
[ -n "${CASES:-}" ] && ARGS+=(--cases ${CASES})

exec "$PY" -m ctmr.inference.predict "${ARGS[@]}" "$@"
