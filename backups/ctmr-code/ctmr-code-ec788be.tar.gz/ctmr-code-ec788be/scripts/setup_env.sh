#!/usr/bin/env bash
# 创建虚拟环境并安装依赖，最后跑 CPU 自检。
# 可选环境变量：
#   PYTHON_BIN  解释器（默认 python3.12，找不到则回退 python3）
#   PIP_INDEX_URL  包索引（默认清华源）
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

PYTHON_BIN="${PYTHON_BIN:-python3.12}"
if ! command -v "$PYTHON_BIN" >/dev/null 2>&1; then
  PYTHON_BIN="python3"
fi
INDEX_URL="${PIP_INDEX_URL:-https://pypi.tuna.tsinghua.edu.cn/simple}"

if [ ! -x "$ROOT/.venv/bin/python" ]; then
  echo "[1/3] 创建虚拟环境 .venv（python: $PYTHON_BIN）"
  if command -v uv >/dev/null 2>&1; then
    UV_CACHE_DIR="${UV_CACHE_DIR:-$ROOT/.uv-cache}" uv venv --python "$PYTHON_BIN" "$ROOT/.venv"
  else
    "$PYTHON_BIN" -m venv "$ROOT/.venv"
  fi
else
  echo "[1/3] 复用已有 .venv"
fi

echo "[2/3] 安装依赖（index: $INDEX_URL）"
if command -v uv >/dev/null 2>&1; then
  UV_CACHE_DIR="${UV_CACHE_DIR:-$ROOT/.uv-cache}" uv pip install \
    --python "$ROOT/.venv/bin/python" --index-url "$INDEX_URL" -r requirements.txt
else
  "$ROOT/.venv/bin/python" -m pip install -i "$INDEX_URL" -r requirements.txt
fi

echo "[3/3] 自检"
"$ROOT/.venv/bin/python" -m ctmr.selftest
