#!/usr/bin/env bash
# 评估位移场，计算 DSC / DSC30。
# 必需：PRED_ROOT=<预测目录>
# 可选：DATA_ROOT（默认 data_prepared/paired） SCHEME RUN_ID NOTES RECORD=1
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
PY="$ROOT/.venv/bin/python"
[ -x "$PY" ] || PY=python3

: "${PRED_ROOT:?请设置 PRED_ROOT=<预测目录>}"

ARGS=(--pred-root "$PRED_ROOT" --data-root "${DATA_ROOT:-data_prepared/paired}")
[ -n "${SCHEME:-}" ] && ARGS+=(--scheme "$SCHEME")
[ -n "${RUN_ID:-}" ] && ARGS+=(--run-id "$RUN_ID")
[ -n "${NOTES:-}" ] && ARGS+=(--notes "$NOTES")
[ -n "${OUTPUT_CSV:-}" ] && ARGS+=(--output-csv "$OUTPUT_CSV")
[ -n "${RECORD:-}" ] && ARGS+=(--record)

exec "$PY" -m ctmr.eval.evaluate "${ARGS[@]}" "$@"
