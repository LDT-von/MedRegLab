#!/usr/bin/env bash
# 训练配准网络（CT vs 合成 CT）。
# 记得先把 configs/registration.yaml 的 translation.enabled 改成 true 并填 ckpt。
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
PY="$ROOT/.venv/bin/python"
[ -x "$PY" ] || PY=python3

exec "$PY" -m ctmr.train.train_registration \
  --config configs/base.yaml configs/registration.yaml "$@"
