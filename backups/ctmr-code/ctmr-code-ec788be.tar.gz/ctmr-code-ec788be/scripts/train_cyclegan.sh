#!/usr/bin/env bash
# 训练 CycleGAN（MR <-> CT 未配对翻译）。
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
PY="$ROOT/.venv/bin/python"
[ -x "$PY" ] || PY=python3

exec "$PY" -m ctmr.train.train_cyclegan \
  --config configs/base.yaml configs/cyclegan.yaml "$@"
