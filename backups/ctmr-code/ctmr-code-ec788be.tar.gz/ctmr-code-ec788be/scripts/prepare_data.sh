#!/usr/bin/env bash
# 数据预处理：把原始数据整理成统一几何。
# 用法：bash scripts/prepare_data.sh [--mode paired|unpaired|all]
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
PY="$ROOT/.venv/bin/python"
[ -x "$PY" ] || PY=python3

exec "$PY" -m ctmr.data.prepare --config configs/base.yaml "$@"
