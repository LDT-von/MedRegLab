#!/usr/bin/env bash
# 端到端冒烟测试（不需要真实数据、不需要 GPU）：
#   合成数据 -> 预处理 -> CycleGAN 2 步 -> 配准 2 步 -> 推理 -> 评分 -> 打包
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
PY="$ROOT/.venv/bin/python"
[ -x "$PY" ] || { echo "未找到 .venv，请先运行 bash scripts/setup_env.sh"; exit 1; }

echo "==> 1/7 生成合成数据"
"$PY" -m ctmr.smoke_data --out data_smoke

echo "==> 2/7 预处理"
"$PY" -m ctmr.data.prepare --config configs/base.yaml \
  --override paths.data_root=data_smoke paths.prepared_root=data_smoke_prepared

echo "==> 3/7 训练 CycleGAN（2 步）"
"$PY" -m ctmr.train.train_cyclegan --config configs/base.yaml configs/cyclegan.yaml configs/smoke.yaml

echo "==> 4/7 训练配准网络（2 步）"
"$PY" -m ctmr.train.train_registration --config configs/base.yaml configs/registration.yaml configs/smoke.yaml

REG_CKPT="$(ls -dt experiments_smoke/runs/smoke_registration_*/checkpoints/latest.pt | head -1)"
echo "    配准权重: $REG_CKPT"

echo "==> 5/7 推理（测试集 025/026）"
"$PY" -m ctmr.inference.predict --config configs/base.yaml configs/registration.yaml configs/smoke.yaml \
  --registration-ckpt "$REG_CKPT" --out experiments_smoke/predict_test

echo "==> 6/7 推理（配对集 001-003）+ 评分"
"$PY" -m ctmr.inference.predict --config configs/base.yaml configs/registration.yaml configs/smoke.yaml \
  --test-root data_smoke/paired --registration-ckpt "$REG_CKPT" --out experiments_smoke/predict_paired
"$PY" -m ctmr.eval.evaluate --pred-root experiments_smoke/predict_paired --data-root data_smoke/paired \
  --doc-dir experiments_smoke/doc_test --scheme smoke --record

echo "==> 7/7 打包提交"
"$PY" -m ctmr.utils.submit --pred-root experiments_smoke/predict_test --out experiments_smoke/submission.zip \
  --data-root data_smoke/test --cases 025 026

echo "冒烟测试通过。产物在 experiments_smoke/"
