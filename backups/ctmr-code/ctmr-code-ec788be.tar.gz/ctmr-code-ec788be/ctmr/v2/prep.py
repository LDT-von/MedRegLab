"""E0：构建分割训练缓存 + split_v2.json + 配对病例世界坐标偏移分析。

用法::

    python -m ctmr.v2.prep --out /home/ubuntu/ctmr/cache --spacing 1.5 1.5 3.0
"""
from __future__ import annotations

import argparse
import json
from multiprocessing import Pool
from pathlib import Path

import numpy as np
import SimpleITK as sitk

from ctmr.v2.data import (
    ORGANS,
    canonical_reference,
    harmonize,
    normalize,
    organ_volumes_ml,
    registry,
    resample,
    save_split,
)


def _build(args):
    item, out_dir, spacing = args
    out = out_dir / f"{item.uid}.npz"
    img = sitk.ReadImage(item.image)
    ref = canonical_reference(img, spacing)
    arr = sitk.GetArrayFromImage(resample(img, ref, is_label=False))
    rec = {"uid": item.uid, "group": item.group, "fold": item.fold, "shape": list(arr.shape)}
    lab_arr = None
    if item.label:
        lab = sitk.ReadImage(item.label)
        native = harmonize(sitk.GetArrayFromImage(lab), item.group)
        rec["vol_ml"] = organ_volumes_ml(native, lab.GetSpacing())
        lab_img = sitk.GetImageFromArray(native)
        lab_img.CopyInformation(lab)
        lab_arr = sitk.GetArrayFromImage(resample(lab_img, ref, is_label=True)).astype(np.uint8)
        # 世界坐标质心（mm），用于 CT/MR 偏移分析
        rec["centroid_mm"] = {}
        for k, name in enumerate(ORGANS, start=1):
            idx = np.argwhere(native == k)
            if len(idx):
                c = idx.mean(0)[::-1]  # (z,y,x) -> (x,y,z)
                rec["centroid_mm"][name] = list(lab.TransformContinuousIndexToPhysicalPoint(c.tolist()))
    np.savez_compressed(
        out,
        img=normalize(arr, item.modality).astype(np.float16),
        lab=lab_arr if lab_arr is not None else np.zeros(0, np.uint8),
        origin=np.array(ref.GetOrigin()),
        spacing=np.array(spacing),
    )
    return rec


def _flags(rec) -> list[str]:
    v = rec.get("vol_ml")
    if v is None:
        return []
    if sum(v.values()) == 0:
        return ["EMPTY"]
    out = []
    if v["liver"] < max(v["spleen"], v["kidney"]):
        out.append("LIVER_NOT_LARGEST")
    out += [f"NO_{o.upper()}" for o in ORGANS if v[o] == 0]
    return out


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="/home/ubuntu/ctmr/cache")
    ap.add_argument("--spacing", type=float, nargs=3, default=(1.5, 1.5, 3.0))
    ap.add_argument("--workers", type=int, default=8)
    args = ap.parse_args()

    spacing = tuple(args.spacing)
    out_dir = Path(args.out) / "seg_{}x{}x{}".format(*spacing)
    out_dir.mkdir(parents=True, exist_ok=True)
    items = registry()
    save_split(items, Path(args.out) / "split_v2.json")

    with Pool(args.workers) as pool:
        recs = pool.map(_build, [(it, out_dir, spacing) for it in items], chunksize=1)

    by_uid = {r["uid"]: r for r in recs}
    for r in recs:
        r["flags"] = _flags(r)
    (out_dir / "meta.json").write_text(json.dumps(recs, indent=1))

    print(f"{len(recs)} items -> {out_dir}")
    print("\n== label check (harmonized, native volumes ml)")
    for r in recs:
        if "vol_ml" in r:
            v = r["vol_ml"]
            mark = " ".join(r["flags"])
            print(f"  {r['uid']:16s} g={r['group']:7s} f={r['fold']:2d} "
                  f"liver={v['liver']:6.0f} spleen={v['spleen']:5.0f} kidney={v['kidney']:5.0f} {mark}")

    print("\n== paired CT↔MR world offset (MR centroid − CT centroid, mm)")
    for case in sorted({r['uid'][:3] for r in recs if r['uid'][:3].isdigit()}):
        ct, mr = by_uid.get(f"{case}_ct"), by_uid.get(f"{case}_mr")
        if not ct or not mr or not ct.get("centroid_mm") or not mr.get("centroid_mm"):
            continue
        parts = []
        for o in ORGANS:
            if o in ct["centroid_mm"] and o in mr["centroid_mm"]:
                d = np.subtract(mr["centroid_mm"][o], ct["centroid_mm"][o])
                parts.append(f"{o}=({d[0]:+6.0f},{d[1]:+6.0f},{d[2]:+6.0f}) |{np.linalg.norm(d):5.0f}|")
        print(f"  {case} {ct['group']:7s} " + "  ".join(parts))


if __name__ == "__main__":
    main()
