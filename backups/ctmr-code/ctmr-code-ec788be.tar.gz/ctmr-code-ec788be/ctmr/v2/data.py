"""v2 数据层：病例登记、标签语义统一、分折、规范网格重采样。

标签语义（2026-10-28 体检，见 docs/实验计划_v2.md F1）::

    tcia  001–008       1=肝 2=脾 3/4=左右肾
    pseudo 009–016      1=双肾 2=脾 3=肝      （伪 MR，零形变对）
    inhouse 017–024     1=双肾 2=脾 3=肝      （与测试 025–032 同源）
    bcv   extra CT      1=肝 2=脾 3/4=左右肾  （Learn2Reg 版）
    chaos extra MR      1=肝 2=脾 3/4=左右肾  （Learn2Reg 版）

统一后：0 背景 / 1 肝 / 2 脾 / 3 肾。官方评分用原始编号分组（CT/MR 同口径），
统一语义只用于训练分割与按器官加权。
"""
from __future__ import annotations

import json
import math
from dataclasses import asdict, dataclass
from pathlib import Path

import numpy as np
import SimpleITK as sitk

from ctmr.data.datasets import find_image, find_label

DATA_ROOT = Path("/home/ubuntu/ctmr/Datasets")
N_FOLDS = 4
ORGANS = ("liver", "spleen", "kidney")

HARMONIZE = {
    "tcia": {1: 1, 2: 2, 3: 3, 4: 3},
    "pseudo": {1: 3, 2: 2, 3: 1},
    "inhouse": {1: 3, 2: 2, 3: 1},
    "test": {1: 3, 2: 2, 3: 1},
    "bcv": {1: 1, 2: 2, 3: 3, 4: 3},
    "chaos": {1: 1, 2: 2, 3: 3, 4: 3},
}
# 原 zip 内即损坏（gzip CRC 错误）
BAD_FILES = {"img0036_bcv_CT.nii.gz"}


def paired_group(case_id: str) -> str:
    n = int(case_id)
    if n <= 8:
        return "tcia"
    if n <= 16:
        return "pseudo"
    if n <= 24:
        return "inhouse"
    return "test"


@dataclass
class Item:
    """一个单模态带标注（或测试无标注）样本。"""

    uid: str  # 001_ct / 017_mr / bcv0001_ct / chaos0003_mr
    case: str  # 001 / bcv0001
    modality: str  # ct / mr
    group: str
    image: str
    label: str | None
    fold: int  # -1 = 测试集


def _fold(index: int) -> int:
    return index % N_FOLDS


def registry(root: Path = DATA_ROOT) -> list[Item]:
    """全部样本。配对病例 CT/MR 同折，保证验证病例两侧分割模型都没见过它。"""
    items: list[Item] = []
    for split in ("train", "test"):
        case_dirs = sorted(p for p in (root / split).iterdir() if p.is_dir())
        by_group: dict[str, list[Path]] = {}
        for d in case_dirs:
            by_group.setdefault(paired_group(d.name), []).append(d)
        for group, dirs in by_group.items():
            for i, d in enumerate(dirs):
                fold = -1 if group == "test" else _fold(i)
                for mod in ("ct", "mr"):
                    img = find_image(d, mod)
                    lab = find_label(d, mod)
                    items.append(
                        Item(f"{d.name}_{mod}", d.name, mod, group, str(img), str(lab) if lab else None, fold)
                    )
    for group, sub, mod in (("bcv", "extra/CT/ct", "ct"), ("chaos", "extra/MR/mr", "mr")):
        imgs = sorted(p for p in (root / sub).glob("img*.nii*") if p.name not in BAD_FILES)
        for i, img in enumerate(imgs):
            num = img.name.split("_")[0][3:]
            lab = img.with_name(img.name.replace("img", "seg", 1))
            case = f"{group}{num}"
            items.append(
                Item(f"{case}_{mod}", case, mod, group, str(img), str(lab) if lab.exists() else None, _fold(i))
            )
    return items


def harmonize(label: np.ndarray, group: str) -> np.ndarray:
    out = np.zeros_like(label, dtype=np.uint8)
    for src, dst in HARMONIZE[group].items():
        out[label == src] = dst
    return out


def canonical_reference(image: sitk.Image, spacing: tuple[float, float, float]) -> sitk.Image:
    """覆盖原图物理范围、方向为单位阵（LPS 对齐）的网格。"""
    size = image.GetSize()
    corners = [
        image.TransformContinuousIndexToPhysicalPoint((i, j, k))
        for i in (-0.5, size[0] - 0.5)
        for j in (-0.5, size[1] - 0.5)
        for k in (-0.5, size[2] - 0.5)
    ]
    lo = np.min(corners, axis=0)
    hi = np.max(corners, axis=0)
    new_size = [max(1, int(math.ceil((hi[a] - lo[a]) / spacing[a]))) for a in range(3)]
    origin = [lo[a] + 0.5 * spacing[a] for a in range(3)]
    ref = sitk.Image(new_size, sitk.sitkFloat32)
    ref.SetSpacing(spacing)
    ref.SetOrigin(origin)
    ref.SetDirection((1, 0, 0, 0, 1, 0, 0, 0, 1))
    return ref


def resample(image: sitk.Image, ref: sitk.Image, is_label: bool, default: float = 0.0) -> sitk.Image:
    interp = sitk.sitkNearestNeighbor if is_label else sitk.sitkLinear
    pixel = image.GetPixelID() if is_label else sitk.sitkFloat32
    return sitk.Resample(image, ref, sitk.Transform(), interp, default, pixel)


def normalize(array: np.ndarray, modality: str) -> np.ndarray:
    """逐图归一化到约 [0, 1]，不用任何跨病例统计。"""
    a = array.astype(np.float32)
    if modality == "ct":
        return np.clip((a + 200.0) / 500.0, -0.2, 1.2)  # 腹窗 [-200, 300] HU
    lo, hi = np.percentile(a[a > 0] if (a > 0).any() else a, [0.5, 99.5])
    return np.clip((a - lo) / max(hi - lo, 1e-6), 0.0, 1.2)


def organ_volumes_ml(label: np.ndarray, spacing: tuple[float, ...]) -> dict[str, float]:
    vox = float(np.prod(spacing)) / 1000.0
    return {name: float((label == k).sum()) * vox for k, name in enumerate(ORGANS, start=1)}


def save_split(items: list[Item], path: Path) -> None:
    path.write_text(json.dumps([asdict(it) for it in items], indent=1, ensure_ascii=False))


def load_split(path: Path) -> list[Item]:
    return [Item(**d) for d in json.loads(path.read_text())]
