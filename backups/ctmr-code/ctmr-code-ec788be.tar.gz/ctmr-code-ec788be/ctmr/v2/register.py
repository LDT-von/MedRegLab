"""E1：ConvexAdam 式逐例配准（无训练）+ 官方口径评分。

流程（全部在世界坐标 mm、LPS 下）::

    ① 平移穷举：8mm MIND-SSC，z ±900 / xy ±128 mm（017–024 的 CT/MR 世界偏移 220–750mm）
    ② 平移细化 + 仿射：4mm MIND-SSD，Adam
    ③ 凸离散搜索：2mm MIND 池化到控制网格，代价体 + 渐进平滑耦合
    ④ Adam 实例优化：稠密位移 + 扩散正则
    ⑤ 位移场 D(x) = A(x + u(x)) − x  →  CT 原生网格（TransformToDisplacementField）

评分与官方一致：原生 MR 标签经位移场最近邻变换到原生 CT 网格，器官 Dice，空器官记 1.0。

用法::

    python -m ctmr.v2.register run --cases 002-008 017-024 --out ~/ctmr/runs/e1_v1 --gpu 0
"""
from __future__ import annotations

import argparse
import csv
import json
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path

import numpy as np
import SimpleITK as sitk
import torch
import torch.nn.functional as F

from ctmr.data.datasets import find_image, find_label
from ctmr.eval.metrics import dice_for_organ, dsc30
from ctmr.utils.field import validate_field
from ctmr.v2.data import DATA_ROOT, ORGANS, canonical_reference, harmonize, normalize, paired_group, resample


@dataclass
class Params:
    # ① 平移穷举
    search_sp: float = 8.0
    search_z: float = 900.0
    search_xy: float = 128.0
    search_step: float = 16.0
    min_overlap: float = 0.5
    # ①' 质心初值的局部图像驱动精化（init=seg 时启用）
    refine: bool = False
    refine_radius: float = 24.0  # mm，搜索窗口半径
    refine_step: float = 8.0  # mm，搜索步长
    # ② 仿射
    affine_mode: str = "rigid"  # none / rigid / affine
    affine_sp: float = 4.0
    affine_iters: int = 100
    affine_lr: float = 0.002
    # ③ 凸搜索
    reg_sp: float = 2.0
    crop_margin: float = 40.0  # mm
    grid: int = 4  # 控制网格 = reg_sp × grid = 8mm
    radius: int = 6  # ±6 格 = ±48mm
    coeffs: tuple = (0.003, 0.01, 0.03, 0.1, 0.3, 1.0)
    # ④ Adam
    io_iters: int = 100
    io_lr: float = 1.0
    io_lambda: float = 1.0
    affine_penalty: float = 0.0  # >0 时惩罚位移场的仿射分量（不惩罚平移）
    # ④' 凸搜索锚定：Adam 阶段把位移场往凸搜索结果拉（防止自由漂移洗掉粗搜索收益）
    anchor: float = 0.0  # 锚定强度（0 = 关闭；对应 loss 中 anchor*mean((us-u0)²)）
    # ④'' 学习率退火：iter 越大 lr 越小，避免后期大 lr 把好解冲掉
    lr_decay: float = 0.0  # 0 = 恒定 lr；>0 时 lr = io_lr * (1 - it/iters)**lr_decay
    mind_radius: int = 1
    mind_dilation: int = 2
    # 分割引导（E4 用 GT 标签 = 上限；E5 用折外预测概率）
    seg_source: str = "none"  # none / gt / pred
    pred_dir: str = ""  # pred 时：<pred_dir>/<case>_{ct,mr}.nii.gz（3 通道器官概率）
    pred_sigma: float = 0.0  # >0 时对**预测**概率做高斯平滑(mm)，与 GT 的 seg_sigma 对齐
    pred_hard: bool = False  # 预测概率先取 argmax 硬标签再平滑（模拟 GT one-hot 锐度）
    pred_lcc: float = 0.0  # >0 时按器官保留最大连通域（肝/脾保留 1 个，肾保留 2 个），
    #  比例阈值 = 保留分块的最小体积占比；抑制远处散点误检对质心初值/梯度的污染
    init: str = "mind"  # mind = ① 平移穷举；seg = 器官质心
    seg_weight: float = 1.0  # 特征 = MIND(12) ⊕ sqrt(4w)·P(3)：代价 = MIND 均值 + w·P 均值
    seg_sigma: float = 2.0  # GT one-hot 平滑（mm），避免硬边界梯度为 0
    # ④''' 分割匹配项：对概率做**归一化内积**（余弦相似度）匹配。
    # 用 2⟨a,b⟩/(‖a‖²+‖b‖²) 而非标准 Dice 2⟨a,b⟩/(‖a‖₁+‖b‖₁)：
    #   标准 soft-Dice 对**完全相同的软概率**也不等于 1（=sum(a²)/sum(a)<1），
    #   其最优解不是「两张图相等」，存在系统性偏置；平方分母形式（余弦相似度）
    #   在 a==b 时严格取 1，且唯一最优解就是 a==b。
    seg_dice: float = 0.0  # 权重；>0 时 Adam 阶段加 seg_dice * (1 - 匹配相似度)
    seg_dice_sigma: float = 0.0  # >0 时对该项的两端概率都做平滑(mm)，强调器官内部一致性


# ----------------------------------------------------------------------------- volumes
class Volume:
    """规范网格（单位方向）上的张量 + 世界坐标采样。"""

    def __init__(self, image: sitk.Image, spacing: float, modality: str, dev, is_label=False):
        ref = canonical_reference(image, (spacing,) * 3)
        pad = -1024.0 if (modality == "ct" and not is_label) else 0.0  # 界外=空气，不能是 0 HU
        arr = sitk.GetArrayFromImage(resample(image, ref, is_label=is_label, default=pad))
        if not is_label:
            arr = normalize(arr, modality)
        self.t = torch.from_numpy(arr.astype(np.float32))[None, None].to(dev)
        self.origin = torch.tensor(ref.GetOrigin(), dtype=torch.float32, device=dev)
        self.spacing = float(spacing)
        self.size = torch.tensor(ref.GetSize(), dtype=torch.float32, device=dev)  # (x,y,z)

    def world_grid(self) -> torch.Tensor:
        """(D,H,W,3) 体素中心世界坐标（x,y,z）。"""
        sx, sy, sz = (int(v) for v in self.size.tolist())
        zz, yy, xx = torch.meshgrid(
            *(torch.arange(n, device=self.t.device, dtype=torch.float32) for n in (sz, sy, sx)), indexing="ij"
        )
        return torch.stack([xx, yy, zz], -1) * self.spacing + self.origin

    def to_norm(self, pts: torch.Tensor) -> torch.Tensor:
        """世界坐标 -> grid_sample 归一化坐标（align_corners=True）。"""
        idx = (pts - self.origin) / self.spacing
        return 2 * idx / (self.size - 1).clamp(min=1) - 1

    def sample(self, feat: torch.Tensor, pts: torch.Tensor, mode="bilinear") -> torch.Tensor:
        """feat (1,C,D,H,W)；pts (...,3) 世界坐标 -> (1,C,...)，越界为 0。"""
        shp = pts.shape[:-1]
        g = self.to_norm(pts).reshape(1, -1, 1, 1, 3)
        out = F.grid_sample(feat, g, mode=mode, padding_mode="zeros", align_corners=True)
        return out.reshape(1, feat.shape[1], *shp)

    def valid(self, pts: torch.Tensor) -> torch.Tensor:
        n = self.to_norm(pts)
        return (n.abs() <= 1).all(-1)


# ----------------------------------------------------------------------------- MIND-SSC
def mind_ssc(img: torch.Tensor, radius=1, dilation=2) -> torch.Tensor:
    """Heinrich et al. MIND-SSC，12 通道。img: (1,1,D,H,W)。"""
    dev = img.device
    six = torch.tensor([[0, 1, 1], [1, 1, 0], [1, 0, 1], [1, 1, 2], [2, 1, 1], [1, 2, 1]], device=dev)
    dist = ((six[:, None, :] - six[None, :, :]) ** 2).sum(-1)
    x, y = torch.meshgrid(torch.arange(6, device=dev), torch.arange(6, device=dev), indexing="ij")
    mask = (x > y).reshape(-1) & (dist == 2).reshape(-1)
    i1 = six[:, None, :].repeat(1, 6, 1).reshape(-1, 3)[mask]
    i2 = six[None, :, :].repeat(6, 1, 1).reshape(-1, 3)[mask]
    k1 = torch.zeros(12, 1, 3, 3, 3, device=dev)
    k2 = torch.zeros(12, 1, 3, 3, 3, device=dev)
    ar = torch.arange(12, device=dev)
    k1.view(-1)[ar * 27 + i1[:, 0] * 9 + i1[:, 1] * 3 + i1[:, 2]] = 1
    k2.view(-1)[ar * 27 + i2[:, 0] * 9 + i2[:, 1] * 3 + i2[:, 2]] = 1
    p = F.pad(img, (dilation,) * 6, mode="replicate")
    diff = (F.conv3d(p, k1, dilation=dilation) - F.conv3d(p, k2, dilation=dilation)) ** 2
    ssd = F.avg_pool3d(F.pad(diff, (radius,) * 6, mode="replicate"), 2 * radius + 1, stride=1)
    mind = ssd - ssd.min(1, keepdim=True)[0]
    var = mind.mean(1, keepdim=True)
    m = var.mean()
    var = var.clamp(m * 0.001, m * 1000)
    return torch.exp(-mind / var)


# ----------------------------------------------------------------------------- stages
def translation_search(ct: Volume, mr: Volume, p: Params):
    """① 8mm MIND 穷举平移，要求重叠 ≥ min_overlap × min(体部体素)。"""
    fct, fmr = mind_ssc(ct.t), mind_ssc(mr.t)
    pts = ct.world_grid()
    body = ct.t[0, 0] > 0.15  # CT > ~ -125 HU：腹部软组织（避开空气/床）
    mr_body = mr.t > 0.05
    pts_b = pts[body]
    fct_b = fct[0][:, body]  # (12,N)
    need = p.min_overlap * min(int(body.sum()), int(mr_body.sum()))
    zs = torch.arange(-p.search_z, p.search_z + 1e-3, p.search_step, device=pts.device)
    xs = torch.arange(-p.search_xy, p.search_xy + 1e-3, p.search_step, device=pts.device)
    cands = torch.stack(torch.meshgrid(xs, xs, zs, indexing="ij"), -1).reshape(-1, 3)
    best_cost, best_t, costs = float("inf"), torch.zeros(3, device=pts.device), []
    mr_body_f = mr_body.float()
    for chunk in cands.split(64):
        q = pts_b[None] + chunk[:, None, :]  # (K,N,3)
        g = mr.to_norm(q).reshape(1, -1, 1, 1, 3)
        fm = F.grid_sample(fmr, g, align_corners=True, padding_mode="zeros").reshape(12, len(chunk), -1)
        vb = F.grid_sample(mr_body_f, g, align_corners=True, mode="nearest").reshape(len(chunk), -1) > 0.5
        ssd = ((fm - fct_b[:, None, :]) ** 2).mean(0)  # (K,N)
        n = vb.sum(1)
        c = (ssd * vb).sum(1) / n.clamp(min=1)
        c[n < need] = float("inf")
        costs.append(c)
    costs = torch.cat(costs)
    i = int(costs.argmin())
    return cands[i], float(costs[i])


def _linear(M: torch.Tensor, mode: str) -> torch.Tensor:
    eye = torch.eye(3, device=M.device)
    if mode == "rigid":
        w = M - M.T  # 反对称 -> 旋转
        return torch.linalg.matrix_exp(w)
    return eye + M


def affine_refine(ct: Volume, mr: Volume, t0: torch.Tensor, p: Params):
    """② 4mm MIND-SSD 上 Adam 优化刚体/仿射（绕 CT 中心）。返回 (A 3×3, b)：p_mr = A x + b。

    损失区域在初值处固定（CT 体部 ∩ 初始 MR 视野）：移出 MR 视野的点采样为 0、代价变高，
    避免「缩到一小块匹配好的区域」的作弊解。
    """
    eye = torch.eye(3, device=ct.t.device)
    if p.affine_mode == "none":
        return eye, t0.clone()
    fct, fmr = mind_ssc(ct.t), mind_ssc(mr.t)
    pts = ct.world_grid()
    body = ct.t[0, 0] > 0.15
    region = body & mr.valid(pts + t0)
    c = pts[region].mean(0)
    x = pts[region] - c
    fct_b = fct[0][:, region]
    M = torch.zeros(3, 3, device=pts.device, requires_grad=True)
    b = t0.clone().requires_grad_(True)
    opt = torch.optim.Adam([{"params": [M], "lr": p.affine_lr}, {"params": [b], "lr": 0.5}])
    for _ in range(p.affine_iters):
        q = x @ _linear(M, p.affine_mode).T + c + b
        fm = mr.sample(fmr, q)[0]
        loss = ((fm - fct_b) ** 2).mean()
        opt.zero_grad()
        loss.backward()
        opt.step()
    with torch.no_grad():
        A = _linear(M, p.affine_mode)
        return A.detach(), (c + b - A @ c).detach()


def apply_affine(pts, A, b):
    return pts @ A.T + b


def organ_probs(case_dir: Path, modality: str, p: Params, group: str) -> sitk.Image | None:
    """3 通道器官概率（肝/脾/肾），原生几何。"""
    if p.seg_source == "gt":
        lab = sitk.ReadImage(str(find_label(case_dir, modality)))
        arr = harmonize(sitk.GetArrayFromImage(lab), group)
        chans = []
        for k in (1, 2, 3):
            c = sitk.GetImageFromArray((arr == k).astype(np.float32))
            c.CopyInformation(lab)
            chans.append(sitk.SmoothingRecursiveGaussian(c, p.seg_sigma))
        return sitk.Compose(chans)
    if p.seg_source == "pred":
        prob = sitk.ReadImage(str(Path(p.pred_dir) / f"{case_dir.name}_{modality}.nii.gz"))
        if p.pred_hard:
            # 硬标签 one-hot：与 GT 分支的形态一致（GT 是 one-hot 后平滑）
            arr = sitk.GetArrayFromImage(prob).astype(np.float32)
            if prob.GetPixelID() == sitk.sitkVectorUInt8:
                arr /= 255.0
            lab = np.where(arr.max(-1) > 0.5, arr.argmax(-1) + 1, 0).astype(np.uint8)
            chans = []
            for k in (1, 2, 3):
                c = sitk.GetImageFromArray((lab == k).astype(np.float32))
                c.CopyInformation(prob)
                chans.append(c)
            prob = sitk.Compose(chans)
        if p.pred_sigma > 0:
            chans = [
                sitk.VectorIndexSelectionCast(prob, i, sitk.sitkFloat32)
                for i in range(prob.GetNumberOfComponentsPerPixel())
            ]
            prob = sitk.Compose([sitk.SmoothingRecursiveGaussian(c, p.pred_sigma) for c in chans])
        if p.pred_lcc > 0:
            prob = keep_large_components(prob, p.pred_lcc)
        return prob
    return None


def keep_large_components(prob: sitk.Image, min_frac: float) -> sitk.Image:
    """按器官保留**最大连通域**（肾保留左右两个最大的）。

    动机（2026-11-02 诊断）：配准剩余空间全在分割侧（final 0.9151 vs GT 天花板
    0.9506）。分割的常见失败模式是「主器官 + 远处散点误检」；这些散点：
      · 破坏质心初值（centroid 被拉偏）→ 初始平移错；
      · 作为额外特征通道引入错误梯度 → Adam 阶段把位移场拉向假目标。
    肝/脾是单侧单连通，肾是双侧双连通，故按器官保留 top-2 连通域。

    实现：逐通道对 argmax 标签做 3D 连通域标记，按体积保留最大的 1（肝/脾）或
    2（肾）个，其余体素概率置零。min_frac 为「保留的最小体积占比」阈值，
    用于剔除比主连通域小太多的第二肾（避免把噪声块当肾）。
    """
    from scipy import ndimage

    arr = sitk.GetArrayFromImage(prob).astype(np.float32)
    if prob.GetPixelID() == sitk.sitkVectorUInt8:
        arr /= 255.0
    lab = np.where(arr.max(-1) > 0.5, arr.argmax(-1) + 1, 0).astype(np.uint8)
    keep = np.zeros_like(lab, dtype=bool)
    # 通道 0=liver, 1=spleen, 2=kidney（与 harmonize 的语义一致）
    n_keep = {1: 1, 2: 1, 3: 2}
    for k, nk in n_keep.items():
        mask = lab == k
        if not mask.any():
            continue
        cc, n = ndimage.label(mask)
        if n == 0:
            continue
        sizes = np.bincount(cc.ravel())
        sizes[0] = 0
        order = np.argsort(sizes)[::-1]
        top = order[:nk]
        biggest = sizes[order[0]]
        for c in top:
            if sizes[c] < min_frac * biggest:
                continue
            keep |= cc == c
    out = arr.copy()
    out[~keep] = 0.0
    img = sitk.GetImageFromArray(out, isVector=True)
    img.CopyInformation(prob)
    return img



class ProbVolume(Volume):
    """多通道概率图到规范网格。"""

    def __init__(self, prob: sitk.Image, spacing: float, dev):
        ref = canonical_reference(prob, (spacing,) * 3)
        chans = [sitk.VectorIndexSelectionCast(prob, i, sitk.sitkFloat32) for i in range(prob.GetNumberOfComponentsPerPixel())]
        arr = np.stack([sitk.GetArrayFromImage(resample(c, ref, is_label=False)) for c in chans])
        if prob.GetPixelID() == sitk.sitkVectorUInt8:  # seg.predict 以 概率×255 存
            arr = arr / 255.0
        self.t = torch.from_numpy(arr.astype(np.float32))[None].to(dev)
        self.origin = torch.tensor(ref.GetOrigin(), dtype=torch.float32, device=dev)
        self.spacing = float(spacing)
        self.size = torch.tensor(ref.GetSize(), dtype=torch.float32, device=dev)


def organ_centroids(pct: ProbVolume, pmr: ProbVolume) -> tuple[list, list]:
    cs, ms = [], []
    gct, gmr = pct.world_grid(), pmr.world_grid()
    for k in range(3):
        wc, wm = pct.t[0, k], pmr.t[0, k]
        if wc.sum() > 50 and wm.sum() > 50:
            cs.append((gct * wc[..., None]).sum((0, 1, 2)) / wc.sum())
            ms.append((gmr * wm[..., None]).sum((0, 1, 2)) / wm.sum())
    return cs, ms


def centroid_translation(pct: ProbVolume, pmr: ProbVolume) -> tuple[torch.Tensor, int]:
    """器官质心平均偏移（017–024 三器官偏移一致到 ±15–30mm，平移即可）。"""
    cs, ms = organ_centroids(pct, pmr)
    if not cs:
        return torch.zeros(3, device=pct.t.device), 0
    return (torch.stack(ms) - torch.stack(cs)).mean(0), len(cs)


def local_translation_refine(ct: Volume, mr: Volume, t0: torch.Tensor, p: Params):
    """①' 在质心初值附近做**局部**图像驱动平移精化。

    为什么需要：器官质心初值对「三器官偏移不一致」的病例不准（024 例平移
    初值只有 0.611，是全部 8 例最差）。质心法只看器官中心，无法利用图像内容。

    做法：以 t0 为中心，在 ±``refine_radius`` mm 的小窗口内，用 4mm MIND 特征
    SSD 选最优平移。窗口小 → 候选少 → 比 ① 的全空间穷举快得多，也比质心法准。

    返回 (最优平移, 代价)。若代价无改善则返回 t0。
    """
    step = max(4.0, p.refine_step)
    r = p.refine_radius
    rng = torch.arange(-r, r + 1e-3, step, device=ct.t.device)
    cands = torch.stack(torch.meshgrid(rng, rng, rng, indexing="ij"), -1).reshape(-1, 3)
    cands = cands + t0[None]
    if cands.shape[0] == 1:
        return t0.clone(), float("inf")

    fct, fmr = mind_ssc(ct.t), mind_ssc(mr.t)
    pts = ct.world_grid()
    body = ct.t[0, 0] > 0.15
    mr_body = mr.t > 0.05
    # 只在「CT 体部 ∩ 各候选都还覆盖 MR 视野」的区域上算代价
    need = p.min_overlap * min(int(body.sum()), int(mr_body.sum()))
    pts_b = pts[body]
    fct_b = fct[0][:, body]
    mr_body_f = mr_body.float()

    best_cost, best_t = float("inf"), t0.clone()
    for chunk in cands.split(64):
        q = pts_b[None] + chunk[:, None, :]
        g = mr.to_norm(q).reshape(1, -1, 1, 1, 3)
        fm = F.grid_sample(fmr, g, align_corners=True, padding_mode="zeros").reshape(12, len(chunk), -1)
        vb = F.grid_sample(mr_body_f, g, align_corners=True, mode="nearest").reshape(len(chunk), -1) > 0.5
        ssd = ((fm - fct_b[:, None, :]) ** 2).mean(0)
        n = vb.sum(1)
        c = (ssd * vb).sum(1) / n.clamp(min=1)
        c[n < need] = float("inf")
        i = int(c.argmin())
        if float(c[i]) < best_cost:
            best_cost = float(c[i])
            best_t = chunk[i].clone()
    return best_t, best_cost


def centroid_init(pct: ProbVolume, pmr: ProbVolume) -> tuple[torch.Tensor, torch.Tensor, int]:
    """器官质心配对 -> 平移（<3 器官）或 Kabsch 刚体（3 器官）。返回 (A, b, 器官数)。"""
    cs, ms = [], []
    gct, gmr = pct.world_grid(), pmr.world_grid()
    for k in range(3):
        wc, wm = pct.t[0, k], pmr.t[0, k]
        if wc.sum() > 50 and wm.sum() > 50:
            cs.append((gct * wc[..., None]).sum((0, 1, 2)) / wc.sum())
            ms.append((gmr * wm[..., None]).sum((0, 1, 2)) / wm.sum())
    eye = torch.eye(3, device=pct.t.device)
    if not cs:
        return eye, torch.zeros(3, device=pct.t.device), 0
    C, M = torch.stack(cs), torch.stack(ms)
    if len(cs) < 3:
        return eye, (M - C).mean(0), len(cs)
    cc, mc = C.mean(0), M.mean(0)
    U, _, Vt = torch.linalg.svd((C - cc).T @ (M - mc))
    d = torch.sign(torch.linalg.det(Vt.T @ U.T))
    R = Vt.T @ torch.diag(torch.tensor([1.0, 1.0, float(d)], device=C.device)) @ U.T
    return R, mc - R @ cc, 3


def with_seg(mind: torch.Tensor, prob: torch.Tensor | None, w: float) -> torch.Tensor:
    if prob is None:
        return mind
    return torch.cat([mind, prob * (4.0 * w) ** 0.5], 1)


def feat_ssd(a: torch.Tensor, b: torch.Tensor, dim=1) -> torch.Tensor:
    """通道 SSD / 12：MIND 部分 = 均值，概率部分按 seg_weight 加权。"""
    return ((a - b) ** 2).sum(dim) / 12.0


def convex_search(fct, fmr_w, p: Params):
    """③ 控制网格上的代价体 + 渐进耦合平滑。fct/fmr_w: (1,12,D,H,W) 同网格。返回控制网格位移（2mm 体素单位，(1,3,d,h,w) 通道 x,y,z）。

    显存说明：原始实现一次性构造 (K,d,h,w) 的代价体与正则张量，K=2197（grid=4）时尚可，
    但 grid=3（K=4913）或 grid=2（K=15625）会直接 OOM。这里把两者的最小值搜索都
    沿 K 分块进行，峰值显存降到 O(chunk·d·h·w)，与 K 基本无关。
    """
    g, R = p.grid, p.radius
    ff = F.avg_pool3d(fct, g, stride=g)
    fm = F.avg_pool3d(fmr_w, g, stride=g)
    _, C, d, h, w = ff.shape
    fm_p = F.pad(fm, (R,) * 6)
    rng = torch.arange(-R, R + 1, device=ff.device)
    disp = torch.stack(torch.meshgrid(rng, rng, rng, indexing="ij"), -1).reshape(-1, 3)  # (dz,dy,dx)
    K = len(disp)
    # 分块大小：控制每块的 (chunk,d,h,w) 不超过约 1.2e8 个元素（约 0.5GB fp32）
    chunk = max(1, int(1.2e8 // max(1, d * h * w)))
    dvec = disp.float()  # (K,3) 控制格单位

    def block_costs(s, e):
        """返回 (e-s,d,h,w) 的 SSD 代价体。"""
        blk = torch.empty(e - s, d, h, w, device=ff.device)
        for j, (dz, dy, dx) in enumerate(disp[s:e].tolist()):
            sh = fm_p[:, :, R + dz : R + dz + d, R + dy : R + dy + h, R + dx : R + dx + w]
            blk[j] = feat_ssd(ff, sh)[0]
        return blk

    # ① 无正则的最优位移（原实现会把整个 cost 体除以其均值后再做正则化，
    #    这里先求出全局代价尺度，后续用等价方式施加同样的归一化。）
    best_cost = torch.full((d, h, w), float("inf"), device=ff.device)
    best_idx = torch.empty(d, h, w, dtype=torch.long, device=ff.device)
    cost_sum = torch.zeros((), device=ff.device)
    for s in range(0, K, chunk):
        e = min(K, s + chunk)
        blk = block_costs(s, e)
        cost_sum += blk.sum()
        bi = blk.argmin(0)
        bc = blk.gather(0, bi[None]).squeeze(0)
        upd = bc < best_cost
        best_cost = torch.where(upd, bc, best_cost)
        best_idx = torch.where(upd, bi + s, best_idx)
        del blk
    # 全局均值 = cost_sum / (K*d*h*w)，与原实现的 cost.mean() 一致
    cost_mean = float(cost_sum / max(1, K * d * h * w))
    cost_mean = max(cost_mean, 1e-12)
    cur = dvec[best_idx].permute(3, 0, 1, 2)[None]  # (1,3,d,h,w) (dz,dy,dx)

    # ② 渐进耦合平滑：每轮在 cost/cost_mean + coeff*pen 上取最小
    for coeff in p.coeffs:
        sm = cur
        for _ in range(3):
            sm = F.avg_pool3d(F.pad(sm, (1,) * 6, mode="replicate"), 3, stride=1)
        best_cost = torch.full((d, h, w), float("inf"), device=ff.device)
        best_idx = torch.empty(d, h, w, dtype=torch.long, device=ff.device)
        for s in range(0, K, chunk):
            e = min(K, s + chunk)
            blk = block_costs(s, e) / cost_mean
            dv = dvec[s:e]
            pen = ((dv[:, :, None, None, None] - sm[0][None]) ** 2).sum(1)  # (k,d,h,w)
            total = blk + coeff * pen
            bi = total.argmin(0)
            bc = total.gather(0, bi[None]).squeeze(0)
            upd = bc < best_cost
            best_cost = torch.where(upd, bc, best_cost)
            best_idx = torch.where(upd, bi + s, best_idx)
            del blk, pen, total
        cur = dvec[best_idx].permute(3, 0, 1, 2)[None]

    for _ in range(3):
        cur = F.avg_pool3d(F.pad(cur, (1,) * 6, mode="replicate"), 3, stride=1)
    # (dz,dy,dx) 控制格 -> (x,y,z) 2mm 体素
    return cur.flip(1) * g


def diffusion(u):
    dz = u[:, :, 1:] - u[:, :, :-1]
    dy = u[:, :, :, 1:] - u[:, :, :, :-1]
    dx = u[..., 1:] - u[..., :-1]
    return (dz**2).mean() + (dy**2).mean() + (dx**2).mean()


def affine_penalty(u):
    """惩罚位移场中的**仿射分量**（整体旋转/缩放/剪切），但**不惩罚平移**。

    为什么需要：diffusion 正则只惩罚一阶差分，因此允许整场做均匀平移与仿射。
    ① 的平移初值（器官质心）本身已对齐；若 Adam 阶段让位移场产生仿射漂移，
    就会把初始对齐「洗掉」——这正解释了 E1/J1 中凸搜索的改进（+0.023）在
    Adam 阶段后消失（final 仅 +0.001）的现象。

    实现：用**体素坐标**做自变量拟合最小二乘仿射 v ≈ X·M + b
    （输入 u 的单位须与坐标一致，生产调用传的是 ``us / reg_sp``，即体素单位）。
    此时 M 无量纲：纯平移 → M = 0；纯旋转 → M 含 ±1 量级的反对称分量；
    纯缩放 → M = λ·I。因此惩罚 |M|² 即可把仿射漂移压掉，而平移 b 不受惩罚。
    """
    _, _, D, H, W = u.shape
    dz = torch.arange(D, device=u.device, dtype=u.dtype) - (D - 1) / 2
    dy = torch.arange(H, device=u.device, dtype=u.dtype) - (H - 1) / 2
    dx = torch.arange(W, device=u.device, dtype=u.dtype) - (W - 1) / 2
    zz, yy, xx = torch.meshgrid(dz, dy, dx, indexing="ij")
    # 物理坐标（mm）：u 的通道 0=x(W)、1=y(H)、2=z(D)
    coords = torch.stack([xx, yy, zz], -1).reshape(-1, 3).to(u.dtype)  # (N,3)
    v = u[0].reshape(3, -1).T  # (N,3)：列 = (dx, dy, dz)
    ones = torch.ones(coords.shape[0], 1, device=u.device, dtype=u.dtype)
    A = torch.cat([coords, ones], -1)  # (N,4)
    sol = torch.linalg.lstsq(A, v).solution  # (4,3)
    M = sol[:3]  # (3,3) 无量纲：纯平移时为 0
    return (M**2).sum()


# ----------------------------------------------------------------------------- pipeline
@dataclass
class CaseResult:
    case: str
    group: str
    t_search: list = field(default_factory=list)
    search_cost: float = 0.0
    t_refine: list = field(default_factory=list)
    refine_cost: float | None = None
    dice: dict = field(default_factory=dict)  # stage -> {organ: dice, mean}
    seconds: float = 0.0
    fold_pct: float = 0.0


def register_case(case_dir: Path, p: Params, dev, out_field: Path | None = None) -> CaseResult:
    t0 = time.time()
    ct_img = sitk.ReadImage(str(find_image(case_dir, "ct")))
    mr_img = sitk.ReadImage(str(find_image(case_dir, "mr")))
    res = CaseResult(case_dir.name, paired_group(case_dir.name))
    stages: dict[str, sitk.Image] = {}

    pct_img = organ_probs(case_dir, "ct", p, res.group) if p.seg_source != "none" else None
    pmr_img = organ_probs(case_dir, "mr", p, res.group) if p.seg_source != "none" else None

    # ① 初值：MIND 平移穷举，或器官质心平移
    if p.init == "seg":
        with torch.no_grad():
            t, n_org = centroid_translation(ProbVolume(pct_img, p.affine_sp, dev), ProbVolume(pmr_img, p.affine_sp, dev))
        res.search_cost = float(n_org)
        # ①' 局部图像驱动精化：质心初值对「三器官偏移不一致」的病例不准
        if p.refine:
            ct4r, mr4r = Volume(ct_img, p.affine_sp, "ct", dev), Volume(mr_img, p.affine_sp, "mr", dev)
            with torch.no_grad():
                t2, c2 = local_translation_refine(ct4r, mr4r, t, p)
            res.refine_cost = round(float(c2), 4) if c2 < float("inf") else None
            res.t_refine = [round(v, 1) for v in t2.tolist()]
            t = t2
    else:
        ct8, mr8 = Volume(ct_img, p.search_sp, "ct", dev), Volume(mr_img, p.search_sp, "mr", dev)
        with torch.no_grad():
            t, cost = translation_search(ct8, mr8, p)
        res.search_cost = round(cost, 4)
    res.t_search = [round(v, 1) for v in t.tolist()]
    # ②
    ct4, mr4 = Volume(ct_img, p.affine_sp, "ct", dev), Volume(mr_img, p.affine_sp, "mr", dev)
    A, b = affine_refine(ct4, mr4, t, p)

    # ③ + ④ on 2mm
    ct2, mr2 = Volume(ct_img, p.reg_sp, "ct", dev), Volume(mr_img, p.reg_sp, "mr", dev)
    pct2 = ProbVolume(pct_img, p.reg_sp, dev) if pct_img is not None else None
    pmr2 = ProbVolume(pmr_img, p.reg_sp, dev) if pmr_img is not None else None
    sw = (4.0 * p.seg_weight) ** 0.5

    def moving_feat(fmr_mind, q):
        f = mr2.sample(fmr_mind, q)
        if pmr2 is not None:
            f = torch.cat([f, pmr2.sample(pmr2.t, q) * sw], 1)
        return f

    full_pts = ct2.world_grid()
    with torch.no_grad():
        stages["translation"] = to_field(full_pts + t, full_pts, ct2)
        aff_full = apply_affine(full_pts, A, b)
        stages["affine"] = to_field(aff_full, full_pts, ct2)
        # ③④ 只在「CT 体部 ∩ 仿射后 MR 视野」包围盒（+margin）内做：大视野 CT（如 022 的 522mm）
        # 视野外无信息，且整幅代价体会爆显存；盒外位移 = 仿射
        roi = (ct2.t[0, 0] > 0.15) & mr2.valid(aff_full)
        crop = bbox_slices(roi, margin=int(round(p.crop_margin / p.reg_sp)), min_size=2 * p.grid)
        pts = full_pts[crop]
        cs = (slice(None), slice(None), *crop)
        fct = mind_ssc(ct2.t[cs], p.mind_radius, p.mind_dilation)
        if pct2 is not None:
            # CT 概率在 CT 规范网格上采样到 2mm 体部网格（两者都是规范网格但原点/尺寸不同）
            fct = torch.cat([fct, pct2.sample(pct2.t, pts) * sw], 1)
        fmr = mind_ssc(mr2.t, p.mind_radius, p.mind_dilation)
        fmr_w = moving_feat(fmr, apply_affine(pts, A, b))
        u0 = convex_search(fct, fmr_w, p)  # (1,3,D/g..) 2mm 体素
        D, H, W = pts.shape[:3]
        u0 = F.interpolate(u0, size=(D, H, W), mode="trilinear", align_corners=False) * p.reg_sp
        stages["convex"] = to_field(embed(aff_full, apply_affine(pts + u0[0].permute(1, 2, 3, 0), A, b), crop),
                                    full_pts, ct2)

    # ④ Adam：半分辨率参数，mm 单位
    half = (max(D // 2, 2), max(H // 2, 2), max(W // 2, 2))
    u = F.interpolate(u0, size=half, mode="trilinear", align_corners=False).clone().requires_grad_(True)
    opt = torch.optim.Adam([u], lr=p.io_lr)
    # 锚定目标：凸搜索结果（降采样到 Adam 的半分辨率参数网格）
    anchor_target = F.interpolate(u0, size=half, mode="trilinear", align_corners=False).detach() if p.anchor > 0 else None
    body = (ct2.t[(slice(None), slice(None), *crop)] > 0.15).float()
    # 概率余弦匹配项所需：CT 端器官概率（固定，不随位移变化）
    pct_crop = pct2.sample(pct2.t, pts) if pct2 is not None else None  # (1,3,D,H,W)
    use_cos = p.seg_dice > 0 and pct_crop is not None and pmr2 is not None
    if use_cos:
        pc = pct_crop[0]  # (3,D,H,W)
        if p.seg_dice_sigma > 0:
            # 平滑 CT 端（只做一次，不随迭代重复计算）
            pc = F.avg_pool3d(F.pad(pc[None], (1,) * 6, mode="replicate"), 3, stride=1)[0]
        ct_sq = (pc**2).sum(dim=(1, 2, 3))  # (3,) 平方范数
    for it in range(p.io_iters):
        if p.lr_decay > 0:
            # 线性到 0 的退火：后期步长小，保住已找到的好解
            cur_lr = p.io_lr * max(0.0, 1.0 - it / max(1, p.io_iters)) ** p.lr_decay
            for gp in opt.param_groups:
                gp["lr"] = cur_lr
        us = F.avg_pool3d(F.avg_pool3d(u, 3, 1, 1, count_include_pad=False), 3, 1, 1, count_include_pad=False)
        uf = F.interpolate(us, size=(D, H, W), mode="trilinear", align_corners=False)
        q = apply_affine(pts + uf[0].permute(1, 2, 3, 0), A, b)
        fm = moving_feat(fmr, q)
        v = mr2.valid(q).float()[None, None] * body
        sim = (feat_ssd(fm, fct)[:, None] * v).sum() / v.sum().clamp(min=1)
        loss = sim + p.io_lambda * diffusion(us / p.reg_sp) * 1e-2
        if p.affine_penalty > 0:
            loss = loss + p.affine_penalty * affine_penalty(us / p.reg_sp)
        if anchor_target is not None:
            # 把位移场拉回凸搜索解：对抗 Adam 的自由漂移（这是凸搜索收益被洗掉的根因）
            loss = loss + p.anchor * ((us - anchor_target) ** 2).mean()
        if use_cos:
            # 概率余弦匹配：直接比较「CT 器官概率」与「变换后的 MR 器官概率」。
            #
            # 为什么不用概率 SSD：SSD 是逐体素的，对分割边界噪声极其敏感——预测分割
            # 的边界抖动会主导梯度，让 Adam 去拟合噪声而不是真实解剖。重叠类指标只关心
            # 区域一致性，对边界噪声鲁棒。证据：GT 引导与预测引导在 translation/convex
            # 阶段几乎无差（0.7525/0.8693 vs 0.7550/0.8629），但 final 差 0.049
            # （0.9506 vs 0.9016）——差距**完全产生于 Adam 阶段**。
            pm = pmr2.sample(pmr2.t, q)  # (1,3,D,H,W) 变换后的 MR 概率
            if p.seg_dice_sigma > 0:
                pm = F.avg_pool3d(F.pad(pm, (1,) * 6, mode="replicate"), 3, stride=1)[0]
            else:
                pm = pm[0]
            dot = (pc * pm).sum(dim=(1, 2, 3))  # (3,)
            mr_sq = (pm**2).sum(dim=(1, 2, 3))
            sim = 2 * dot / (ct_sq + mr_sq + 1e-8)  # 余弦相似度，a==b 时严格为 1
            loss = loss + p.seg_dice * (1.0 - sim.mean())
        opt.zero_grad()
        loss.backward()
        opt.step()
    with torch.no_grad():
        us = F.avg_pool3d(F.avg_pool3d(u, 3, 1, 1, count_include_pad=False), 3, 1, 1, count_include_pad=False)
        uf = F.interpolate(us, size=(D, H, W), mode="trilinear", align_corners=False)
        final_pts = apply_affine(pts + uf[0].permute(1, 2, 3, 0), A, b)
        stages["final"] = to_field(embed(aff_full, final_pts, crop), full_pts, ct2)
        res.fold_pct = round(float(folding(final_pts, p.reg_sp)) * 100, 3)
    res.seconds = round(time.time() - t0, 1)

    lab_ct = find_label(case_dir, "ct")
    lab_mr = find_label(case_dir, "mr")
    for name, fld in stages.items():
        native = to_native(fld, ct_img)
        if name == "final" and out_field is not None:
            out_field.parent.mkdir(parents=True, exist_ok=True)
            sitk.WriteImage(native, str(out_field))
        if lab_ct and lab_mr:
            res.dice[name] = score(native, sitk.ReadImage(str(lab_ct)), sitk.ReadImage(str(lab_mr)), res.group)
    if lab_ct and lab_mr:
        res.dice["identity"] = score(None, sitk.ReadImage(str(lab_ct)), sitk.ReadImage(str(lab_mr)), res.group)
    if pct_img is not None:
        # 无标签代理分：预测 MR 器官图经位移场 vs 预测 CT 器官图（测试集 QA；验证集上看与真分的相关）
        native = to_native(stages["final"], ct_img)
        res.dice["final_proxy"] = score(native, prob_to_label(pct_img), prob_to_label(pmr_img), "bcv")
    return res


def prob_to_label(prob: sitk.Image) -> sitk.Image:
    """3 通道器官概率 -> 标签（统一语义 1 肝 / 2 脾 / 3 肾；最大概率 < 0.5 为背景）。"""
    arr = sitk.GetArrayFromImage(prob).astype(np.float32)
    if prob.GetPixelID() == sitk.sitkVectorUInt8:
        arr /= 255.0
    lab = np.where(arr.max(-1) > 0.5, arr.argmax(-1) + 1, 0).astype(np.uint8)
    img = sitk.GetImageFromArray(lab)
    img.SetOrigin(prob.GetOrigin())
    img.SetSpacing(prob.GetSpacing())
    img.SetDirection(prob.GetDirection())
    return img


def bbox_slices(mask: torch.Tensor, margin: int, min_size: int) -> tuple[slice, slice, slice]:
    """(D,H,W) 布尔掩膜的包围盒 + margin；空掩膜返回整幅。"""
    if not mask.any():
        return tuple(slice(0, n) for n in mask.shape)
    out = []
    for ax, n in enumerate(mask.shape):
        idx = mask.any(dim=tuple(a for a in range(3) if a != ax)).nonzero()[:, 0]
        lo, hi = max(int(idx.min()) - margin, 0), min(int(idx.max()) + margin + 1, n)
        if hi - lo < min_size:
            lo, hi = max(0, min(lo, n - min_size)), min(n, max(hi, lo + min_size))
        out.append(slice(lo, hi))
    return tuple(out)


def embed(full: torch.Tensor, part: torch.Tensor, crop) -> torch.Tensor:
    out = full.clone()
    out[crop] = part
    return out


def to_field(target_pts: torch.Tensor, pts: torch.Tensor, ref: Volume) -> sitk.Image:
    """世界坐标映射 -> 规范网格上的 sitk 位移场（float64）。"""
    disp = (target_pts - pts).detach().cpu().numpy().astype(np.float64)
    img = sitk.GetImageFromArray(disp, isVector=True)
    img.SetOrigin(ref.origin.tolist())
    img.SetSpacing((ref.spacing,) * 3)
    return img


def to_native(field_img: sitk.Image, ct_img: sitk.Image) -> sitk.Image:
    tx = sitk.DisplacementFieldTransform(sitk.Image(field_img))
    out = sitk.TransformToDisplacementField(
        tx, sitk.sitkVectorFloat32, ct_img.GetSize(), ct_img.GetOrigin(), ct_img.GetSpacing(), ct_img.GetDirection()
    )
    issues = validate_field(out, ct_img)
    assert not issues, issues
    return out


def score(field_img, lab_ct: sitk.Image, lab_mr: sitk.Image, group: str) -> dict:
    """官方口径：原生 MR 标签经位移场最近邻采样到原生 CT 网格。"""
    if field_img is None:
        tx = sitk.Transform()
    else:
        tx = sitk.DisplacementFieldTransform(sitk.Cast(field_img, sitk.sitkVectorFloat64))
    warped = sitk.Resample(lab_mr, lab_ct, tx, sitk.sitkNearestNeighbor, 0, lab_mr.GetPixelID())
    a = harmonize(sitk.GetArrayFromImage(lab_ct), group)
    bb = harmonize(sitk.GetArrayFromImage(warped), group)
    out = {o: round(dice_for_organ(bb == k, a == k), 4) for k, o in enumerate(ORGANS, start=1)}
    out["mean"] = round(float(np.mean([out[o] for o in ORGANS])), 4)
    return out


def folding(pts: torch.Tensor, sp: float) -> torch.Tensor:
    """负雅可比行列式比例（映射 pts: (D,H,W,3) 世界坐标）。"""
    dz = (pts[1:, :-1, :-1] - pts[:-1, :-1, :-1]) / sp
    dy = (pts[:-1, 1:, :-1] - pts[:-1, :-1, :-1]) / sp
    dx = (pts[:-1, :-1, 1:] - pts[:-1, :-1, :-1]) / sp
    J = torch.stack([dx, dy, dz], -1)
    return (torch.linalg.det(J) <= 0).float().mean()


# ----------------------------------------------------------------------------- CLI
def parse_cases(specs: list[str]) -> list[str]:
    out = []
    for s in specs:
        if "-" in s:
            a, b = s.split("-")
            out += [f"{i:03d}" for i in range(int(a), int(b) + 1)]
        else:
            out.append(s)
    return out


def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    r = sub.add_parser("run")
    r.add_argument("--cases", nargs="+", required=True)
    r.add_argument("--split", default="train")
    r.add_argument("--out", required=True)
    r.add_argument("--gpu", type=int, default=0)
    r.add_argument("--save-fields", action="store_true")
    r.add_argument("--set", nargs="*", default=[], help="覆盖参数 key=value")
    args = ap.parse_args()

    p = Params()
    for kv in args.set:
        k, v = kv.split("=", 1)
        cur = getattr(p, k)
        if isinstance(cur, bool):
            # ⚠️ bool("False") 是 True！必须显式解析，否则 `pred_hard=False`
            #    会静默变成 True（历史消融 CA2/CB1 因此被误归因）。
            setattr(p, k, v.strip().lower() in ("1", "true", "yes", "on"))
        elif isinstance(cur, tuple):
            setattr(p, k, eval(v))
        else:
            setattr(p, k, type(cur)(v))
    dev = torch.device(f"cuda:{args.gpu}")
    out = Path(args.out).expanduser()
    out.mkdir(parents=True, exist_ok=True)
    (out / "params.json").write_text(json.dumps(asdict(p), indent=1))

    results = []
    for c in parse_cases(args.cases):
        case_dir = DATA_ROOT / args.split / c
        fld = out / "fields" / c / "displacement_field.nii.gz" if args.save_fields else None
        res = register_case(case_dir, p, dev, fld)
        results.append(res)
        d = res.dice
        line = f"{c} {res.group:7s} t={res.t_search} cost={res.search_cost} " + " ".join(
            f"{s}={d[s]['mean']:.3f}" for s in ("identity", "translation", "affine", "convex", "final", "final_proxy") if s in d
        ) + f" fold={res.fold_pct}% {res.seconds}s"
        print(line, flush=True)

    with open(out / "per_case.csv", "w", newline="") as fh:
        wr = csv.writer(fh)
        wr.writerow(["case", "group", "stage", *ORGANS, "mean", "fold_pct", "t_search"])
        for res in results:
            for s, d in res.dice.items():
                wr.writerow([res.case, res.group, s, *(d[o] for o in ORGANS), d["mean"], res.fold_pct, res.t_search])
    summary = {}
    for g in sorted({r.group for r in results}):
        rs = [r for r in results if r.group == g]
        for s in ("identity", "translation", "affine", "convex", "final", "final_proxy"):
            vals = [r.dice[s]["mean"] for r in rs if s in r.dice]
            if vals:
                summary[f"{g}/{s}"] = {"dsc": round(float(np.mean(vals)), 4), "std": round(float(np.std(vals)), 4),
                                       "dsc30": round(dsc30(vals)[0], 4), "n": len(vals)}
    (out / "summary.json").write_text(json.dumps(summary, indent=1))
    print("\n== summary (DSC / std / DSC30)")
    for k, v in summary.items():
        print(f"  {k:22s} {v['dsc']:.4f} ±{v['std']:.4f}  DSC30 {v['dsc30']:.4f}  n={v['n']}")


if __name__ == "__main__":
    main()
