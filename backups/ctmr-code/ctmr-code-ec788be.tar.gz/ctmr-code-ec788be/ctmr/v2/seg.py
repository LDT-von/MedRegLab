"""E2/E3：单模态器官分割（3D U-Net，从零训练，无任何预训练权重）。

训练纪律（实验计划_v2 §4）：固定训练长度、只存 last（不按验证集挑 ckpt）；
验证集 = 本折留出病例，曲线只用于观察。

用法::

    python -m ctmr.v2.seg train --modality ct --fold 0 --gpu 0
    python -m ctmr.v2.seg train --modality mr --fold all --gpu 1   # 全量模型
"""
from __future__ import annotations

import argparse
import json
import math
import time
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

from ctmr.v2.data import N_FOLDS

CACHE = Path("/home/ubuntu/ctmr/cache")
RUNS = Path("/home/ubuntu/ctmr/runs")
N_CLASSES = 4  # 0 bg / 1 liver / 2 spleen / 3 kidney
PATCH = (64, 160, 160)  # (D,H,W) @ 3.0×1.5×1.5mm = 192×240×240mm

# ⚠️ PATCH 覆盖不足（2026-11-02 发现）：实测 57 个器官样本的物理跨度超过
#    PATCH 的覆盖范围。inhouse 组（= 测试集同源）的肝 177×183×219mm、
#    肾 129×88×223mm，都超出 192×240×240mm —— 网络训练时**从来看不到完整器官**，
#    边界位置学不到。这是分割 Dice 只有 0.927 的可能根因之一。
#    大 PATCH 方案：`--patch D H W` 可覆盖（如 96×176×192 = 288×264×288mm）。
PATCH_PRESETS = {
    "small": (64, 160, 160),   # 192×240×240mm（原默认）
    "large": (96, 176, 192),   # 288×264×288mm（覆盖 inhouse 全部器官）
}


# ----------------------------------------------------------------------------- model
class ConvBlock(nn.Sequential):
    def __init__(self, cin: int, cout: int, stride=1):
        super().__init__(
            nn.Conv3d(cin, cout, 3, stride=stride, padding=1, bias=False),
            nn.InstanceNorm3d(cout, affine=True),
            nn.LeakyReLU(0.01, inplace=True),
            nn.Conv3d(cout, cout, 3, padding=1, bias=False),
            nn.InstanceNorm3d(cout, affine=True),
            nn.LeakyReLU(0.01, inplace=True),
        )


class UNet3D(nn.Module):
    """各向异性 U-Net：第一次下采样只在 H/W（层厚 3mm vs 1.5mm）。"""

    def __init__(self, cin=1, ncls=N_CLASSES, widths=(32, 64, 128, 256, 320)):
        super().__init__()
        strides = [1, (1, 2, 2), 2, 2, 2]
        self.enc = nn.ModuleList()
        c = cin
        for w, s in zip(widths, strides):
            self.enc.append(ConvBlock(c, w, s))
            c = w
        self.up = nn.ModuleList()
        self.dec = nn.ModuleList()
        for i in range(len(widths) - 1, 0, -1):
            s = strides[i]
            self.up.append(nn.ConvTranspose3d(widths[i], widths[i - 1], s, stride=s))
            self.dec.append(ConvBlock(2 * widths[i - 1], widths[i - 1]))
        self.head = nn.Conv3d(widths[0], ncls, 1)

    def forward(self, x):
        skips = []
        for blk in self.enc:
            x = blk(x)
            skips.append(x)
        x = skips.pop()
        for up, dec in zip(self.up, self.dec):
            x = dec(torch.cat([up(x), skips.pop()], 1))
        return self.head(x)


# ----------------------------------------------------------------------------- data
def load_items(modality: str, fold: int | str):
    meta = json.loads((CACHE / "seg_1.5x1.5x3.0" / "meta.json").read_text())
    train, val = [], []
    for r in meta:
        if not r["uid"].endswith("_" + modality) or r["fold"] < 0 or "EMPTY" in r.get("flags", []):
            continue
        if "vol_ml" not in r:
            continue
        (val if fold != "all" and r["fold"] == fold else train).append(r)
    return train, val


def load_arrays(recs):
    out = []
    for r in recs:
        z = np.load(CACHE / "seg_1.5x1.5x3.0" / f"{r['uid']}.npz")
        img, lab = z["img"], z["lab"]  # 保持 float16（.61 只有 9GB 内存），取块时再转 float32
        fg = []
        for k in range(1, N_CLASSES):
            idx = np.argwhere(lab == k)
            if len(idx):
                fg.append(idx[np.random.default_rng(0).choice(len(idx), min(len(idx), 3000), replace=False)])
        out.append({"uid": r["uid"], "group": r["group"], "img": img, "lab": lab, "fg": fg})
    return out


def sample_patch(item, rng, fg_prob=0.67, size=PATCH):
    img, lab = item["img"], item["lab"]
    if item["fg"] and rng.random() < fg_prob:
        pts = item["fg"][rng.integers(len(item["fg"]))]
        center = pts[rng.integers(len(pts))]
    else:
        center = np.array([rng.integers(s) for s in img.shape])
    # 大一圈裁剪，留给 GPU 旋转/缩放
    big = [int(s * 1.25) for s in size]
    lo = [int(c - b // 2) for c, b in zip(center, big)]
    pi = np.zeros(big, np.float32)
    pl = np.zeros(big, np.uint8)
    src = tuple(slice(max(l, 0), min(l + b, s)) for l, b, s in zip(lo, big, img.shape))
    dst = tuple(slice(sl.start - l, sl.stop - l) for sl, l in zip(src, lo))
    pi[dst] = img[src]
    pl[dst] = lab[src]
    return pi, pl


def gpu_augment(img, lab, modality, size=PATCH):
    """img/lab: (B,1,D',H',W') -> 随机仿射 + 强度增强，输出 PATCH 大小。"""
    b, dev = img.shape[0], img.device
    theta = torch.zeros(b, 3, 4, device=dev)
    for i in range(b):
        # affine_grid 坐标分量顺序 (x,y,z) = (W,H,D)：轴位面内 = 分量 0/1
        az = math.radians(np.random.uniform(-15, 15))
        ax, ay = (math.radians(np.random.uniform(-5, 5)) for _ in range(2))
        s = np.random.uniform(0.85, 1.2)
        r_axial = torch.tensor([[math.cos(az), -math.sin(az), 0], [math.sin(az), math.cos(az), 0], [0, 0, 1]])
        r_yz = torch.tensor([[1, 0, 0], [0, math.cos(ax), -math.sin(ax)], [0, math.sin(ax), math.cos(ax)]])
        r_xz = torch.tensor([[math.cos(ay), 0, math.sin(ay)], [0, 1, 0], [-math.sin(ay), 0, math.cos(ay)]])
        theta[i, :, :3] = (r_axial @ r_yz @ r_xz).to(dev) / s
        theta[i, :, 3] = torch.empty(3, device=dev).uniform_(-0.05, 0.05)
    # 输出 PATCH，采样范围对应原大块中心 1/1.25
    theta[:, :, :3] = theta[:, :, :3] / 1.25
    grid = F.affine_grid(theta, (b, 1, *size), align_corners=False)
    img = F.grid_sample(img, grid, mode="bilinear", padding_mode="zeros", align_corners=False)
    lab = F.grid_sample(lab.float(), grid, mode="nearest", padding_mode="zeros", align_corners=False).long()

    # 强度：对比度/亮度/gamma/噪声/模糊；MR 再加低频偏置场
    for i in range(b):
        x = img[i]
        if modality == "mr" and np.random.rand() < 0.7:
            coarse = torch.randn(1, 1, 3, 4, 4, device=dev) * 0.25
            field = F.interpolate(coarse, size=x.shape[1:], mode="trilinear", align_corners=False)[0]
            x = x * torch.exp(field)
        if np.random.rand() < 0.8:
            x = x * np.random.uniform(0.75, 1.25) + np.random.uniform(-0.1, 0.1)
        if np.random.rand() < 0.5:
            g = np.random.uniform(0.7, 1.5)
            x = x.clamp(min=0) ** g
        if np.random.rand() < 0.3:
            x = x + torch.randn_like(x) * np.random.uniform(0, 0.05)
        if np.random.rand() < 0.2:
            x = F.avg_pool3d(x[None], 3, stride=1, padding=1)[0]
        img[i] = x
    return img, lab[:, 0]


def soft_dice_loss(logits, target):
    p = logits.softmax(1)
    oh = F.one_hot(target, N_CLASSES).permute(0, 4, 1, 2, 3).float()
    dims = (0, 2, 3, 4)
    inter = (p * oh).sum(dims)
    den = p.sum(dims) + oh.sum(dims)
    dice = (2 * inter + 1e-5) / (den + 1e-5)
    return 1 - dice[1:].mean()


@torch.no_grad()
def sliding_window(model, img, size=PATCH, step=0.5, use_amp=True):
    """img: (1,1,D,H,W) -> softmax 概率 (1,C,D,H,W)。

    ``use_amp=False`` 时用 fp32 推理。bf16 只有约 8 位有效位，对小器官
    （如 024 例仅 95ml 的脾脏）的边界精度影响明显；fp32 推理更准也更可复现。
    """
    _, _, *shape = img.shape
    pad = [max(0, s - d) for s, d in zip(size, shape)]
    x = F.pad(img, (0, pad[2], 0, pad[1], 0, pad[0]))
    full = x.shape[2:]
    out = torch.zeros(1, N_CLASSES, *full, device=img.device)
    cnt = torch.zeros(1, 1, *full, device=img.device)
    starts = [
        sorted({min(i, f - s) for i in range(0, max(f - s, 0) + 1, max(1, int(s * step)))} | {max(f - s, 0)})
        for f, s in zip(full, size)
    ]
    for z in starts[0]:
        for y in starts[1]:
            for w in starts[2]:
                sl = (slice(None), slice(None), slice(z, z + size[0]), slice(y, y + size[1]), slice(w, w + size[2]))
                if use_amp:
                    with torch.autocast("cuda", dtype=torch.bfloat16):
                        out[sl] += model(x[sl]).float().softmax(1)
                else:
                    out[sl] += model(x[sl]).float().softmax(1)
                cnt[sl] += 1
    out = out / cnt
    return out[:, :, : shape[0], : shape[1], : shape[2]]


# --------------------------------------------------------------------------- TTA
# 翻转测试时增强（TTA）。
#
# 为什么做这个：分割 Dice 0.927 是配准第二大杠杆（GT 引导可到 0.9506 vs 预测 0.9037），
# 而验证曲线到 ep100 仍在上升，说明分割本身还有空间。翻转 TTA 不需要重训，
# 只需前向几次，是性价比最高的提分手段。
#
# 各向异性注意：体数据是 (D,H,W) @ 3.0×1.5×1.5mm，**轴位面内翻转 (H,W)** 与
# **层厚方向翻转 (D)** 的几何含义不同，腹部解剖并非严格左右对称，
# 因此只做**面内左右翻转**（H 轴，对应 L/R）和**前后翻转**（W 轴，对应 A/P），
# 不做 D 轴（上/下）翻转。
#
# ⚠️ 维度陷阱：张量是 (N,C,D,H,W)，因此 **H=dim 3、W=dim 4、D=dim 2**。
#    早期版本误用 (2,)/(3,)，实际翻转的是 D 轴和 H 轴，导致 Dice 从 0.94 崩到 0.57
#    （因为 3mm 层厚的轴向翻转不是解剖镜像）。合成测试已锁定该映射。
_TTA_FLIPS = {"lr": (3,), "ap": (4,)}


def sliding_window_tta(model, img, size=PATCH, step=0.5, use_amp=True, flips=("lr",)):
    """多翻转 TTA 的滑窗推理，返回平均概率 (1,C,D,H,W)。

    对每个翻转组合，推理后翻回原空间再平均。
    """
    base = sliding_window(model, img, size=size, step=step, use_amp=use_amp)
    if not flips:
        return base
    acc = base.clone()
    n = 1
    for name in flips:
        dims = _TTA_FLIPS.get(name)
        if dims is None:
            raise ValueError(f"未知的 TTA 翻转: {name}（可选 {list(_TTA_FLIPS)}）")
        x = torch.flip(img, dims=dims)
        p = sliding_window(model, x, size=size, step=step, use_amp=use_amp)
        acc += torch.flip(p, dims=dims)
        n += 1
    return acc / n


def sliding_window_multiscale(model, img, size=PATCH, step=0.5, use_amp=True,
                              scales=(1.0,), weights=None):
    """多尺度 TTA：同一图像按不同空间尺寸滑窗推理，再把概率重采样回原尺寸平均。

    为什么做这个（2026-11-02）：
        诊断显示配准剩余空间**全部在分割侧**（GA1 final 0.9151 vs GT 天花板 0.9506，
        差 0.0355；而 final_proxy=0.9832 说明配准对预测掩膜几乎完美对齐）。
        分割的结构性缺陷是「网络从来看不到完整器官」——训练 PATCH 192×240×240mm
        而 inhouse 肝 177×183×219mm、肾 129×88×223mm，器官边界落在 patch 外。
        大 patch 训练更差（100ep 预算不够），但**推理时用大窗口**不需要重训，
        直接让网络看到完整器官。

    与翻转 TTA 的关键区别：多尺度**不改变解剖语义**（左右翻转会把单侧器官
    翻到解剖上错误的一侧，实测脾脏 Dice 从 0.93 崩到 0.02）。

    实现：把图像用 trilinear 重采样到 scale 倍的物理尺寸，用 size 滑窗，
    概率再重采样回原尺寸。scale>1 = 放大视野（看到更多上下文）。
    """
    base_shape = img.shape[2:]
    acc = None
    wsum = 0.0
    if weights is None:
        weights = [1.0] * len(scales)
    for sc, w in zip(scales, weights):
        if abs(sc - 1.0) < 1e-6:
            p = sliding_window(model, img, size=size, step=step, use_amp=use_amp)
        else:
            # 放大物理尺寸（各向异性按目标物理覆盖反推），再滑窗
            tgt = tuple(max(8, int(round(s * sc))) for s in base_shape)
            x = F.interpolate(img, size=tgt, mode="trilinear", align_corners=False)
            p = sliding_window(model, x, size=size, step=step, use_amp=use_amp)
            p = F.interpolate(p, size=base_shape, mode="trilinear", align_corners=False)
        acc = p * w if acc is None else acc + p * w
        wsum += w
    return acc / max(wsum, 1e-8)



def dice_scores(pred, lab):
    s = []
    for k in range(1, N_CLASSES):
        a, b = pred == k, lab == k
        if b.sum() == 0:
            s.append(float("nan"))
            continue
        s.append(float(2 * (a & b).sum() / (a.sum() + b.sum())))
    return s


def evaluate(model, items, dev, size=PATCH):
    model.eval()
    rows = []
    for it in items:
        x = torch.from_numpy(it["img"].astype(np.float32))[None, None].to(dev)
        pred = sliding_window(model, x, size=size).argmax(1)[0].cpu().numpy()
        rows.append({"uid": it["uid"], "group": it["group"], "dice": dice_scores(pred, it["lab"])})
    model.train()
    return rows


def summarize(rows):
    out = {}
    for g in sorted({r["group"] for r in rows}) + ["all"]:
        rs = [r for r in rows if g == "all" or r["group"] == g]
        d = np.array([r["dice"] for r in rs], dtype=float)
        out[g] = [round(float(np.nanmean(d[:, k])), 4) for k in range(3)]
    return out


# ----------------------------------------------------------------------------- train
def train(args):
    torch.manual_seed(args.seed)
    np.random.seed(args.seed)
    rng = np.random.default_rng(args.seed)
    dev = torch.device(f"cuda:{args.gpu}")
    fold = "all" if args.fold == "all" else int(args.fold)
    # PATCH 大小：可用 --patch D H W 自定义，或 --patch-preset small|large
    patch = PATCH_PRESETS.get(args.patch_preset, PATCH)
    if args.patch:
        patch = tuple(int(v) for v in args.patch)
    tr_recs, va_recs = load_items(args.modality, fold)
    run = RUNS / f"seg_{args.modality}_f{args.fold}_{args.tag}"
    run.mkdir(parents=True, exist_ok=True)
    # 同一 run 只允许一个进程：两个 runner 从两端取折，靠锁避免重复训练
    lock = run / "LOCK"
    if (run / "train.log").exists() and "DONE" in (run / "train.log").read_text():
        print(f"skip {run.name}: already DONE")
        return
    if lock.exists():
        pid = int(lock.read_text() or 0)
        if pid and Path(f"/proc/{pid}").exists():
            print(f"skip {run.name}: running in pid {pid}")
            return
    if (run / "train.log").exists():
        (run / "train.log").rename(run / f"train.log.aborted.{int(time.time())}")
    lock.write_text(str(__import__("os").getpid()))
    (run / "config.json").write_text(json.dumps({**vars(args), "train": [r["uid"] for r in tr_recs],
                                                 "val": [r["uid"] for r in va_recs], "patch": list(patch)}, indent=1))
    log = open(run / "train.log", "a")

    def say(msg):
        line = f"[{time.strftime('%H:%M:%S')}] {msg}"
        print(line, flush=True)
        log.write(line + "\n")
        log.flush()

    tr, va = load_arrays(tr_recs), load_arrays(va_recs)
    say(f"modality={args.modality} fold={args.fold} train={len(tr)} val={len(va)} patch={patch}")

    model = UNet3D().to(dev)
    opt = torch.optim.SGD(model.parameters(), lr=args.lr, momentum=0.99, nesterov=True, weight_decay=3e-5)
    total = args.epochs * args.iters
    sched = torch.optim.lr_scheduler.LambdaLR(opt, lambda it: (1 - it / total) ** 0.9)
    big = [int(s * 1.25) for s in patch]
    step = 0
    for ep in range(args.epochs):
        t0, losses = time.time(), []
        for _ in range(args.iters):
            batch = [sample_patch(tr[rng.integers(len(tr))], rng, size=patch) for _ in range(args.batch)]
            img = torch.from_numpy(np.stack([b[0] for b in batch]))[:, None].to(dev)
            lab = torch.from_numpy(np.stack([b[1] for b in batch]))[:, None].to(dev)
            assert list(img.shape[2:]) == big
            img, lab = gpu_augment(img, lab, args.modality)
            with torch.autocast("cuda", dtype=torch.bfloat16):
                logits = model(img)
            logits = logits.float()
            loss = F.cross_entropy(logits, lab) + soft_dice_loss(logits, lab)
            opt.zero_grad(set_to_none=True)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 12)
            opt.step()
            sched.step()
            step += 1
            losses.append(loss.item())
        msg = f"ep {ep + 1}/{args.epochs} loss {np.mean(losses):.4f} lr {sched.get_last_lr()[0]:.2e} {time.time() - t0:.0f}s"
        if va and ((ep + 1) % args.val_every == 0 or ep + 1 == args.epochs):
            s = summarize(evaluate(model, va, dev, size=patch))
            msg += " val(liver,spleen,kidney) " + " ".join(f"{g}={v}" for g, v in s.items())
        say(msg)
        torch.save({"model": model.state_dict(), "epoch": ep + 1, "args": vars(args)}, run / "last.pt")

    if va:
        rows = evaluate(model, va, dev, size=patch)
        (run / "val_last.json").write_text(json.dumps({"rows": rows, "summary": summarize(rows)}, indent=1))
        say(f"FINAL val summary {summarize(rows)}")
    say("DONE")


def predict(args):
    """折外预测：配对病例用「没见过它」的折模型；测试病例用全量模型。

    输出 <out>/<case>_<mod>.nii.gz：3 通道（肝/脾/肾）softmax，规范网格几何。

    ``--fold all`` 强制所有配对病例都用全量模型（seg_{mod}_fall_*）。
    这不是折外口径，**不能**用于评估开发集；它存在的目的是在**无标签**的
    测试集上复现提交所用的模型配置，以及做域内消融（如 fp32 推理）。
    """
    import SimpleITK as sitk

    dev = torch.device(f"cuda:{args.gpu}")
    meta = json.loads((CACHE / "seg_1.5x1.5x3.0" / "meta.json").read_text())
    out = Path(args.out).expanduser()
    out.mkdir(parents=True, exist_ok=True)
    models: dict[str, UNet3D] = {}
    patch_sizes: dict[str, tuple] = {}
    for r in meta:
        uid = r["uid"]
        case, mod = uid.rsplit("_", 1)
        if mod != args.modality or not case.isdigit():
            continue
        fold = "all" if r["fold"] < 0 else str(r["fold"])
        if args.fold == "all":
            # 强制用全量模型（域内口径，仅用于测试集复现与消融）
            fold = "all"
        if fold not in models:
            # 多个 tag（不同种子）= 同折集成；每个成员都没见过本折病例，折外口径不变
            models[fold] = []
            # 按模态选择 tag：--ct-tags / --mr-tags 可覆盖 --tag（按模态设计集成）
            if args.ct_tags and mod == "ct":
                use_tags = list(args.ct_tags)
            elif args.mr_tags and mod == "mr":
                use_tags = list(args.mr_tags)
            else:
                use_tags = list(args.tag)
            for tag in use_tags:
                ck = RUNS / f"seg_{mod}_f{fold}_{tag}" / "last.pt"
                m = UNet3D().to(dev)
                blob = torch.load(ck, map_location=dev)
                m.load_state_dict(blob["model"])
                models[fold].append(m.eval())
                # 推理用的 patch 大小：优先取显式参数，否则读训练时的 config
                if args.patch:
                    psize = tuple(int(v) for v in args.patch)
                elif args.patch_preset != "auto":
                    psize = PATCH_PRESETS.get(args.patch_preset, PATCH)
                else:
                    cfg = RUNS / f"seg_{mod}_f{fold}_{tag}" / "config.json"
                    if cfg.exists():
                        p = json.loads(cfg.read_text()).get("patch")
                        psize = tuple(int(v) for v in p) if p else PATCH
                    else:
                        psize = PATCH
            patch_sizes[fold] = psize
        z = np.load(CACHE / "seg_1.5x1.5x3.0" / f"{uid}.npz")
        x = torch.from_numpy(z["img"].astype(np.float32))[None, None].to(dev)
        flips = tuple(args.tta) if args.tta else ()
        scales = tuple(float(s) for s in args.scales) if args.scales else (1.0,)
        psize = patch_sizes[fold]

        def infer(m):
            if scales and any(abs(s - 1.0) > 1e-6 for s in scales):
                return sliding_window_multiscale(m, x, size=psize, step=0.5,
                                                use_amp=not args.fp32, scales=scales)
            return sliding_window_tta(m, x, use_amp=not args.fp32, flips=flips, size=psize)

        prob = sum(infer(m) for m in models[fold])[0, 1:].cpu().numpy() / len(models[fold])  # (3,D,H,W)
        # uint8（概率×255）：64 个体积 float32 约 5GB，.14 磁盘放不下
        img = sitk.GetImageFromArray(np.round(np.moveaxis(prob, 0, -1) * 255).astype(np.uint8), isVector=True)
        img.SetOrigin(z["origin"].tolist())
        img.SetSpacing(z["spacing"].tolist())
        sitk.WriteImage(img, str(out / f"{case}_{mod}.nii.gz"))
        if z["lab"].size:
            d = dice_scores(np.where(prob.max(0) > 0.5, prob.argmax(0) + 1, 0), z["lab"])
            print(f"{uid} fold={fold} dice(liver,spleen,kidney)={[round(v, 3) for v in d]}", flush=True)
        else:
            print(f"{uid} fold={fold} (no label)", flush=True)


def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    pr = sub.add_parser("predict")
    pr.add_argument("--modality", choices=["ct", "mr"], required=True)
    pr.add_argument("--out", required=True)
    pr.add_argument("--gpu", type=int, default=0)
    pr.add_argument("--tag", nargs="+", default=["v1"], help="多个 tag 时按折平均概率（集成）")
    pr.add_argument("--fp32", action="store_true", help="fp32 推理（默认 bf16 autocast）；精度更高且可复现")
    pr.add_argument("--fold", default="auto", help="auto=折外口径；all=全部用全量模型（非折外，仅用于测试集复现/消融）")
    pr.add_argument(
        "--tta",
        nargs="*",
        default=[],
        choices=["lr", "ap"],
        help="翻转 TTA：lr=面内左右(H)，ap=前后(W)。不做 D 轴（上/下）翻转——"
        "腹部解剖非上下对称。默认关闭。",
    )
    pr.add_argument(
        "--patch",
        nargs=3,
        type=int,
        default=None,
        metavar=("D", "H", "W"),
        help="推理时的 patch 大小（体素）。默认读训练 config。",
    )
    pr.add_argument(
        "--patch-preset",
        default="auto",
        choices=["auto", *PATCH_PRESETS],
        help="auto=读训练 config；否则用预设（small/large）",
    )
    pr.add_argument(
        "--scales",
        nargs="*",
        type=float,
        default=[],
        help="多尺度 TTA：>1 表示放大物理视野后再滑窗（如 1.0 1.25 1.5）。"
        "不改解剖语义（不像左右翻转会破坏器官侧别）。",
    )
    pr.add_argument(
        "--ct-tags",
        nargs="+",
        default=None,
        help="CT 专用 tag 列表（等权集成）。给定后覆盖 --tag 中的 ct 部分。"
        "用于「按模态设计集成」：不同质量的模型混在一起会稀释（见结论 26）。",
    )
    pr.add_argument(
        "--mr-tags",
        nargs="+",
        default=None,
        help="MR 专用 tag 列表（等权集成）。给定后覆盖 --tag 中的 mr 部分。",
    )
    t = sub.add_parser("train")
    t.add_argument("--modality", choices=["ct", "mr"], required=True)
    t.add_argument("--fold", default="0", help="0..3 或 all")
    t.add_argument("--gpu", type=int, default=0)
    t.add_argument("--epochs", type=int, default=100)
    t.add_argument("--iters", type=int, default=250)
    t.add_argument("--batch", type=int, default=2)
    t.add_argument("--lr", type=float, default=0.01)
    t.add_argument("--val-every", type=int, default=10)
    t.add_argument("--seed", type=int, default=0)
    t.add_argument("--tag", default="v1")
    t.add_argument(
        "--patch",
        nargs=3,
        type=int,
        default=None,
        metavar=("D", "H", "W"),
        help=f"训练 patch 大小（体素）。预设: {PATCH_PRESETS}（large 可完整覆盖器官）",
    )
    t.add_argument("--patch-preset", default="small", choices=list(PATCH_PRESETS))
    args = ap.parse_args()
    if args.cmd == "train":
        assert args.fold == "all" or 0 <= int(args.fold) < N_FOLDS
        train(args)
    elif args.cmd == "predict":
        predict(args)


if __name__ == "__main__":
    main()
