"""VoxelMorph 式可变形配准网络 + 空间变换层。

约定（重要，贯穿训练 / 推理 / 提交）：

- 网络输入 ``x``：通道 0 = fixed（CT），通道 1 = moving（合成 CT）。
- 网络输出 ``flow``：形状 ``(N, 3, D, H, W)``，单位为 **体素（voxel）**，
  通道顺序为 ``(x, y, z)``，对应数组轴 ``(W, H, D)``。
- 语义：``p_moving = p_fixed + flow``，即把固定图坐标映射到浮动图坐标。
- ``SpatialTransformer.warp(src, flow)`` 采样 ``src`` 在 ``p_fixed + flow`` 处的值，
  因此 ``warp(moving, flow)`` 就是「把 moving 对齐到 fixed」后的图像。
"""
from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F

from ctmr.models.blocks import conv, upsample


class ConvBlock(nn.Module):
    def __init__(self, dim: int, in_ch: int, out_ch: int) -> None:
        super().__init__()
        self.block = nn.Sequential(
            conv(dim, in_ch, out_ch, kernel_size=3, padding=1),
            nn.LeakyReLU(0.2, inplace=True),
            conv(dim, out_ch, out_ch, kernel_size=3, padding=1),
            nn.LeakyReLU(0.2, inplace=True),
        )

    def forward(self, x):
        return self.block(x)


class VoxelMorphNet(nn.Module):
    """U-Net 编码器-解码器，输出 3 通道位移场。"""

    def __init__(
        self,
        dim: int = 3,
        in_ch: int = 2,
        enc: tuple[int, ...] | list[int] = (16, 32, 32, 32),
        dec: tuple[int, ...] | list[int] = (32, 32, 32, 16, 16),
        out_ch: int = 3,
    ) -> None:
        super().__init__()
        self.dim = dim
        enc = list(enc)
        dec = list(dec)

        self.enc = nn.ModuleList()
        for i, nf in enumerate(enc):
            self.enc.append(ConvBlock(dim, in_ch if i == 0 else enc[i - 1], nf))

        self.dec = nn.ModuleList()
        prev = enc[-1]
        for i, nf in enumerate(dec):
            skip_ch = enc[-2 - i] if i < len(enc) - 1 else 0
            self.dec.append(ConvBlock(dim, prev + skip_ch, nf))
            prev = nf

        self.flow = conv(dim, prev, out_ch, kernel_size=3, padding=1)
        self.pool = nn.AvgPool3d(2, 2, 0) if dim == 3 else nn.AvgPool2d(2, 2, 0)
        nn.init.zeros_(self.flow.weight)
        nn.init.zeros_(self.flow.bias)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        input_shape = x.shape[2:]
        skips: list[torch.Tensor] = []
        for i, block in enumerate(self.enc):
            x = block(x)
            if i < len(self.enc) - 1:
                skips.append(x)
                x = self.pool(x)

        for i, block in enumerate(self.dec):
            x = upsample(self.dim, 2)(x)
            if i < len(skips):
                skip = skips[-(i + 1)]
                if x.shape[2:] != skip.shape[2:]:
                    x = F.interpolate(
                        x, size=skip.shape[2:], mode=_mode(self.dim), align_corners=False
                    )
                x = torch.cat([x, skip], dim=1)
            x = block(x)

        flow = self.flow(x)
        if flow.shape[2:] != input_shape:
            flow = F.interpolate(flow, size=input_shape, mode=_mode(self.dim), align_corners=False)
        return flow


def _mode(dim: int) -> str:
    return "trilinear" if dim == 3 else "bilinear"


class SpatialTransformer(nn.Module):
    """按位移场对图像做重采样（2D / 3D）。"""

    def __init__(self, dim: int = 3) -> None:
        super().__init__()
        self.dim = dim

    def forward(self, src: torch.Tensor, flow: torch.Tensor) -> torch.Tensor:
        return self._warp3d(src, flow) if self.dim == 3 else self._warp2d(src, flow)

    @staticmethod
    def _warp2d(src: torch.Tensor, flow: torch.Tensor) -> torch.Tensor:
        n, _, h, w = src.shape
        device, dtype = src.device, src.dtype
        yy = torch.arange(h, device=device, dtype=dtype).view(1, h, 1).expand(n, h, w)
        xx = torch.arange(w, device=device, dtype=dtype).view(1, 1, w).expand(n, h, w)
        grid_x = xx + flow[:, 0]
        grid_y = yy + flow[:, 1]
        grid_x = 2.0 * grid_x / max(w - 1, 1) - 1.0
        grid_y = 2.0 * grid_y / max(h - 1, 1) - 1.0
        grid = torch.stack([grid_x, grid_y], dim=-1)
        return F.grid_sample(src, grid, mode="bilinear", padding_mode="border", align_corners=True)

    @staticmethod
    def _warp3d(src: torch.Tensor, flow: torch.Tensor) -> torch.Tensor:
        n, _, d, h, w = src.shape
        device, dtype = src.device, src.dtype
        zz = torch.arange(d, device=device, dtype=dtype).view(1, d, 1, 1).expand(n, d, h, w)
        yy = torch.arange(h, device=device, dtype=dtype).view(1, 1, h, 1).expand(n, d, h, w)
        xx = torch.arange(w, device=device, dtype=dtype).view(1, 1, 1, w).expand(n, d, h, w)
        grid_x = xx + flow[:, 0]
        grid_y = yy + flow[:, 1]
        grid_z = zz + flow[:, 2]
        grid_x = 2.0 * grid_x / max(w - 1, 1) - 1.0
        grid_y = 2.0 * grid_y / max(h - 1, 1) - 1.0
        grid_z = 2.0 * grid_z / max(d - 1, 1) - 1.0
        grid = torch.stack([grid_x, grid_y, grid_z], dim=-1)
        return F.grid_sample(src, grid, mode="bilinear", padding_mode="border", align_corners=True)


def build_registration_net(
    dim: int = 3,
    in_ch: int = 2,
    enc: tuple[int, ...] | list[int] = (16, 32, 32, 32),
    dec: tuple[int, ...] | list[int] = (32, 32, 32, 16, 16),
) -> VoxelMorphNet:
    return VoxelMorphNet(dim=dim, in_ch=in_ch, enc=enc, dec=dec, out_ch=3)
