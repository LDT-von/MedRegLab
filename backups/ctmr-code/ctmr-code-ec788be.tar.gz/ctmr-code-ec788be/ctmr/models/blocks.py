"""按维度选择 2D/3D 的基础算子与权重初始化。"""
from __future__ import annotations

import torch.nn as nn

_CONV = {2: nn.Conv2d, 3: nn.Conv3d}
_NORM = {2: nn.InstanceNorm2d, 3: nn.InstanceNorm3d}
_PAD = {2: nn.ReflectionPad2d, 3: nn.ReflectionPad3d}
_POOL = {2: nn.AvgPool2d, 3: nn.AvgPool3d}
_INTERP_MODE = {2: "bilinear", 3: "trilinear"}


def conv(dim: int, *args, **kwargs) -> nn.Module:
    if dim not in _CONV:
        raise ValueError(f"dim 只支持 2 或 3，收到 {dim}")
    return _CONV[dim](*args, **kwargs)


def norm(dim: int, channels: int, affine: bool = True) -> nn.Module:
    """InstanceNorm（不跟踪 running stats，适合小 batch）。"""
    return _NORM[dim](channels, affine=affine, track_running_stats=False)


def reflection_pad(dim: int, pad: int) -> nn.Module:
    return _PAD[dim](pad)


def avg_pool(dim: int, kernel_size: int, stride: int | None = None, padding: int = 0) -> nn.Module:
    return _POOL[dim](kernel_size, stride, padding)


def upsample(dim: int, scale_factor: int = 2) -> nn.Module:
    return nn.Upsample(scale_factor=scale_factor, mode=_INTERP_MODE[dim], align_corners=False)


def init_weights(module: nn.Module) -> None:
    """CycleGAN 常用初始化：卷积正态 0.02，归一化权重 1、偏置 0。"""
    classname = module.__class__.__name__
    if "Conv" in classname:
        nn.init.normal_(module.weight.data, 0.0, 0.02)
        if getattr(module, "bias", None) is not None:
            nn.init.constant_(module.bias.data, 0.0)
    elif "InstanceNorm" in classname or "BatchNorm" in classname:
        if module.affine:
            nn.init.constant_(module.weight.data, 1.0)
            nn.init.constant_(module.bias.data, 0.0)
