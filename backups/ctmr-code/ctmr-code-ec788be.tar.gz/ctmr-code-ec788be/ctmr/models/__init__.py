"""网络定义。"""
from ctmr.models.blocks import avg_pool, conv, init_weights, norm, reflection_pad, upsample
from ctmr.models.cyclegan import (
    PatchDiscriminator,
    ResnetBlock,
    ResnetGenerator,
    build_discriminator,
    build_generator,
)
from ctmr.models.translation import translate_volume
from ctmr.models.voxelmorph import (
    ConvBlock,
    SpatialTransformer,
    VoxelMorphNet,
    build_registration_net,
)

__all__ = [
    "avg_pool",
    "conv",
    "init_weights",
    "norm",
    "reflection_pad",
    "upsample",
    "PatchDiscriminator",
    "ResnetBlock",
    "ResnetGenerator",
    "build_discriminator",
    "build_generator",
    "translate_volume",
    "ConvBlock",
    "SpatialTransformer",
    "VoxelMorphNet",
    "build_registration_net",
]
