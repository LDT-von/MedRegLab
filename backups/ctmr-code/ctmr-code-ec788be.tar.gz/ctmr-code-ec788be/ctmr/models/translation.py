"""把 2D CycleGAN 生成器应用到整幅 3D 体积（逐切片）。"""
from __future__ import annotations

import torch


def translate_volume(
    generator: torch.nn.Module,
    volume: torch.Tensor,
    dim: int,
    axis: int = 0,
) -> torch.Tensor:
    """对体积做模态翻译。

    参数
    ----
    generator : 生成器（输入/输出均为 ``(N, C, ...)``）
    volume    : ``(N, C, D, H, W)`` 的 3D 张量
    dim       : 生成器维度；3 表示直接 3D 前向，2 表示逐切片
    axis      : dim==2 时切片方向（0/1/2 对应 D/H/W）
    """
    if dim == 3:
        return generator(volume)

    axis = axis % 3
    n_slices = volume.shape[2 + axis]
    outputs: list[torch.Tensor] = []
    for i in range(n_slices):
        index = [slice(None)] * 5
        index[2 + axis] = i
        outputs.append(generator(volume[tuple(index)]))
    return torch.stack(outputs, dim=2 + axis)
