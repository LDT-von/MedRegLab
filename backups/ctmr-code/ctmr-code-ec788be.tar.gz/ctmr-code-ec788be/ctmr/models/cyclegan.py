"""CycleGAN 网络（2D / 3D 可切换）。

- 生成器：ResNet 结构（7x7 首尾卷积 + 两次下采样 + N 个残差块 + 两次上采样）。
- 判别器：PatchGAN。

用于方案二的 MR→CT 翻译：``G_AB: MR -> 合成 CT``，``G_BA: CT -> 合成 MR``。
"""
from __future__ import annotations

import torch.nn as nn

from ctmr.models.blocks import conv, norm, reflection_pad, upsample


class ResnetBlock(nn.Module):
    def __init__(self, dim: int = 2, in_ch: int = 64, mid_ch: int | None = None, out_ch: int | None = None) -> None:
        super().__init__()
        mid_ch = mid_ch or in_ch
        out_ch = out_ch or in_ch
        self.block = nn.Sequential(
            reflection_pad(dim, 1),
            conv(dim, in_ch, mid_ch, kernel_size=3, stride=1, padding=0),
            norm(dim, mid_ch),
            nn.ReLU(inplace=True),
            reflection_pad(dim, 1),
            conv(dim, mid_ch, out_ch, kernel_size=3, stride=1, padding=0),
            norm(dim, out_ch),
        )

    def forward(self, x):
        return x + self.block(x)


class ResnetGenerator(nn.Module):
    """ResNet 生成器。输入输出均为单通道（可配）。"""

    def __init__(
        self,
        dim: int = 2,
        in_ch: int = 1,
        out_ch: int = 1,
        base: int = 64,
        n_blocks: int = 6,
    ) -> None:
        super().__init__()
        self.dim = dim
        layers: list[nn.Module] = [
            reflection_pad(dim, 3),
            conv(dim, in_ch, base, kernel_size=7, stride=1, padding=0),
            norm(dim, base),
            nn.ReLU(inplace=True),
        ]
        mult = base
        for _ in range(2):
            prev = mult
            mult *= 2
            layers += [
                conv(dim, prev, mult, kernel_size=3, stride=2, padding=1),
                norm(dim, mult),
                nn.ReLU(inplace=True),
            ]
        for _ in range(n_blocks):
            layers.append(ResnetBlock(dim, mult))
        for _ in range(2):
            prev = mult
            mult //= 2
            layers += [
                upsample(dim, 2),
                conv(dim, prev, mult, kernel_size=3, stride=1, padding=1),
                norm(dim, mult),
                nn.ReLU(inplace=True),
            ]
        layers += [
            reflection_pad(dim, 3),
            conv(dim, mult, out_ch, kernel_size=7, stride=1, padding=0),
            nn.Tanh(),
        ]
        self.model = nn.Sequential(*layers)

    def forward(self, x):
        return self.model(x)


class PatchDiscriminator(nn.Module):
    """PatchGAN 判别器，输出每个 patch 的真假 logit。"""

    def __init__(self, dim: int = 2, in_ch: int = 1, base: int = 64, n_layers: int = 3) -> None:
        super().__init__()
        self.dim = dim
        layers: list[nn.Module] = [
            conv(dim, in_ch, base, kernel_size=4, stride=2, padding=1),
            nn.LeakyReLU(0.2, inplace=True),
        ]
        mult = 1
        for n in range(1, n_layers):
            prev = base * mult
            mult = min(2 ** n, 8)
            layers += [
                conv(dim, prev, base * mult, kernel_size=4, stride=2, padding=1),
                norm(dim, base * mult),
                nn.LeakyReLU(0.2, inplace=True),
            ]
        prev = base * mult
        mult = min(2 ** n_layers, 8)
        layers += [
            conv(dim, prev, base * mult, kernel_size=4, stride=2, padding=1),
            norm(dim, base * mult),
            nn.LeakyReLU(0.2, inplace=True),
            conv(dim, base * mult, 1, kernel_size=4, stride=1, padding=1),
        ]
        self.model = nn.Sequential(*layers)

    def forward(self, x):
        return self.model(x)


def build_generator(dim: int, in_ch: int = 1, out_ch: int = 1, base: int = 64, n_blocks: int = 6) -> ResnetGenerator:
    return ResnetGenerator(dim=dim, in_ch=in_ch, out_ch=out_ch, base=base, n_blocks=n_blocks)


def build_discriminator(dim: int, in_ch: int = 1, base: int = 64, n_layers: int = 3) -> PatchDiscriminator:
    return PatchDiscriminator(dim=dim, in_ch=in_ch, base=base, n_layers=n_layers)
