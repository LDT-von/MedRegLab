"""推理入口。

具体实现见 ``ctmr.inference.predict``。这里不在包初始化时导入，避免
``python -m ctmr.inference.predict`` 触发 "found in sys.modules" 告警。
"""
