"""推理：为测试集生成可直接提交的位移场。

方案二流程::

    MR --(CycleGAN G_AB)--> 合成 CT --(配准网络)--> 位移场

位移场单位是物理毫米、几何与 ``ct.nii`` 完全一致，可直接打包提交。
"""
from __future__ import annotations

import argparse
import json
from datetime import datetime
from pathlib import Path

import numpy as np
import SimpleITK as sitk
import torch

from ctmr.data.datasets import discover_case_dirs, find_image
from ctmr.data.io import from_array, read_image, to_array, write_image
from ctmr.data.preprocess import normalize_array, resample_to_reference
from ctmr.models.cyclegan import build_generator
from ctmr.models.translation import translate_volume
from ctmr.models.voxelmorph import build_registration_net
from ctmr.utils.config import apply_overrides, load_config
from ctmr.utils.device import resolve_device
from ctmr.utils.field import canonicalize_field, make_displacement_field, validate_field
from ctmr.utils.logging import setup_logging


def load_generator(ckpt_path: str | Path, device: torch.device):
    checkpoint = torch.load(str(ckpt_path), map_location="cpu")
    kwargs = checkpoint.get("generator_kwargs") or {"dim": int(checkpoint.get("dim", 2))}
    generator = build_generator(**kwargs)
    generator.load_state_dict(checkpoint["g_ab"])
    generator.to(device).eval()
    return generator, int(kwargs.get("dim", 2))


def load_registration(ckpt_path: str | Path, device: torch.device):
    checkpoint = torch.load(str(ckpt_path), map_location="cpu")
    kwargs = dict(checkpoint.get("model_kwargs") or {"dim": int(checkpoint.get("dim", 3))})
    model = build_registration_net(**kwargs)
    model.load_state_dict(checkpoint["model"])
    model.to(device).eval()
    return model


def zero_field(ct_img: sitk.Image) -> sitk.Image:
    zeros = np.zeros((3,) + tuple(to_array(ct_img).shape), dtype=np.float32)
    field = make_displacement_field(zeros, ct_img, apply_direction=False)
    return canonicalize_field(field, ct_img)


def classical_field(fixed_img: sitk.Image, moving_img: sitk.Image) -> sitk.Image:
    """SimpleITK Demons 兜底配准（合成 CT vs 真实 CT）。"""
    fixed = sitk.Cast(fixed_img, sitk.sitkFloat32)
    moving = sitk.Cast(moving_img, sitk.sitkFloat32)
    demons = sitk.DemonsRegistrationFilter()
    demons.SetNumberOfIterations(60)
    demons.SetStandardDeviations(1.0)
    demons.SetSmoothDisplacementField(True)
    demons.SetSmoothUpdateField(True)
    demons.Execute(fixed, moving)
    return demons.GetDisplacementField()


def predict_field(
    ct_img: sitk.Image,
    mr_img: sitk.Image,
    generator,
    gen_dim: int,
    model,
    device: torch.device,
    method: str = "learned",
    axis: int = 0,
) -> sitk.Image:
    mr_aligned = resample_to_reference(mr_img, ct_img)
    ct_array = normalize_array(to_array(ct_img))
    mr_array = normalize_array(to_array(mr_aligned))

    ct_tensor = torch.from_numpy(ct_array)[None, None].float().to(device)
    mr_tensor = torch.from_numpy(mr_array)[None, None].float().to(device)

    with torch.no_grad():
        synthetic = translate_volume(generator, mr_tensor, gen_dim, axis) if generator is not None else mr_tensor

        if method == "classical":
            fixed_img = from_array(ct_array, ct_img)
            synthetic_img = from_array(synthetic[0, 0].cpu().numpy(), ct_img)
            return canonicalize_field(classical_field(fixed_img, synthetic_img), ct_img)

        flow = model(torch.cat([ct_tensor, synthetic], dim=1))

    flow_array = flow[0].detach().cpu().numpy()
    field = make_displacement_field(flow_array, ct_img, apply_direction=True)
    return canonicalize_field(field, ct_img)


def main() -> None:
    parser = argparse.ArgumentParser(description="生成测试集位移场")
    parser.add_argument("--config", nargs="+", default=["configs/base.yaml", "configs/registration.yaml"])
    parser.add_argument("--override", nargs="*", default=[])
    parser.add_argument("--test-root", default=None, help="测试集根目录（含 <case>/ct.nii.gz, mr.nii.gz）")
    parser.add_argument("--cases", nargs="*", default=None, help="只处理指定病例编号")
    parser.add_argument("--translation-ckpt", default=None, help="CycleGAN 权重（MR->CT）")
    parser.add_argument("--registration-ckpt", required=True, help="配准网络权重")
    parser.add_argument("--method", choices=["learned", "classical"], default="learned")
    parser.add_argument("--axis", type=int, default=None, help="2D 翻译时切片方向")
    parser.add_argument("--out", default=None)
    parser.add_argument("--device", default=None)
    args = parser.parse_args()

    cfg = apply_overrides(load_config(*args.config), args.override)
    device = resolve_device(args.device or str(cfg.runtime.device))

    out_dir = Path(args.out) if args.out else Path(cfg.experiment.output_root) / "outputs" / f"predict_{datetime.now():%Y%m%d_%H%M%S}"
    logger = setup_logging(log_file=out_dir / "predict.log")

    test_root = Path(args.test_root) if args.test_root else Path(cfg.paths.data_root) / "test"
    if not test_root.exists():
        raise SystemExit(f"测试集目录不存在: {test_root}")

    gen_dim = 2
    generator = None
    if args.translation_ckpt:
        generator, gen_dim = load_generator(args.translation_ckpt, device)
        logger.info("已加载翻译生成器（dim=%d）: %s", gen_dim, args.translation_ckpt)
    else:
        logger.warning("未提供 --translation-ckpt，将直接把 MR 当作合成 CT 配准")

    model = load_registration(args.registration_ckpt, device)
    logger.info("已加载配准网络: %s（device=%s）", args.registration_ckpt, device)

    axis = args.axis if args.axis is not None else int(getattr(cfg, "translation", {}).get("axis", 0))

    case_dirs = discover_case_dirs(test_root)
    if args.cases:
        wanted = set(args.cases)
        case_dirs = [d for d in case_dirs if d.name in wanted]
    if not case_dirs:
        raise SystemExit(f"在 {test_root} 未找到测试病例")

    logger.info("待处理病例：%s", ", ".join(d.name for d in case_dirs))

    for case_dir in case_dirs:
        ct_img = read_image(find_image(case_dir, "ct"))
        mr_img = read_image(find_image(case_dir, "mr"))
        try:
            field = predict_field(ct_img, mr_img, generator, gen_dim, model, device, args.method, axis)
            issues = validate_field(field, ct_img)
        except Exception as exc:  # noqa: BLE001 - 单例失败用零场兜底，保证提交完整
            logger.exception("%s: 推理失败，回退零位移场 (%s)", case_dir.name, exc)
            field = zero_field(ct_img)
            issues = ["推理失败，已回退零位移场"]

        case_out = out_dir / case_dir.name
        write_image(field, case_out / "displacement_field.nii.gz")

        meta = {"case_id": case_dir.name, "method": args.method, "issues": issues}
        (case_out / "meta.json").write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")

        logger.info("%s: 已写入位移场（问题：%s）", case_dir.name, "; ".join(issues) if issues else "无")

    logger.info("全部完成，输出目录：%s", out_dir)


if __name__ == "__main__":
    main()
