"""CPU 自检：随机张量前向 + 位移场几何回环。

在没有真实数据、没有 GPU 的机器上也能验证脚手架是否正确：

    python -m ctmr.selftest

重点验证「体素位移 -> 物理毫米位移场 -> SimpleITK 重采样」的语义是否与
``p_mr = p_ct + D(p_ct)`` 一致。
"""
from __future__ import annotations

import sys

import numpy as np
import SimpleITK as sitk
import torch

from ctmr.data.io import from_array, to_array
from ctmr.losses.gan import adversarial_loss
from ctmr.losses.registration import gradient_loss, ncc_loss
from ctmr.models.cyclegan import build_discriminator, build_generator
from ctmr.models.voxelmorph import SpatialTransformer, build_registration_net
from ctmr.utils.field import (
    apply_displacement_field,
    canonicalize_field,
    flow_voxel_to_mm,
    make_displacement_field,
    validate_field,
)


def test_cyclegan_2d() -> None:
    generator = build_generator(dim=2, base=8, n_blocks=1)
    discriminator = build_discriminator(dim=2, base=8, n_layers=2)
    x = torch.randn(2, 1, 64, 64)
    y = generator(x)
    assert y.shape == x.shape, y.shape
    pred = discriminator(y)
    assert pred.shape[:2] == (2, 1), pred.shape
    assert torch.isfinite(adversarial_loss(pred, True)).all()


def test_cyclegan_3d() -> None:
    generator = build_generator(dim=3, base=8, n_blocks=1)
    x = torch.randn(1, 1, 32, 32, 32)
    y = generator(x)
    assert y.shape == x.shape, y.shape


def test_voxelmorph() -> None:
    model = build_registration_net(dim=3, enc=(8, 16, 16, 16), dec=(16, 16, 8, 8, 8))
    x = torch.randn(1, 2, 32, 32, 32)
    flow = model(x)
    assert flow.shape == (1, 3, 32, 32, 32), flow.shape
    warped = SpatialTransformer(3)(x[:, 1:2], flow)
    assert warped.shape == (1, 1, 32, 32, 32)


def test_losses() -> None:
    a = torch.randn(1, 1, 16, 16, 16)
    b = torch.randn(1, 1, 16, 16, 16)
    assert torch.isfinite(ncc_loss(a, b, win=5))
    flow = torch.randn(1, 3, 16, 16, 16) * 0.1
    assert torch.isfinite(gradient_loss(flow))


def test_identity_warp() -> None:
    x = torch.randn(1, 1, 16, 16, 16)
    flow = torch.zeros(1, 3, 16, 16, 16)
    assert torch.allclose(SpatialTransformer(3)(x, flow), x, atol=1e-5)


def test_flow_scaling() -> None:
    flow = np.zeros((3, 4, 5, 6), dtype=np.float32)
    flow[0] = 2.0
    flow[1] = 3.0
    flow[2] = 4.0
    mm = flow_voxel_to_mm(flow, spacing=(1.0, 2.0, 3.0))
    assert mm.shape == (4, 5, 6, 3)
    assert np.allclose(mm[0, 0, 0], [2.0, 6.0, 12.0]), mm[0, 0, 0]


def test_field_roundtrip() -> None:
    """位移 +2 体素（x 方向）应当等价于数组沿最后一维左移 2。"""
    size = (32, 40, 48)  # SimpleITK 顺序 (x, y, z) -> 数组 (z, y, x)
    spacing = (1.0, 2.0, 3.0)
    ct = sitk.Image(list(size), sitk.sitkFloat32)
    ct.SetSpacing(list(spacing))

    arr = np.zeros((48, 40, 32), dtype=np.float32)
    arr[20:28, 18:22, 14:18] = 1.0
    label = from_array(arr, ct)

    flow = np.zeros((3, 48, 40, 32), dtype=np.float32)
    flow[0] = 2.0  # +2 体素，沿 x（数组最后一维）

    field = canonicalize_field(make_displacement_field(flow, ct, apply_direction=True), ct)
    issues = validate_field(field, ct)
    assert not issues, issues

    warped = apply_displacement_field(label, field, ct, is_label=True)
    got = to_array(warped)
    expected = np.roll(arr, -2, axis=-1)

    region = (slice(18, 30), slice(16, 24), slice(10, 28))
    assert np.allclose(got[region], expected[region], atol=1e-4), "位移场方向/单位不一致"


def main() -> int:
    tests = [
        ("CycleGAN 2D 前向", test_cyclegan_2d),
        ("CycleGAN 3D 前向", test_cyclegan_3d),
        ("VoxelMorph 前向 + 变换", test_voxelmorph),
        ("配准损失有限性", test_losses),
        ("零位移 = 恒等变换", test_identity_warp),
        ("体素->毫米缩放", test_flow_scaling),
        ("位移场几何回环", test_field_roundtrip),
    ]
    failed = 0
    for name, fn in tests:
        try:
            fn()
            print(f"[PASS] {name}")
        except Exception as exc:  # noqa: BLE001
            failed += 1
            print(f"[FAIL] {name}: {exc}")
    print("-" * 50)
    print(f"{len(tests) - failed}/{len(tests)} 项通过")
    return 0 if failed == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
