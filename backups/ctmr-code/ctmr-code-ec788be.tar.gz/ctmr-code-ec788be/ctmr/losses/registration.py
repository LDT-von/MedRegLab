"""配准损失：局部 NCC、位移场平滑、Dice（标签弱监督）。"""
from __future__ import annotations

import torch
import torch.nn.functional as F


def _avg_pool_same(x: torch.Tensor, kernel: int) -> torch.Tensor:
    """与输入同尺寸的局部均值池化（窗口内有效像素归一化）。"""
    if x.dim() == 5:
        return F.avg_pool3d(x, kernel_size=kernel, stride=1, padding=kernel // 2, count_include_pad=False)
    return F.avg_pool2d(x, kernel_size=kernel, stride=1, padding=kernel // 2, count_include_pad=False)


def ncc_loss(y_true: torch.Tensor, y_pred: torch.Tensor, win: int = 9, eps: float = 1e-5) -> torch.Tensor:
    """局部归一化互相关损失（越小越相似），支持 2D/3D。"""
    i_sum = _avg_pool_same(y_pred, win)
    j_sum = _avg_pool_same(y_true, win)
    i2_sum = _avg_pool_same(y_pred * y_pred, win)
    j2_sum = _avg_pool_same(y_true * y_true, win)
    ij_sum = _avg_pool_same(y_pred * y_true, win)

    cross = ij_sum - i_sum * j_sum
    i_var = i2_sum - i_sum * i_sum
    j_var = j2_sum - j_sum * j_sum
    denom = torch.sqrt(torch.clamp(i_var, min=0.0) * torch.clamp(j_var, min=0.0) + eps)
    ncc = cross / denom
    return 1.0 - ncc.mean()


def gradient_loss(flow: torch.Tensor, squared: bool = False) -> torch.Tensor:
    """位移场一阶差分平滑项（越小越平滑）。"""
    if flow.dim() == 5:
        diffs = [
            flow[:, :, 1:, :, :] - flow[:, :, :-1, :, :],
            flow[:, :, :, 1:, :] - flow[:, :, :, :-1, :],
            flow[:, :, :, :, 1:] - flow[:, :, :, :, :-1],
        ]
    elif flow.dim() == 4:
        diffs = [
            flow[:, :, 1:, :] - flow[:, :, :-1, :],
            flow[:, :, :, 1:] - flow[:, :, :, :-1],
        ]
    else:
        raise ValueError(f"flow 维度应为 4 或 5，收到 {flow.dim()}")

    terms = [d.pow(2).mean() if squared else d.abs().mean() for d in diffs]
    return torch.stack(terms).mean()


def dice_loss(pred_prob: torch.Tensor, target: torch.Tensor, eps: float = 1e-5) -> torch.Tensor:
    """多通道 Dice 损失；pred_prob / target 形状 ``(N, C, ...)``。"""
    dims = tuple(range(2, pred_prob.dim()))
    intersection = (pred_prob * target).sum(dim=dims)
    denominator = pred_prob.sum(dim=dims) + target.sum(dim=dims)
    dice = (2.0 * intersection + eps) / (denominator + eps)
    return 1.0 - dice.mean()


def bending_energy(flow: torch.Tensor) -> torch.Tensor:
    """二阶平滑（bending energy），用于可选的更强正则。"""
    if flow.dim() == 5:
        d2 = [
            flow[:, :, 2:, :, :] - 2 * flow[:, :, 1:-1, :, :] + flow[:, :, :-2, :, :],
            flow[:, :, :, 2:, :] - 2 * flow[:, :, :, 1:-1, :] + flow[:, :, :, :-2, :],
            flow[:, :, :, :, 2:] - 2 * flow[:, :, :, :, 1:-1] + flow[:, :, :, :, :-2],
        ]
    elif flow.dim() == 4:
        d2 = [
            flow[:, :, 2:, :] - 2 * flow[:, :, 1:-1, :] + flow[:, :, :-2, :],
            flow[:, :, :, 2:] - 2 * flow[:, :, :, 1:-1] + flow[:, :, :, :-2],
        ]
    else:
        raise ValueError(f"flow 维度应为 4 或 5，收到 {flow.dim()}")
    return torch.stack([d.pow(2).mean() for d in d2]).mean()
