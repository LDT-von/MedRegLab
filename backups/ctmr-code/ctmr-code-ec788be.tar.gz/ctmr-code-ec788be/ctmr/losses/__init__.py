"""损失函数。"""
from ctmr.losses.gan import adversarial_loss, cycle_consistency_loss, identity_loss
from ctmr.losses.registration import (
    bending_energy,
    dice_loss,
    gradient_loss,
    ncc_loss,
)

__all__ = [
    "adversarial_loss",
    "cycle_consistency_loss",
    "identity_loss",
    "bending_energy",
    "dice_loss",
    "gradient_loss",
    "ncc_loss",
]
