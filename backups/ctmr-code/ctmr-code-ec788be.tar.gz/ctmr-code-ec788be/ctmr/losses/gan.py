"""CycleGAN 损失：对抗损失、循环一致性、身份损失。"""
from __future__ import annotations

import torch
import torch.nn.functional as F


def adversarial_loss(pred: torch.Tensor, is_real: bool, kind: str = "lsgan") -> torch.Tensor:
    """LSGAN（MSE）或 BCE 对抗损失。"""
    target = torch.ones_like(pred) if is_real else torch.zeros_like(pred)
    if kind == "lsgan":
        return F.mse_loss(pred, target)
    if kind == "bce":
        return F.binary_cross_entropy_with_logits(pred, target)
    raise ValueError(f"未知对抗损失类型: {kind}")


def cycle_consistency_loss(reconstructed: torch.Tensor, original: torch.Tensor) -> torch.Tensor:
    return F.l1_loss(reconstructed, original)


def identity_loss(same_domain: torch.Tensor, original: torch.Tensor) -> torch.Tensor:
    return F.l1_loss(same_domain, original)
