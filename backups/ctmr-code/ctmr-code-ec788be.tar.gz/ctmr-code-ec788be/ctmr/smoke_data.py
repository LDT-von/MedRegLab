"""生成极小的合成 CT/MR 数据，用于端到端冒烟测试（不需要真实数据）。

用法::

    python -m ctmr.smoke_data --out data_smoke

生成结构::

    data_smoke/paired/{001,002,003}/{ct,mr,label_ct,label_mr}.nii.gz
    data_smoke/unpaired/ct/*.nii.gz
    data_smoke/unpaired/mr/*.nii.gz
    data_smoke/test/{025,026}/{ct,mr}.nii.gz
"""
from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import SimpleITK as sitk
from scipy.ndimage import gaussian_filter

from ctmr.data.io import from_array, write_image

SHAPE = (24, 48, 48)  # (z, y, x)
SPACING = (1.0, 1.5, 2.0)


def _reference() -> sitk.Image:
    image = sitk.Image([SHAPE[2], SHAPE[1], SHAPE[0]], sitk.sitkFloat32)
    image.SetSpacing(list(SPACING))
    image.SetOrigin([0.0, 0.0, 0.0])
    image.SetDirection([1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0])
    return image


def _make_arrays(seed: int, shift: int) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    rng = np.random.default_rng(seed)
    z, y, x = np.indices(SHAPE)

    label = np.zeros(SHAPE, dtype=np.uint8)
    label[((z - 12) / 6) ** 2 + ((y - 16) / 10) ** 2 + ((x - 18) / 12) ** 2 <= 1] = 1  # 肝
    label[((z - 12) / 5) ** 2 + ((y - 16) / 8) ** 2 + ((x - 36) / 7) ** 2 <= 1] = 2   # 脾
    label[((z - 12) / 4) ** 2 + ((y - 36) / 6) ** 2 + ((x - 24) / 6) ** 2 <= 1] = 3   # 肾

    ct = 0.1 + 0.25 * (label == 1) + 0.35 * (label == 2) + 0.2 * (label == 3)
    ct = gaussian_filter(ct, 1.0) + 0.02 * rng.normal(size=SHAPE)

    mr = 0.9 - 0.4 * (label == 1) - 0.5 * (label == 2) - 0.3 * (label == 3)
    mr = gaussian_filter(mr, 1.5) + 0.02 * rng.normal(size=SHAPE)

    mr = np.roll(mr, shift, axis=-1)
    label_mr = np.roll(label, shift, axis=-1)
    return ct.astype(np.float32), mr.astype(np.float32), label, label_mr


def _write_pair(
    out_dir: Path,
    case_id: str,
    seed: int,
    shift: int,
    with_labels: bool,
    subdir: str = "paired",
) -> None:
    reference = _reference()
    ct, mr, label, label_mr = _make_arrays(seed, shift)
    case_dir = out_dir / subdir / case_id
    write_image(from_array(ct, reference), case_dir / "ct.nii.gz")
    write_image(from_array(mr, reference), case_dir / "mr.nii.gz")
    if with_labels:
        write_image(from_array(label, reference), case_dir / "label_ct.nii.gz")
        write_image(from_array(label_mr, reference), case_dir / "label_mr.nii.gz")


def main() -> None:
    parser = argparse.ArgumentParser(description="生成合成冒烟数据")
    parser.add_argument("--out", default="data_smoke")
    args = parser.parse_args()

    out = Path(args.out)
    for index, case_id in enumerate(["001", "002", "003"]):
        _write_pair(out, case_id, seed=index, shift=3 + index, with_labels=True)

    reference = _reference()
    for index in range(4):
        ct, mr, _, _ = _make_arrays(100 + index, shift=index)
        write_image(from_array(ct, reference), out / "unpaired" / "ct" / f"ct_{index:02d}.nii.gz")
        write_image(from_array(mr, reference), out / "unpaired" / "mr" / f"mr_{index:02d}.nii.gz")

    for index, case_id in enumerate(["025", "026"]):
        _write_pair(out, case_id, seed=200 + index, shift=4 + index, with_labels=False, subdir="test")

    print(f"合成数据已生成: {out.resolve()}")


if __name__ == "__main__":
    main()
