"""位移场工具：体素流 <-> 物理毫米位移场，以及校验、应用。

提交规范关键点（对应赛题文档二）：
- 单位是 **物理坐标（毫米）**，不是体素索引；
- 语义：``p_mr = p_ct + D(p_ct)``；
- size / spacing / origin / direction 必须与 ``ct.nii`` **完全一致**；
- 推荐用 SimpleITK 的 ``TransformToDisplacementField`` 生成，而非手工拼四维数组。
"""
from __future__ import annotations

import numpy as np
import SimpleITK as sitk

from ctmr.data.io import same_geometry


def flow_voxel_to_mm(
    flow: np.ndarray,
    spacing: tuple[float, float, float],
    direction: tuple[float, ...] | None = None,
) -> np.ndarray:
    """把 ``(3, D, H, W)`` 的体素位移（通道 x,y,z）转成 ``(D, H, W, 3)`` 的物理毫米位移。

    注意数组空间轴是 ``(D, H, W) = (z, y, x)``，而 flow 通道是 ``(x, y, z)``，
    因此通道 0 乘的是 spacing[0]（x 方向）。
    """
    flow = np.asarray(flow, dtype=np.float64)
    if flow.ndim != 4 or flow.shape[0] != 3:
        raise ValueError(f"flow 形状应为 (3, D, H, W)，收到 {flow.shape}")

    sx, sy, sz = spacing
    disp_index = np.stack([flow[0] * sx, flow[1] * sy, flow[2] * sz], axis=-1)

    if direction is not None:
        matrix = np.asarray(direction, dtype=np.float64).reshape(3, 3)
        disp_index = disp_index @ matrix.T

    return disp_index.astype(np.float32)


def make_displacement_field(
    flow: np.ndarray,
    reference_image: sitk.Image,
    apply_direction: bool = False,
) -> sitk.Image:
    """由体素位移场构造 SimpleITK 位移场图像（几何与参考图一致）。"""
    disp = flow_voxel_to_mm(
        flow,
        reference_image.GetSpacing(),
        reference_image.GetDirection() if apply_direction else None,
    )
    field = sitk.GetImageFromArray(disp, isVector=True)
    field.CopyInformation(reference_image)
    return field


def canonicalize_field(field: sitk.Image, reference_image: sitk.Image) -> sitk.Image:
    """用 ``TransformToDisplacementField`` 规范化，保证几何与参考图完全一致。

    注意：SimpleITK 的 ``DisplacementFieldTransform`` 只接受 ``vector float64``，
    因此内部先做 Cast；输出仍用 float32（赛题推荐、体积更小）。
    """
    transform = sitk.DisplacementFieldTransform(sitk.Cast(field, sitk.sitkVectorFloat64))
    return sitk.TransformToDisplacementField(
        transform,
        sitk.sitkVectorFloat32,
        reference_image.GetSize(),
        reference_image.GetOrigin(),
        reference_image.GetSpacing(),
        reference_image.GetDirection(),
    )


def apply_displacement_field(
    moving: sitk.Image,
    field: sitk.Image,
    reference: sitk.Image,
    is_label: bool = True,
) -> sitk.Image:
    """把 ``moving`` 按位移场变换到 ``reference`` 空间。

    位移场语义 ``p_moving = p_fixed + D``，与 ``DisplacementFieldTransform`` 一致。
    """
    transform = sitk.DisplacementFieldTransform(sitk.Cast(field, sitk.sitkVectorFloat64))
    interpolator = sitk.sitkNearestNeighbor if is_label else sitk.sitkLinear
    return sitk.Resample(moving, reference, transform, interpolator, 0.0, moving.GetPixelID())


def validate_field(field: sitk.Image, reference: sitk.Image, tol: float = 1e-4) -> list[str]:
    """提交前自检，返回问题列表（空列表 = 通过）。"""
    issues: list[str] = []

    if field.GetDimension() != 3:
        issues.append(f"维度应为 3，实际 {field.GetDimension()}")
    if field.GetNumberOfComponentsPerPixel() != 3:
        issues.append(f"分量数应为 3，实际 {field.GetNumberOfComponentsPerPixel()}")
    if field.GetSize() != reference.GetSize():
        issues.append(f"size 不一致: {field.GetSize()} vs {reference.GetSize()}")
    if not same_geometry(field, reference, tol=tol):
        issues.append("spacing/origin/direction 与参考图不一致")

    pixel_id = field.GetPixelID()
    if pixel_id not in (sitk.sitkVectorFloat32, sitk.sitkVectorFloat64):
        issues.append(f"数据类型应为 float32/float64，实际 pixel id={pixel_id}")

    array = sitk.GetArrayFromImage(field)
    if not np.isfinite(array).all():
        issues.append("位移场含 NaN 或 Inf")

    return issues
