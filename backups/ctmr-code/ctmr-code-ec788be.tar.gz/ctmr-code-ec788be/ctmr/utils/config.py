"""配置加载：多份 YAML 深合并 + 属性式访问 + 命令行覆盖。"""
from __future__ import annotations

import copy
from pathlib import Path
from typing import Any, Mapping

import yaml


class DotDict(dict):
    """支持 ``cfg.train.epochs`` 这种属性访问的 dict（递归）。"""

    def __getattr__(self, key: str) -> Any:
        try:
            return self[key]
        except KeyError as exc:  # pragma: no cover - 属性错误路径
            raise AttributeError(key) from exc

    def __setattr__(self, key: str, value: Any) -> None:
        self[key] = value

    def __delattr__(self, key: str) -> None:
        try:
            del self[key]
        except KeyError as exc:  # pragma: no cover
            raise AttributeError(key) from exc


def _to_dot(obj: Any) -> Any:
    if isinstance(obj, Mapping):
        return DotDict({k: _to_dot(v) for k, v in obj.items()})
    if isinstance(obj, list):
        return [_to_dot(v) for v in obj]
    return obj


def to_plain(obj: Any) -> Any:
    """把 DotDict / 嵌套结构转成纯 dict/list，便于 yaml 落盘。"""
    if isinstance(obj, Mapping):
        return {k: to_plain(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [to_plain(v) for v in obj]
    return obj


def deep_merge(base: Mapping, override: Mapping) -> dict:
    out = copy.deepcopy(dict(base))
    for key, val in override.items():
        if key in out and isinstance(out[key], Mapping) and isinstance(val, Mapping):
            out[key] = deep_merge(out[key], val)
        else:
            out[key] = copy.deepcopy(val)
    return out


def load_config(*paths: str | Path, overrides: Mapping | None = None) -> DotDict:
    """按顺序深合并多个 YAML，后者覆盖前者；``overrides`` 最后覆盖。"""
    cfg: dict = {}
    for path in paths:
        p = Path(path)
        if not p.exists():
            raise FileNotFoundError(f"配置文件不存在: {p.resolve()}")
        with open(p, "r", encoding="utf-8") as fh:
            data = yaml.safe_load(fh) or {}
        cfg = deep_merge(cfg, data)
    if overrides:
        cfg = deep_merge(cfg, overrides)
    return _to_dot(cfg)


def save_config(cfg: Mapping, path: str | Path) -> None:
    """把最终生效配置落盘，便于复现。"""
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    with open(p, "w", encoding="utf-8") as fh:
        yaml.safe_dump(to_plain(cfg), fh, allow_unicode=True, sort_keys=False)


def apply_overrides(cfg: DotDict, pairs: list[str]) -> DotDict:
    """应用 ``a.b=1 c.d=foo`` 形式的命令行覆盖。"""
    for pair in pairs:
        if "=" not in pair:
            raise ValueError(f"覆盖项格式应为 key=value，收到: {pair}")
        key, raw = pair.split("=", 1)
        node: Any = cfg
        parts = key.split(".")
        for part in parts[:-1]:
            if part not in node or not isinstance(node[part], Mapping):
                node[part] = DotDict()
            node = node[part]
        node[parts[-1]] = yaml.safe_load(raw)
    return cfg
