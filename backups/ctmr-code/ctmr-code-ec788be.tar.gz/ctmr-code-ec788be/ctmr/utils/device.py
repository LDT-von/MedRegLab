"""设备选择。"""
from __future__ import annotations

import torch


def resolve_device(preference: str = "auto") -> torch.device:
    """auto: 有 CUDA 用 CUDA，否则 CPU（MPS 对 grid_sample 支持不稳，默认避开）。"""
    if preference == "cpu":
        return torch.device("cpu")
    if preference == "cuda":
        return torch.device("cuda" if torch.cuda.is_available() else "cpu")
    if preference == "mps":
        return torch.device("mps" if torch.backends.mps.is_available() else "cpu")
    return torch.device("cuda" if torch.cuda.is_available() else "cpu")
