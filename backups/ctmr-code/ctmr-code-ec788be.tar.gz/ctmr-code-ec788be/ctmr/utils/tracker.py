"""实验记录器：把每个方案/变体的分数逐条写入 ``docs/``。

产出两个文件：
- ``docs/experiments.csv``  : 机器可读，便于后续脚本汇总/画图。
- ``docs/EXPERIMENTS.md``   : 人读的 Markdown 表格，追加式。
"""
from __future__ import annotations

import csv
from datetime import datetime
from pathlib import Path
from typing import Any

CSV_FIELDS = [
    "timestamp",
    "scheme",
    "run_id",
    "dataset",
    "n_cases",
    "dsc",
    "dsc30",
    "notes",
    "config",
    "log",
    "checkpoint",
]

MD_HEADER = (
    "# 实验记录（EXPERIMENTS）\n\n"
    "> 本文件由 `ctmr/utils/tracker.py` 自动追加。每跑完一个方案/变体，"
    "新增一条记录，并在 `experiments.csv` 中留一行。\n"
    "> 字段：时间 / 方案 / run_id / 数据集 / 病例数 / DSC / DSC30 / 备注 / 配置 / 日志 / 权重。\n\n"
)


class ExperimentTracker:
    """管理 `docs/` 下的实验记录。"""

    def __init__(self, doc_dir: str | Path = "docs") -> None:
        self.dir = Path(doc_dir)
        self.dir.mkdir(parents=True, exist_ok=True)
        self.csv_path = self.dir / "experiments.csv"
        self.md_path = self.dir / "EXPERIMENTS.md"
        self._ensure()

    def _ensure(self) -> None:
        if not self.csv_path.exists():
            with open(self.csv_path, "w", newline="", encoding="utf-8") as fh:
                csv.DictWriter(fh, fieldnames=CSV_FIELDS).writeheader()
        if not self.md_path.exists():
            self.md_path.write_text(MD_HEADER, encoding="utf-8")

    @staticmethod
    def _fmt(value: Any) -> Any:
        if value is None:
            return ""
        if isinstance(value, float):
            return f"{value:.4f}"
        return value

    def record(
        self,
        scheme: str,
        run_id: str,
        dsc: float | None = None,
        dsc30: float | None = None,
        dataset: str = "",
        n_cases: int | None = None,
        notes: str = "",
        config: str = "",
        log: str = "",
        checkpoint: str = "",
    ) -> dict:
        """追加一条实验记录，返回写入的 row。"""
        row = {
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "scheme": scheme,
            "run_id": run_id,
            "dataset": dataset,
            "n_cases": "" if n_cases is None else n_cases,
            "dsc": self._fmt(dsc),
            "dsc30": self._fmt(dsc30),
            "notes": notes,
            "config": config,
            "log": log,
            "checkpoint": checkpoint,
        }
        with open(self.csv_path, "a", newline="", encoding="utf-8") as fh:
            csv.DictWriter(fh, fieldnames=CSV_FIELDS).writerow(row)
        self._append_md(row)
        return row

    def note(self, text: str) -> None:
        """在 Markdown 末尾追加一段自由文本（用于记录踩坑/结论）。"""
        self.md_path.parent.mkdir(parents=True, exist_ok=True)
        with open(self.md_path, "a", encoding="utf-8") as fh:
            fh.write("\n" + text.rstrip() + "\n")

    def _append_md(self, row: dict) -> None:
        text = self.md_path.read_text(encoding="utf-8")
        if "| 时间 |" not in text:
            with open(self.md_path, "a", encoding="utf-8") as fh:
                fh.write("| 时间 | 方案 | run_id | 数据集 | 病例数 | DSC | DSC30 | 备注 |\n")
                fh.write("|---|---|---|---|---|---|---|---|\n")
        line = (
            f"| {row['timestamp']} | {row['scheme']} | {row['run_id']} | {row['dataset']} | "
            f"{row['n_cases']} | {row['dsc']} | {row['dsc30']} | {row['notes']} |\n"
        )
        with open(self.md_path, "a", encoding="utf-8") as fh:
            fh.write(line)
