"""提交打包与自检。

生成 ``submission.zip``，内部结构::

    submission/025/displacement_field.nii.gz
    submission/026/displacement_field.nii.gz
    ...

同时校验每个位移场的维度、分量数、几何一致性、NaN/Inf。
"""
from __future__ import annotations

import argparse
import zipfile
from pathlib import Path

from ctmr.data.datasets import find_image
from ctmr.data.io import read_image
from ctmr.utils.field import validate_field
from ctmr.utils.logging import setup_logging


def validate_case(field_path: Path, ct_path: Path) -> list[str]:
    field = read_image(field_path)
    ct = read_image(ct_path)
    return validate_field(field, ct)


def make_submission_zip(
    pred_root: str | Path,
    out_zip: str | Path,
    data_root: str | Path | None = None,
    case_ids: list[str] | None = None,
) -> list[str]:
    """打包并返回问题列表（空 = 通过）。"""
    pred_root = Path(pred_root)
    out_zip = Path(out_zip)
    out_zip.parent.mkdir(parents=True, exist_ok=True)

    case_dirs = sorted([d for d in pred_root.iterdir() if d.is_dir()])
    if case_ids is not None:
        case_dirs = [d for d in case_dirs if d.name in set(case_ids)]
    if not case_dirs:
        return [f"预测目录下没有任何病例子目录: {pred_root}"]

    issues: list[str] = []
    found: set[str] = set()

    with zipfile.ZipFile(out_zip, "w", zipfile.ZIP_DEFLATED) as zf:
        for case_dir in case_dirs:
            field_path = case_dir / "displacement_field.nii.gz"
            if not field_path.exists():
                issues.append(f"{case_dir.name}: 缺少 displacement_field.nii.gz")
                continue

            if data_root is not None:
                ct_path = find_image(Path(data_root) / case_dir.name, "ct")
                if ct_path is None:
                    issues.append(f"{case_dir.name}: 在 {data_root} 下找不到 ct")
                else:
                    for problem in validate_case(field_path, ct_path):
                        issues.append(f"{case_dir.name}: {problem}")

            zf.write(field_path, arcname=f"submission/{case_dir.name}/displacement_field.nii.gz")
            found.add(case_dir.name)

    if case_ids is not None:
        for case_id in case_ids:
            if case_id not in found:
                issues.append(f"{case_id}: 未包含在压缩包中")

    return issues


def main() -> None:
    parser = argparse.ArgumentParser(description="打包提交 zip 并自检")
    parser.add_argument("--pred-root", required=True, help="含 <case>/displacement_field.nii.gz 的目录")
    parser.add_argument("--out", required=True, help="输出 zip 路径")
    parser.add_argument("--data-root", default=None, help="测试集原始目录（含 <case>/ct.nii.gz），用于几何自检")
    parser.add_argument("--cases", nargs="*", default=None, help="期望包含的病例编号")
    args = parser.parse_args()

    logger = setup_logging()
    issues = make_submission_zip(args.pred_root, args.out, args.data_root, args.cases)

    if issues:
        logger.warning("自检发现 %d 个问题：", len(issues))
        for issue in issues:
            logger.warning("  - %s", issue)
    else:
        logger.info("自检通过：几何、维度、分量、NaN/Inf 均正常")

    size_mb = Path(args.out).stat().st_size / 1024 / 1024
    logger.info("已生成 %s（%.2f MB）", args.out, size_mb)


if __name__ == "__main__":
    main()
