"""在带标签的验证集上评估位移场，计算 DSC / DSC30，并可写入 ``docs/``。

用法::

    python -m ctmr.eval.evaluate \
        --pred-root experiments/outputs/reg_run \
        --data-root data_prepared/paired \
        --scheme cyclegan --run-id reg_run --record
"""
from __future__ import annotations

import argparse
import csv
from pathlib import Path

import numpy as np

from ctmr.data.datasets import find_label
from ctmr.data.io import read_image, to_array
from ctmr.data.preprocess import resample_to_reference
from ctmr.eval.metrics import case_dice, summarize
from ctmr.utils.field import apply_displacement_field, validate_field
from ctmr.utils.logging import setup_logging
from ctmr.utils.tracker import ExperimentTracker


def evaluate_case(case_dir: Path, field_path: Path):
    """返回 (器官 Dice 字典, 位移场问题列表)。"""
    ct_label_path = find_label(case_dir, "ct")
    mr_label_path = find_label(case_dir, "mr")
    if ct_label_path is None or mr_label_path is None:
        raise FileNotFoundError(f"{case_dir} 缺少 CT 或 MR 标签")

    ct_label_img = read_image(ct_label_path)
    mr_label_img = read_image(mr_label_path)
    if mr_label_img.GetSize() != ct_label_img.GetSize():
        mr_label_img = resample_to_reference(mr_label_img, ct_label_img, is_label=True)

    field = read_image(field_path)
    issues = validate_field(field, ct_label_img)

    warped = apply_displacement_field(mr_label_img, field, ct_label_img, is_label=True)
    pred = np.asarray(to_array(warped)).astype(np.int64)
    gt = np.asarray(to_array(ct_label_img)).astype(np.int64)
    return case_dice(pred, gt), issues


def main() -> None:
    parser = argparse.ArgumentParser(description="评估位移场的器官 Dice / DSC30")
    parser.add_argument("--pred-root", required=True, help="每个子目录含 displacement_field.nii.gz")
    parser.add_argument("--data-root", default="data_prepared/paired", help="含 label_ct / label_mr 的病例目录")
    parser.add_argument("--cases", nargs="*", default=None, help="只评估指定病例编号")
    parser.add_argument("--output-csv", default=None)
    parser.add_argument("--doc-dir", default="docs")
    parser.add_argument("--scheme", default="cyclegan")
    parser.add_argument("--run-id", default="")
    parser.add_argument("--notes", default="")
    parser.add_argument("--config-path", default="")
    parser.add_argument("--log", default="")
    parser.add_argument("--checkpoint", default="")
    parser.add_argument("--record", action="store_true", help="把结果写入 docs/ 实验记录")
    args = parser.parse_args()

    pred_root = Path(args.pred_root)
    data_root = Path(args.data_root)
    logger = setup_logging(log_file=f"{args.doc_dir}/eval.log")

    if not pred_root.exists():
        raise SystemExit(f"预测目录不存在: {pred_root}")
    if not data_root.exists():
        raise SystemExit(f"数据目录不存在: {data_root}")

    wanted = set(args.cases) if args.cases else None
    rows: list[dict] = []

    for case_dir in sorted([d for d in data_root.iterdir() if d.is_dir()]):
        if wanted and case_dir.name not in wanted:
            continue
        field_path = pred_root / case_dir.name / "displacement_field.nii.gz"
        if not field_path.exists():
            logger.warning("%s: 未找到位移场，跳过", case_dir.name)
            continue
        try:
            scores, issues = evaluate_case(case_dir, field_path)
        except Exception as exc:  # noqa: BLE001 - 单例失败不应中断整体评估
            logger.error("%s: 评估失败 (%s)", case_dir.name, exc)
            continue

        row = {"case_id": case_dir.name, **scores, "issues": "; ".join(issues)}
        rows.append(row)
        if issues:
            logger.warning("%s: %s", case_dir.name, "; ".join(issues))

    if not rows:
        raise SystemExit("没有可评估的病例（检查 --pred-root / --data-root）")

    rows.sort(key=lambda r: r["mean"])
    summary = summarize(r["mean"] for r in rows)

    logger.info("=" * 76)
    logger.info("%-8s %-8s %-8s %-8s %-8s", "case", "liver", "spleen", "kidney", "mean")
    for row in rows:
        logger.info(
            "%-8s %-8.4f %-8.4f %-8.4f %-8.4f",
            row["case_id"], row["liver"], row["spleen"], row["kidney"], row["mean"],
        )
    logger.info("-" * 76)
    logger.info(
        "DSC = %.4f | DSC30 = %.4f（最差 %d/%d 例）| 最好 %.4f | 最差 %.4f",
        summary["dsc"], summary["dsc30"], summary["dsc30_cases"], summary["n_cases"],
        summary["best"], summary["worst"],
    )
    logger.info("=" * 76)

    out_csv = Path(args.output_csv) if args.output_csv else pred_root / "eval_results.csv"
    out_csv.parent.mkdir(parents=True, exist_ok=True)
    with open(out_csv, "w", newline="", encoding="utf-8") as fh:
        writer = csv.DictWriter(fh, fieldnames=["case_id", "liver", "spleen", "kidney", "mean", "issues"])
        writer.writeheader()
        writer.writerows(rows)
    logger.info("逐例结果已写入 %s", out_csv)

    if args.record:
        tracker = ExperimentTracker(args.doc_dir)
        tracker.record(
            scheme=args.scheme,
            run_id=args.run_id or pred_root.name,
            dsc=summary["dsc"],
            dsc30=summary["dsc30"],
            dataset=str(data_root),
            n_cases=summary["n_cases"],
            notes=args.notes,
            config=args.config_path,
            log=args.log,
            checkpoint=args.checkpoint,
        )
        logger.info("已写入实验记录：%s/experiments.csv", args.doc_dir)


if __name__ == "__main__":
    main()
