"""评分：器官 Dice、DSC30。

标签定义（赛题）：0 背景 / 1 肝脏 / 2 脾脏 / 3 肾脏。
其中 001–008 的双肾分别为 3 和 4，因此肾脏按 ``3 或 4`` 合并统计。

空器官规则：若 CT 中该器官不存在（``|A| = 0``），该器官 DSC 记为 1.0。
"""
from __future__ import annotations

import math
from typing import Iterable

import numpy as np

ORGAN_LABELS: dict[str, tuple[int, ...]] = {
    "liver": (1,),
    "spleen": (2,),
    "kidney": (3, 4),
}


def dice_for_organ(pred_mask: np.ndarray, gt_mask: np.ndarray, eps: float = 1e-8) -> float:
    """单个器官的 Dice；CT 中缺失该器官时返回 1.0。"""
    gt_size = int(gt_mask.sum())
    pred_size = int(pred_mask.sum())
    if gt_size == 0:
        return 1.0
    if pred_size == 0:
        return 0.0
    inter = int(np.logical_and(pred_mask, gt_mask).sum())
    return float(2.0 * inter / (gt_size + pred_size + eps))


def case_dice(pred: np.ndarray, gt: np.ndarray) -> dict[str, float]:
    """单病例三器官 Dice 及均值。"""
    scores: dict[str, float] = {}
    for organ, labels in ORGAN_LABELS.items():
        pred_mask = np.isin(pred, labels)
        gt_mask = np.isin(gt, labels)
        scores[organ] = dice_for_organ(pred_mask, gt_mask)
    scores["mean"] = float(np.mean([scores[o] for o in ORGAN_LABELS]))
    return scores


def dsc30(case_scores: Iterable[float]) -> tuple[float, int]:
    """最差 30% 病例的均值（向上取整），返回 (分数, 取用的病例数)。"""
    values = sorted(float(v) for v in case_scores)
    n = len(values)
    if n == 0:
        return 0.0, 0
    k = max(1, math.ceil(0.3 * n))
    return float(np.mean(values[:k])), k


def summarize(case_means: Iterable[float]) -> dict[str, float | int]:
    values = [float(v) for v in case_means]
    if not values:
        return {"dsc": 0.0, "dsc30": 0.0, "n_cases": 0, "dsc30_cases": 0, "best": 0.0, "worst": 0.0}
    robust, k = dsc30(values)
    return {
        "dsc": float(np.mean(values)),
        "dsc30": robust,
        "n_cases": len(values),
        "dsc30_cases": k,
        "best": float(np.max(values)),
        "worst": float(np.min(values)),
    }
