"""训练 CycleGAN（MR <-> CT 无配对翻译）。

用法::

    python -m ctmr.train.train_cyclegan --config configs/base.yaml configs/cyclegan.yaml

产物::

    experiments/runs/<run_id>/train.log
    experiments/runs/<run_id>/metrics.csv
    experiments/runs/<run_id>/checkpoints/latest.pt   # 含 g_ab（MR->CT）
"""
from __future__ import annotations

import argparse
import json
import time
from datetime import datetime
from pathlib import Path

import torch
from torch.utils.data import DataLoader

from ctmr.data.datasets import SliceDataset, collect_images
from ctmr.losses.gan import adversarial_loss, cycle_consistency_loss, identity_loss
from ctmr.models.blocks import init_weights
from ctmr.models.cyclegan import build_discriminator, build_generator
from ctmr.utils.config import apply_overrides, load_config, save_config, to_plain
from ctmr.utils.device import resolve_device
from ctmr.utils.logging import setup_logging


def _seed_all(seed: int) -> None:
    import random

    import numpy as np

    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def _infinite(loader):
    while True:
        yield from loader


def main() -> None:
    parser = argparse.ArgumentParser(description="训练 CycleGAN（MR <-> CT）")
    parser.add_argument("--config", nargs="+", default=["configs/base.yaml", "configs/cyclegan.yaml"])
    parser.add_argument("--override", nargs="*", default=[])
    parser.add_argument("--max-steps", type=int, default=None, help="每个 epoch 的步数上限（调试用）")
    parser.add_argument("--epochs", type=int, default=None)
    args = parser.parse_args()

    cfg = apply_overrides(load_config(*args.config), args.override)
    _seed_all(int(cfg.experiment.seed))
    device = resolve_device(str(cfg.runtime.device))

    run_id = f"{cfg.experiment.name}_cyclegan_{datetime.now():%Y%m%d_%H%M%S}"
    run_dir = Path(cfg.experiment.output_root) / "runs" / run_id
    logger = setup_logging(log_file=run_dir / "train.log")
    logger.info("run_id=%s device=%s", run_id, device)
    save_config(cfg, run_dir / "config.yaml")

    mr_files = collect_images(cfg.data.cyclegan.mr_dir)
    ct_files = collect_images(cfg.data.cyclegan.ct_dir)
    logger.info("MR 体积 %d 个；CT 体积 %d 个", len(mr_files), len(ct_files))
    if not mr_files or not ct_files:
        raise SystemExit("未找到未配对 MR/CT 图像，请先运行 `python -m ctmr.data.prepare` 或检查配置路径")

    batch_size = int(cfg.train.batch_size)
    n_steps = int(args.max_steps or cfg.train.n_steps_per_epoch or 200)
    epochs = int(args.epochs or cfg.train.epochs)

    ds_mr = SliceDataset(
        mr_files, axis=int(cfg.data.axis),
        samples_per_epoch=max(n_steps * batch_size, 512), seed=int(cfg.experiment.seed),
    )
    ds_ct = SliceDataset(
        ct_files, axis=int(cfg.data.axis),
        samples_per_epoch=max(n_steps * batch_size, 512), seed=int(cfg.experiment.seed) + 1,
    )
    num_workers = int(cfg.runtime.num_workers)
    pin = device.type == "cuda"
    loader_mr = DataLoader(ds_mr, batch_size=batch_size, shuffle=True, num_workers=num_workers, drop_last=True, pin_memory=pin)
    loader_ct = DataLoader(ds_ct, batch_size=batch_size, shuffle=True, num_workers=num_workers, drop_last=True, pin_memory=pin)

    dim = int(cfg.model.dim)
    base = int(cfg.model.generator.base)
    n_blocks = int(cfg.model.generator.n_blocks)
    disc_base = int(cfg.model.discriminator.base)
    disc_layers = int(cfg.model.discriminator.n_layers)

    g_kwargs = {"dim": dim, "in_ch": 1, "out_ch": 1, "base": base, "n_blocks": n_blocks}
    G_AB = build_generator(**g_kwargs).to(device)
    G_BA = build_generator(**g_kwargs).to(device)
    D_A = build_discriminator(dim=dim, in_ch=1, base=disc_base, n_layers=disc_layers).to(device)
    D_B = build_discriminator(dim=dim, in_ch=1, base=disc_base, n_layers=disc_layers).to(device)
    for module in (G_AB, G_BA, D_A, D_B):
        module.apply(init_weights)

    logger.info(
        "生成器 %.2fM 参数，判别器 %.2fM 参数",
        sum(p.numel() for p in G_AB.parameters()) / 1e6,
        sum(p.numel() for p in D_A.parameters()) / 1e6,
    )

    lr = float(cfg.train.lr)
    beta1 = float(cfg.train.beta1)
    opt_G = torch.optim.Adam(list(G_AB.parameters()) + list(G_BA.parameters()), lr=lr, betas=(beta1, 0.999))
    opt_D = torch.optim.Adam(list(D_A.parameters()) + list(D_B.parameters()), lr=lr, betas=(beta1, 0.999))

    use_amp = bool(cfg.runtime.amp) and device.type == "cuda"
    scaler = None
    if use_amp:
        try:
            scaler = torch.amp.GradScaler("cuda", enabled=True)
        except TypeError:  # 兼容老版本 torch
            scaler = torch.cuda.amp.GradScaler(enabled=True)

    kind = str(cfg.train.gan_kind)
    lam_cycle = float(cfg.train.lambda_cycle)
    lam_identity = float(cfg.train.lambda_identity)
    log_every = int(cfg.train.log_interval)
    save_every = int(cfg.train.save_every)

    ckpt_dir = run_dir / "checkpoints"
    ckpt_dir.mkdir(parents=True, exist_ok=True)
    metrics_file = open(run_dir / "metrics.csv", "w", encoding="utf-8")
    metrics_file.write("epoch,step,loss_g,loss_d,loss_adv,loss_cycle,loss_id\n")
    metrics_file.flush()

    it_mr, it_ct = _infinite(loader_mr), _infinite(loader_ct)
    global_step = 0
    start = time.time()

    for epoch in range(1, epochs + 1):
        for _ in range(n_steps):
            real_mr = next(it_mr).to(device, non_blocking=True)
            real_ct = next(it_ct).to(device, non_blocking=True)

            opt_G.zero_grad(set_to_none=True)
            with torch.autocast(device_type=device.type, dtype=torch.float16, enabled=use_amp):
                fake_ct = G_AB(real_mr)
                rec_mr = G_BA(fake_ct)
                fake_mr = G_BA(real_ct)
                rec_ct = G_AB(fake_mr)
                id_ct = G_AB(real_ct)
                id_mr = G_BA(real_mr)

                loss_adv = adversarial_loss(D_A(fake_ct), True, kind) + adversarial_loss(D_B(fake_mr), True, kind)
                loss_cycle = cycle_consistency_loss(rec_mr, real_mr) + cycle_consistency_loss(rec_ct, real_ct)
                loss_id = identity_loss(id_ct, real_ct) + identity_loss(id_mr, real_mr)
                loss_g = loss_adv + lam_cycle * loss_cycle + lam_identity * loss_id

            if scaler is not None:
                scaler.scale(loss_g).backward()
                scaler.step(opt_G)
            else:
                loss_g.backward()
                opt_G.step()

            opt_D.zero_grad(set_to_none=True)
            with torch.no_grad():
                fake_ct_detached = G_AB(real_mr).detach()
                fake_mr_detached = G_BA(real_ct).detach()
            with torch.autocast(device_type=device.type, dtype=torch.float16, enabled=use_amp):
                loss_d = 0.5 * (
                    adversarial_loss(D_A(real_ct), True, kind)
                    + adversarial_loss(D_A(fake_ct_detached), False, kind)
                )
                loss_d = loss_d + 0.5 * (
                    adversarial_loss(D_B(real_mr), True, kind)
                    + adversarial_loss(D_B(fake_mr_detached), False, kind)
                )

            if scaler is not None:
                scaler.scale(loss_d).backward()
                scaler.step(opt_D)
                scaler.update()
            else:
                loss_d.backward()
                opt_D.step()

            global_step += 1
            if global_step % log_every == 0:
                logger.info(
                    "epoch %d step %d | G %.4f (adv %.4f cycle %.4f id %.4f) | D %.4f",
                    epoch, global_step, loss_g.item(), loss_adv.item(),
                    loss_cycle.item(), loss_id.item(), loss_d.item(),
                )
                metrics_file.write(
                    f"{epoch},{global_step},{loss_g.item():.6f},{loss_d.item():.6f},"
                    f"{loss_adv.item():.6f},{loss_cycle.item():.6f},{loss_id.item():.6f}\n"
                )
                metrics_file.flush()

        if save_every > 0 and epoch % save_every == 0:
            checkpoint = {
                "g_ab": G_AB.state_dict(),
                "g_ba": G_BA.state_dict(),
                "d_a": D_A.state_dict(),
                "d_b": D_B.state_dict(),
                "dim": dim,
                "generator_kwargs": g_kwargs,
                "config": to_plain(cfg),
                "epoch": epoch,
            }
            torch.save(checkpoint, ckpt_dir / f"cyclegan_epoch{epoch:03d}.pt")
            torch.save(checkpoint, ckpt_dir / "latest.pt")
            logger.info("已保存权重: %s", ckpt_dir / "latest.pt")

    metrics_file.close()
    elapsed = time.time() - start
    meta = {
        "run_id": run_id, "device": str(device), "epochs": epochs,
        "steps_per_epoch": n_steps, "elapsed_sec": round(elapsed, 1), "torch": torch.__version__,
    }
    (run_dir / "run_meta.json").write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
    logger.info("训练完成，用时 %.1fs。输出目录：%s", elapsed, run_dir)


if __name__ == "__main__":
    main()
