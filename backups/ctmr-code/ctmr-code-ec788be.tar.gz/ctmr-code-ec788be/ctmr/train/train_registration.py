"""训练配准网络（方案二：CT vs 合成 CT 的单模态配准）。

流程：``MR --(CycleGAN G_AB)--> 合成 CT``，再训练 VoxelMorph 式网络把合成 CT
对齐到真实 CT，输出「固定图(CT) -> 浮动图(MR)」的位移场。

用法::

    python -m ctmr.train.train_registration --config configs/base.yaml configs/registration.yaml
"""
from __future__ import annotations

import argparse
import json
import time
from datetime import datetime
from pathlib import Path

import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader

from ctmr.data.datasets import PairedDataset, discover_paired
from ctmr.losses.registration import dice_loss, gradient_loss, ncc_loss
from ctmr.models.cyclegan import build_generator
from ctmr.models.translation import translate_volume
from ctmr.models.voxelmorph import SpatialTransformer, build_registration_net
from ctmr.utils.config import apply_overrides, load_config, save_config, to_plain
from ctmr.utils.device import resolve_device
from ctmr.utils.logging import setup_logging

NUM_CLASSES = 5  # 0 背景 / 1 肝 / 2 脾 / 3 肾 / 4 肾（001-008 双肾）


def _seed_all(seed: int) -> None:
    import random

    import numpy as np

    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def _infinite(loader):
    while True:
        yield from loader


def _resolve_translator(cfg, device):
    trans_cfg = getattr(cfg, "translation", None)
    if not trans_cfg or not bool(trans_cfg.get("enabled", False)):
        return None, 2
    ckpt_path = trans_cfg.get("ckpt")
    if not ckpt_path:
        raise SystemExit("translation.enabled=true 但未配置 translation.ckpt")
    checkpoint = torch.load(str(ckpt_path), map_location="cpu")
    kwargs = checkpoint.get("generator_kwargs") or {"dim": int(checkpoint.get("dim", 2))}
    generator = build_generator(**kwargs)
    generator.load_state_dict(checkpoint["g_ab"])
    generator.to(device).eval()
    for param in generator.parameters():
        param.requires_grad_(False)
    return generator, int(kwargs.get("dim", 2))


def main() -> None:
    parser = argparse.ArgumentParser(description="训练 VoxelMorph 式配准网络")
    parser.add_argument("--config", nargs="+", default=["configs/base.yaml", "configs/registration.yaml"])
    parser.add_argument("--override", nargs="*", default=[])
    parser.add_argument("--max-steps", type=int, default=None)
    parser.add_argument("--epochs", type=int, default=None)
    args = parser.parse_args()

    cfg = apply_overrides(load_config(*args.config), args.override)
    _seed_all(int(cfg.experiment.seed))
    device = resolve_device(str(cfg.runtime.device))

    run_id = f"{cfg.experiment.name}_registration_{datetime.now():%Y%m%d_%H%M%S}"
    run_dir = Path(cfg.experiment.output_root) / "runs" / run_id
    logger = setup_logging(log_file=run_dir / "train.log")
    logger.info("run_id=%s device=%s", run_id, device)
    save_config(cfg, run_dir / "config.yaml")

    cases = discover_paired(cfg.data.paired.root)
    logger.info("配对病例 %d 例（%s）", len(cases), cfg.data.paired.root)
    if not cases:
        raise SystemExit("未找到配对病例，请先运行 `python -m ctmr.data.prepare --mode paired`")

    dim = int(cfg.registration.model.dim)
    enc = tuple(cfg.registration.model.enc)
    dec = tuple(cfg.registration.model.dec)
    patch_size = cfg.registration.get("patch_size")
    patch_size = tuple(patch_size) if patch_size else None
    win = int(cfg.loss.ncc_win)
    w_ncc = float(cfg.loss.w_ncc)
    w_smooth = float(cfg.loss.w_smooth)
    w_dice = float(cfg.loss.w_dice)

    if patch_size and any(p % 8 != 0 for p in patch_size):
        logger.warning("patch_size %s 不是 8 的倍数，可能因多次池化导致尺寸不齐（代码会自动对齐）", patch_size)

    dataset = PairedDataset(
        cases,
        patch_size=patch_size,
        normalize=True,
        percentiles=tuple(cfg.data.percentiles),
        with_labels=w_dice > 0,
        seed=int(cfg.experiment.seed),
    )
    loader = DataLoader(
        dataset, batch_size=int(cfg.train.batch_size), shuffle=True,
        num_workers=int(cfg.runtime.num_workers), drop_last=True,
        pin_memory=device.type == "cuda",
    )

    translator, trans_dim = _resolve_translator(cfg, device)
    if translator is None:
        logger.warning("未启用翻译（translation.enabled=false），将直接把 MR 当作合成 CT")
    else:
        logger.info("已启用翻译生成器（dim=%d）", trans_dim)

    model = build_registration_net(dim=dim, in_ch=2, enc=enc, dec=dec).to(device)
    logger.info("配准网络 %.2fM 参数", sum(p.numel() for p in model.parameters()) / 1e6)

    lr = float(cfg.train.lr)
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)

    st = SpatialTransformer(dim=dim)
    epochs = int(args.epochs or cfg.train.epochs)
    n_steps = int(args.max_steps or cfg.train.n_steps_per_epoch or len(loader))
    log_every = int(cfg.train.log_interval)
    save_every = int(cfg.train.save_every)
    axis = int(cfg.translation.get("axis", 0)) if translator is not None else 0

    ckpt_dir = run_dir / "checkpoints"
    ckpt_dir.mkdir(parents=True, exist_ok=True)
    metrics_file = open(run_dir / "metrics.csv", "w", encoding="utf-8")
    metrics_file.write("epoch,step,loss,ncc,smooth,dice\n")
    metrics_file.flush()

    it = _infinite(loader)
    global_step = 0
    start = time.time()

    for epoch in range(1, epochs + 1):
        for _ in range(n_steps):
            batch = next(it)
            ct = batch["ct"].to(device, non_blocking=True)
            mr = batch["mr"].to(device, non_blocking=True)

            optimizer.zero_grad(set_to_none=True)
            with torch.no_grad():
                synthetic = translate_volume(translator, mr, trans_dim, axis) if translator is not None else mr

            flow = model(torch.cat([ct, synthetic], dim=1))
            warped = st(synthetic, flow)

            loss_ncc = ncc_loss(ct, warped, win=win)
            loss_smooth = gradient_loss(flow)
            loss = w_ncc * loss_ncc + w_smooth * loss_smooth

            loss_dice_value = torch.zeros((), device=device)
            if w_dice > 0 and "label_ct" in batch and "label_mr" in batch:
                label_ct = batch["label_ct"].to(device).squeeze(1).long().clamp(0, NUM_CLASSES - 1)
                label_mr = batch["label_mr"].to(device).squeeze(1).long().clamp(0, NUM_CLASSES - 1)
                if dim == 3:
                    onehot_mr = F.one_hot(label_mr, NUM_CLASSES).permute(0, 4, 1, 2, 3).float()
                    onehot_ct = F.one_hot(label_ct, NUM_CLASSES).permute(0, 4, 1, 2, 3).float()
                else:
                    onehot_mr = F.one_hot(label_mr, NUM_CLASSES).permute(0, 3, 1, 2).float()
                    onehot_ct = F.one_hot(label_ct, NUM_CLASSES).permute(0, 3, 1, 2).float()
                warped_onehot = st(onehot_mr, flow)
                loss_dice_value = dice_loss(warped_onehot[:, 1:], onehot_ct[:, 1:])
                loss = loss + w_dice * loss_dice_value

            loss.backward()
            optimizer.step()

            global_step += 1
            if global_step % log_every == 0:
                logger.info(
                    "epoch %d step %d | loss %.4f (ncc %.4f smooth %.4f dice %.4f)",
                    epoch, global_step, loss.item(), loss_ncc.item(),
                    loss_smooth.item(), loss_dice_value.item(),
                )
                metrics_file.write(
                    f"{epoch},{global_step},{loss.item():.6f},{loss_ncc.item():.6f},"
                    f"{loss_smooth.item():.6f},{loss_dice_value.item():.6f}\n"
                )
                metrics_file.flush()

        if save_every > 0 and epoch % save_every == 0:
            model_kwargs = {"dim": dim, "in_ch": 2, "enc": list(enc), "dec": list(dec)}
            checkpoint = {
                "model": model.state_dict(),
                "model_kwargs": model_kwargs,
                "dim": dim,
                "config": to_plain(cfg),
                "epoch": epoch,
            }
            torch.save(checkpoint, ckpt_dir / f"registration_epoch{epoch:03d}.pt")
            torch.save(checkpoint, ckpt_dir / "latest.pt")
            logger.info("已保存权重: %s", ckpt_dir / "latest.pt")

    metrics_file.close()
    elapsed = time.time() - start
    meta = {
        "run_id": run_id, "device": str(device), "epochs": epochs,
        "steps_per_epoch": n_steps, "elapsed_sec": round(elapsed, 1),
        "torch": torch.__version__, "translation": translator is not None,
    }
    (run_dir / "run_meta.json").write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
    logger.info("训练完成，用时 %.1fs。输出目录：%s", elapsed, run_dir)


if __name__ == "__main__":
    main()
