// 算法说明 PPT（16:9 宽屏）。用法：NODE_PATH=<含 pptxgenjs 的 node_modules> node docs/report/build_ppt.js
// 插图来自 make_figures.py；结果页为原生图表（可在 PowerPoint 里改数）。
const path = require("path");
const pptxgen = require("pptxgenjs");

const FIG = (n) => path.join(__dirname, "figs", n);
const OUT = path.join(__dirname, "CT-MR配准_算法说明.pptx");

const THEME = {
  name: "CTMR Teal",
  headFontFace: "Microsoft YaHei",
  bodyFontFace: "Microsoft YaHei",
  colors: {
    dk1: "1F2A37", lt1: "FFFFFF", dk2: "0F766E", lt2: "F3EFE6",
    accent1: "0F766E", accent2: "E4572E", accent3: "79BEB1", accent4: "C7CBD1",
    accent5: "3B9C8F", accent6: "B9DDD5", hlink: "0F766E", folHlink: "3B9C8F",
  },
};
const HEX = THEME.colors;

const pres = new pptxgen();
pres.layout = "LAYOUT_WIDE"; // 13.33 x 7.5
pres.title = "跨模态 CT–MR 腹部配准：分割引导的逐例优化";
pres.theme = { headFontFace: THEME.headFontFace, bodyFontFace: THEME.bodyFontFace };
const C = pres.SchemeColor;

// ----------------------------------------------------------------------------- layouts
pres.defineSlideMaster({
  title: "TITLE_DARK",
  background: { color: C.text2 },
  objects: [
    { placeholder: { options: { name: "title", type: "title", x: 0.8, y: 2.2, w: 11.7, h: 1.6, fontSize: 38, bold: true, color: C.background1, valign: "bottom" }, text: "标题" } },
    { placeholder: { options: { name: "body", type: "body", x: 0.8, y: 4.0, w: 11.7, h: 1.6, fontSize: 18, color: "D7EFEA", valign: "top" }, text: "副标题" } },
  ],
});
pres.defineSlideMaster({
  title: "TITLE_ONLY",
  background: { color: C.background1 },
  margin: [0.5, 0.6, 0.6, 0.6],
  slideNumber: { x: 12.4, y: 7.0, w: 0.6, h: 0.3, fontSize: 10, color: "6B7280" },
  objects: [
    { placeholder: { options: { name: "title", type: "title", x: 0.6, y: 0.35, w: 12.1, h: 0.85, fontSize: 30, bold: true, color: C.text1, valign: "middle" }, text: "标题" } },
    { text: { text: "跨模态图像配准挑战赛 · 算法说明", options: { x: 0.6, y: 7.0, w: 6, h: 0.3, fontSize: 10, color: "6B7280" } } },
  ],
});

function title(slide, t) { slide.addText(t, { placeholder: "title" }); }
function text(slide, runs, opt) { slide.addText(runs, { isTextBox: true, fontSize: 15, color: C.text1, valign: "top", margin: 0, ...opt }); }
function bullets(slide, items, opt) {
  text(slide, items.map((s, i) => ({ text: s, options: { bullet: true, breakLine: i < items.length - 1, paraSpaceAfter: 8 } })), opt);
}
function card(slide, x, y, w, h, name) {
  slide.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y, w, h, rectRadius: 0.12, fill: { color: C.background2 }, line: { color: C.background2 }, objectName: name });
}
function stat(slide, x, y, w, big, label, color) {
  text(slide, [{ text: big, options: { fontSize: 44, bold: true, color: color || C.text2 } }], { x, y, w, h: 0.9, align: "left" });
  text(slide, label, { x, y: y + 0.9, w, h: 0.7, fontSize: 13, color: "4B5563" });
}

// ----------------------------------------------------------------------------- 1 封面
pres.addSection({ title: "封面" });
let s = pres.addSlide({ masterName: "TITLE_DARK", sectionTitle: "封面" });
s.addText("跨模态 CT–MR 腹部图像配准\n分割引导的逐例优化方法", { placeholder: "title" });
s.addText("智能医学算法挑战赛　　高手队（团队编码 H3lzihNk）\n固定图 CT · 浮动图 MR · 评分 DSC / DSC30", { placeholder: "body" });
s.addNotes("封面。团队信息按赛事要求匿名，只写赛道与团队编码。");

// ----------------------------------------------------------------------------- 2 核心结论
pres.addSection({ title: "概览" });
s = pres.addSlide({ masterName: "TITLE_ONLY", sectionTitle: "概览" });
title(s, "学习放在分割上，配准交给逐例优化");
text(s, "24 对配对中只有 16 对有真实形变，直接学配准网络必然过拟合；单模态带标注数据却有 ~70 例/模态。我们只训练器官分割，再用分割结果引导无训练参数的逐例配准。", { x: 0.6, y: 1.35, w: 12.1, h: 0.9, fontSize: 16 });
const stats = [["0.872", "自采验证集 017–024 DSC\n（4 折留出，未参与任何训练/选型）"], ["0.835", "DSC30（最差 3 例均值）\n基线 0.672 → +0.163"], ["0.82", "最差病例 024\n基线 0.50"], ["≤5", "配准可调标量超参\n无可学习配准权重"]];
stats.forEach(([b, l], i) => { card(s, 0.6 + i * 3.08, 2.6, 2.85, 2.6, `stat${i}`); stat(s, 0.85 + i * 3.08, 2.85, 2.5, b, l, i === 2 ? C.accent2 : C.text2); });
text(s, "基线 = 同一逐例优化框架但不用分割（MIND-SSC 描述子 + 平移穷举 + 凸离散搜索 + Adam），对应往届经典方法量级。", { x: 0.6, y: 5.6, w: 12.1, h: 0.6, fontSize: 13, color: "6B7280" });

// ----------------------------------------------------------------------------- 3 数据划分
pres.addSection({ title: "数据" });
s = pres.addSlide({ masterName: "TITLE_ONLY", sectionTitle: "数据" });
title(s, "数据训练拆分：只把 017–024 当测试代理");
s.addImage({ path: FIG("fig1_data_split.png"), x: 0.6, y: 1.3, w: 7.6, h: 3.54, objectName: "fig1" });
bullets(s, [
  "001–008 公开 TCIA：2 mm 预对齐，次要验证",
  "009–016 伪 MR：与 CT 同网格、标签几乎相同 = 零形变对，不进任何验证",
  "017–024 主办方自采：与测试 025–032 同源，唯一主验证集",
  "4 折：每折各组 2 例；同一病例 CT/MR 同折 → 验证病例两侧分割模型都没见过它",
  "BCV 49 例 CT、CHAOS 40 例 MR 只用于训练分割（主办方提供的辅助数据）",
], { x: 8.5, y: 1.4, w: 4.2, h: 5.2, fontSize: 14 });
text(s, "CT 分割训练 73 例（每折 ~54），MR 63 例（每折 ~48）；001 的 MR 标签为空已剔除；1 例 BCV 文件损坏已剔除", { x: 0.6, y: 5.2, w: 7.6, h: 0.8, fontSize: 12, color: "6B7280" });

// ----------------------------------------------------------------------------- 4 预处理
s = pres.addSlide({ masterName: "TITLE_ONLY", sectionTitle: "数据" });
title(s, "预处理：先修正标签语义，再处理 200–750 mm 偏移");
s.addImage({ path: FIG("fig2_preprocess.png"), x: 0.6, y: 1.3, w: 12.1, h: 4.49, objectName: "fig2" });
bullets(s, [
  "发现 009–024 的标签编号与 001–008 不同（1 = 双肾、3 = 肝），按体积核验后统一语义；官方评分仍用原始编号",
  "自采病例 CT/MR 世界坐标相差 220–750 mm，几乎全在 z 向：全局平移决定成败",
], { x: 0.6, y: 5.95, w: 12.1, h: 0.95, fontSize: 14 });

// ----------------------------------------------------------------------------- 5 总体架构
pres.addSection({ title: "方法" });
s = pres.addSlide({ masterName: "TITLE_ONLY", sectionTitle: "方法" });
title(s, "模型架构：两阶段 = 器官分割 + 逐例优化配准");
s.addImage({ path: FIG("fig3_pipeline.png"), x: 0.6, y: 1.3, w: 12.1, h: 4.47, objectName: "fig3" });
text(s, [
  { text: "为什么不直接训练配准网络：", options: { bold: true } },
  { text: "往届学习型方案在留出口径下最高 0.80/0.71；经典无训练方法 DSC30 更稳。分割只需单模态标注，数据量大 4 倍且不依赖配对。" },
], { x: 0.6, y: 5.95, w: 12.1, h: 0.9, fontSize: 14 });

// ----------------------------------------------------------------------------- 6 分割网络
s = pres.addSlide({ masterName: "TITLE_ONLY", sectionTitle: "方法" });
title(s, "分割网络：各向异性 3D U-Net，从零训练");
s.addImage({ path: FIG("fig4_unet.png"), x: 0.6, y: 1.3, w: 7.8, h: 3.41, objectName: "fig4" });
const segRows = [
  [{ text: "折外 Dice（017–024）", options: { bold: true, color: "FFFFFF", fill: { color: HEX.dk2 } } }, { text: "肝", options: { bold: true, color: "FFFFFF", fill: { color: HEX.dk2 } } }, { text: "脾", options: { bold: true, color: "FFFFFF", fill: { color: HEX.dk2 } } }, { text: "肾", options: { bold: true, color: "FFFFFF", fill: { color: HEX.dk2 } } }],
  ["CT", "0.906", "0.907", "0.912"],
  ["MR", "0.887", "0.872", "0.876"],
];
s.addTable(segRows, { x: 8.7, y: 1.4, w: 4.0, colW: [1.9, 0.7, 0.7, 0.7], fontSize: 13, color: HEX.dk1, border: { type: "solid", pt: 0.5, color: "E5E7EB" }, rowH: 0.42, objectName: "segTable" });
bullets(s, [
  "输入：1.5×1.5×3 mm，块 64×160×160",
  "增强：旋转/缩放/平移 + 对比度、gamma、噪声、模糊；MR 加低频偏置场",
  "固定 100 epoch、只用 last checkpoint：不按验证集挑模型",
  "无任何医学预训练权重",
], { x: 8.7, y: 3.0, w: 4.0, h: 3.6, fontSize: 13 });
text(s, "测试集用全量数据重训的模型；验证集预测一律来自没见过该病例的折模型", { x: 0.6, y: 4.95, w: 7.8, h: 0.6, fontSize: 12, color: "6B7280" });

// ----------------------------------------------------------------------------- 7 配准细节
s = pres.addSlide({ masterName: "TITLE_ONLY", sectionTitle: "方法" });
title(s, "配准：四步逐例优化，全部在世界坐标（mm）中进行");
const steps = [
  ["1", "器官质心平移", "CT/MR 预测概率加权质心之差的均值，一步跨过 200–2000 mm 偏移；不依赖强度"],
  ["2", "凸离散搜索", "特征 = MIND-SSC(12) ⊕ √(4w)·器官概率(3)；8 mm 控制网格、±48 mm 代价体，渐进平滑耦合"],
  ["3", "Adam 实例优化", "半分辨率稠密位移，SSD + λ·扩散正则（λ=10），100 次迭代；只在 CT 体部∩MR 视野内计算"],
  ["4", "位移场输出", "D(x) = T(x) − x → TransformToDisplacementField 到 CT 原生网格，float32、毫米"],
];
steps.forEach(([n, h, d], i) => {
  const y = 1.45 + i * 1.32;
  s.addShape(pres.shapes.OVAL, { x: 0.7, y: y + 0.08, w: 0.62, h: 0.62, fill: { color: C.text2 }, line: { color: C.text2 }, objectName: `stepDot${n}` });
  text(s, n, { x: 0.7, y: y + 0.08, w: 0.62, h: 0.62, align: "center", valign: "middle", fontSize: 18, bold: true, color: C.background1 });
  text(s, h, { x: 1.6, y, w: 3.0, h: 0.8, fontSize: 18, bold: true, valign: "middle" });
  text(s, d, { x: 4.6, y, w: 8.1, h: 0.8, fontSize: 14, valign: "middle" });
});
text(s, "可调超参仅：器官权重 w、正则 λ、控制网格、搜索半径、迭代数；均在 TCIA 001–008 上选定", { x: 0.6, y: 6.55, w: 12.1, h: 0.4, fontSize: 12, color: "6B7280" });

// ----------------------------------------------------------------------------- 8 测试流程
pres.addSection({ title: "测试" });
s = pres.addSlide({ masterName: "TITLE_ONLY", sectionTitle: "测试" });
title(s, "测试方法：选型与验证分离，测试集只推理一次");
const flow = [
  ["预登记网格", "每轮实验跑之前把超参网格写进实验计划，跑完不追加"],
  ["TCIA 上选型", "只按 002–008 的 DSC 选配置；差 < 0.02 视为噪声取更简单者"],
  ["自采上报告", "017–024 折外结果报 mean±std、DSC30、逐器官"],
  ["官方口径复算", "原生 MR 标签经位移场最近邻采样到原生 CT 网格；空器官记 1.0"],
  ["测试推理 + 自检", "全量分割模型；几何/NaN/类型自检；无标签代理分做 QA"],
];
flow.forEach(([h, d], i) => {
  const x = 0.6 + i * 2.48;
  card(s, x, 1.5, 2.28, 3.4, `flow${i}`);
  text(s, `${i + 1}`, { x: x + 0.2, y: 1.7, w: 1.0, h: 0.6, fontSize: 28, bold: true, color: C.text2 });
  text(s, h, { x: x + 0.2, y: 2.35, w: 1.95, h: 0.6, fontSize: 16, bold: true });
  text(s, d, { x: x + 0.2, y: 3.0, w: 1.95, h: 1.8, fontSize: 12.5, color: "374151" });
});
bullets(s, [
  "代理分 = 预测 MR 器官图经位移场 vs 预测 CT 器官图；验证集上代理分与真分同序（约高 0.03–0.07），用于发现测试病例的失败",
  "合规：只用主办方数据；无医学预训练权重；未在 025–032 上调参或选型",
], { x: 0.6, y: 5.2, w: 12.1, h: 1.5, fontSize: 14 });

// ----------------------------------------------------------------------------- 9 结果（原生图表）
pres.addSection({ title: "结果" });
s = pres.addSlide({ masterName: "TITLE_ONLY", sectionTitle: "结果" });
title(s, "结果：分割引导让每个自采病例都超过 0.81");
const cases = ["017", "018", "019", "020", "021", "022", "023", "024"];
s.addChart(pres.charts.BAR, [
  { name: "基线（无分割）", labels: cases, values: [0.783, 0.730, 0.836, 0.898, 0.860, 0.896, 0.874, 0.502] },
  { name: "本方法（折外预测）", labels: cases, values: [0.880, 0.835, 0.855, 0.912, 0.880, 0.901, 0.893, 0.816] },
  { name: "上限（GT 标签，仅分析）", labels: cases, values: [0.956, 0.939, 0.943, 0.947, 0.940, 0.953, 0.934, 0.850] },
], {
  x: 0.6, y: 1.3, w: 8.4, h: 5.4, barDir: "col", barGapWidthPct: 60,
  chartColors: [HEX.accent4, HEX.accent1, HEX.accent6],
  valAxisMinVal: 0.4, valAxisMaxVal: 1.0, valAxisMajorUnit: 0.1, valAxisLabelFormatCode: "0.0",
  valGridLine: { color: "E5E7EB", size: 0.5 }, catGridLine: { style: "none" },
  catAxisLabelColor: "4B5563", valAxisLabelColor: "4B5563", catAxisLabelFontFace: "+mn-lt", valAxisLabelFontFace: "+mn-lt",
  catAxisLabelFontSize: 11, valAxisLabelFontSize: 11,
  showLegend: true, legendPos: "b", legendFontSize: 11, legendFontFace: "+mn-lt", legendColor: "374151",
  showTitle: true, title: "自采验证集 017–024 逐例 DSC（4 折留出）", titleFontSize: 13, titleColor: "1F2A37", titleFontFace: "+mn-lt",
  objectName: "resultsChart",
});
const sumRows = [
  [{ text: "", options: { fill: { color: HEX.dk2 } } }, { text: "DSC", options: { bold: true, color: "FFFFFF", fill: { color: HEX.dk2 } } }, { text: "DSC30", options: { bold: true, color: "FFFFFF", fill: { color: HEX.dk2 } } }],
  ["基线", "0.797", "0.672"],
  [{ text: "本方法", options: { bold: true, color: HEX.dk2 } }, { text: "0.872", options: { bold: true, color: HEX.dk2 } }, { text: "0.835", options: { bold: true, color: HEX.dk2 } }],
  ["上限（GT）", "0.933", "0.908"],
];
s.addTable(sumRows, { x: 9.3, y: 1.5, w: 3.4, colW: [1.4, 1.0, 1.0], fontSize: 14, color: HEX.dk1, border: { type: "solid", pt: 0.5, color: "E5E7EB" }, rowH: 0.45, objectName: "sumTable" });
bullets(s, [
  "+0.075 DSC，+0.163 DSC30",
  "最弱病例对应 MR 分割最弱处（018 肝 0.74、019 肾 0.72）",
  "上限说明瓶颈在分割，不在配准",
], { x: 9.3, y: 3.75, w: 3.4, h: 2.9, fontSize: 13 });

// ----------------------------------------------------------------------------- 10 结论
pres.addSection({ title: "总结" });
s = pres.addSlide({ masterName: "TITLE_DARK", sectionTitle: "总结" });
s.addText("把有限的配对数据留给验证，\n把学习留给数据充足的分割", { placeholder: "title" });
s.addText("下一步：分割多种子集成（针对 018/019 的 MR 弱例）· 多起点 + 代理分选优保 DSC30 · 器官权重细化", { placeholder: "body" });

(async () => {
  await pres.writeFile({ fileName: OUT });
  const { applyTheme } = require(process.env.APPLY_THEME);
  await applyTheme(OUT, THEME);
  console.log(OUT);
})();
