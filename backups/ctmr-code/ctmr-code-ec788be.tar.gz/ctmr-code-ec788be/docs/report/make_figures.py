"""技术报告 / PPT 插图（5 张）。

数据来源（2026-10-28/29 实验日志，见 docs/实验计划_v2.md）：
- 世界坐标偏移：E0 `ctmr.v2.prep` 输出（肝脏质心，MR − CT）
- 逐例 DSC：E1 `runs/e1_grid/am-none_lam-10`、E5 `runs/e5/init-seg_w-1`、E4 `runs/e4/init-mind_w-4`
- 分割折外 Dice：`runs/seg_*_v1/val_last.json`

用法::

    python docs/report/make_figures.py   # 输出到 docs/report/figs/
"""
from __future__ import annotations

from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch

OUT = Path(__file__).parent / "figs"
OUT.mkdir(parents=True, exist_ok=True)

for name in ("Noto Sans CJK SC", "Noto Sans CJK JP", "Noto Sans CJK HK"):
    if any(f.name == name for f in font_manager.fontManager.ttflist):
        plt.rcParams["font.family"] = name
        break
plt.rcParams.update({"axes.unicode_minus": False, "font.size": 11, "savefig.dpi": 220})

INK = "#1F2A37"
MUTED = "#6B7280"
TEAL = "#0F766E"
TEAL_L = "#99D5CC"
CORAL = "#E4572E"
SAND = "#F3EFE6"
GRID = "#E5E7EB"
FOLD_COLORS = ["#0F766E", "#3B9C8F", "#79BEB1", "#B9DDD5"]
GREY = "#C7CBD1"


def box(ax, x, y, w, h, text, fc=SAND, ec=INK, fs=11, bold=False, color=INK):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.02,rounding_size=0.06",
                                fc=fc, ec=ec, lw=1.2))
    ax.text(x + w / 2, y + h / 2, text, ha="center", va="center", fontsize=fs, color=color,
            fontweight="bold" if bold else "normal", wrap=True)


def arrow(ax, x0, y0, x1, y1, color=INK):
    ax.add_patch(FancyArrowPatch((x0, y0), (x1, y1), arrowstyle="-|>", mutation_scale=14, lw=1.4, color=color))


# ----------------------------------------------------------------------------- 图1 数据划分
def fig_split():
    groups = [
        ("配对·公开 TCIA\n001–008（2mm 预对齐）", 8, "paired"),
        ("配对·伪 MR\n009–016（零形变对）", 8, "paired"),
        ("配对·主办方自采\n017–024（≈测试分布）", 8, "paired"),
        ("未配对 CT · BCV\n49 例（剔除 1 例损坏）", 49, "extra"),
        ("未配对 MR · CHAOS\n40 例（T2-SPIR）", 40, "extra"),
        ("测试集 025–032\n（无标签）", 8, "test"),
    ]
    fig, ax = plt.subplots(figsize=(11, 5.2))
    ax.set_xlim(0, 25)
    ax.set_ylim(-0.8, len(groups) + 0.2)
    ax.axis("off")
    for row, (label, n, kind) in enumerate(groups):
        y = len(groups) - 1 - row
        ax.text(0, y + 0.4, label, va="center", ha="left", fontsize=10.5, color=INK)
        cols = 8 if n == 8 else 25 - 6.2
        for i in range(n):
            if n == 8:
                x, yy, s = 6.4 + i * 1.15, y + 0.15, 0.8
            else:
                per = 25
                x, yy, s = 6.4 + (i % per) * 0.74, y + 0.5 - (i // per) * 0.38, 0.6
            fc = GREY if kind == "test" else FOLD_COLORS[i % 4]
            ax.add_patch(plt.Rectangle((x, yy), s if n == 8 else s, s if n == 8 else 0.32, fc=fc, ec="white", lw=0.8))
            if n == 8:
                ax.text(x + s / 2, yy + s / 2, f"{(row * 8 + i + 1) if kind != 'test' else 25 + i:03d}",
                        ha="center", va="center", fontsize=7.5, color="white" if kind != "test" else INK)
    for k, c in enumerate(FOLD_COLORS):
        ax.add_patch(plt.Rectangle((6.4 + k * 3.2, -0.65), 0.45, 0.35, fc=c, ec="none"))
        ax.text(6.4 + k * 3.2 + 0.6, -0.48, f"第 {k} 折", va="center", fontsize=10, color=INK)
    ax.add_patch(plt.Rectangle((6.4 + 4 * 3.2, -0.65), 0.45, 0.35, fc=GREY, ec="none"))
    ax.text(6.4 + 4 * 3.2 + 0.6, -0.48, "测试（仅最终推理一次）", va="center", fontsize=10, color=INK)
    ax.set_title("图1  数据构成与 4 折划分：配对病例 CT/MR 同折，验证病例两侧分割模型均未见过",
                 fontsize=12.5, color=INK, loc="left", pad=10)
    fig.tight_layout()
    fig.savefig(OUT / "fig1_data_split.png", bbox_inches="tight")
    plt.close(fig)


# ----------------------------------------------------------------------------- 图2 预处理
def fig_preprocess():
    cases = ["002", "003", "004", "005", "006", "007", "008", "009", "010", "011", "012", "013", "014",
             "015", "016", "017", "018", "019", "020", "021", "022", "023", "024"]
    off = [70, 31, 28, 38, 50, 37, 19, 5, 4, 6, 4, 0, 0, 0, 0, 697, 281, 260, 738, 499, 218, 284, 319]
    color = [TEAL_L] * 7 + [GREY] * 8 + [CORAL] * 8
    fig, (a, b) = plt.subplots(1, 2, figsize=(12.5, 4.6), gridspec_kw={"width_ratios": [1.7, 1]})
    a.bar(cases, off, color=color, width=0.75)
    a.set_ylabel("MR−CT 肝脏质心世界坐标偏移 (mm)")
    a.tick_params(axis="x", labelsize=8.5, rotation=90)
    a.spines[["top", "right"]].set_visible(False)
    a.yaxis.grid(True, color=GRID)
    a.set_axisbelow(True)
    a.text(7.6, 560, "自采 017–024：220–750 mm\n几乎全在 z 向（检查床位置差）→", fontsize=9.5, color=CORAL, va="top")
    a.text(0, 760, "TCIA：20–100 mm", fontsize=9.5, color=TEAL, va="top")
    a.text(7.2, 120, "伪 MR：≈0", fontsize=9.5, color=MUTED)
    a.set_title("(a) 配对病例的世界坐标偏移", fontsize=11.5, loc="left", color=INK)

    b.axis("off")
    rows = [["来源", "原始标签", "统一后"],
            ["001–008 / BCV / CHAOS", "1 肝  2 脾  3,4 左右肾", "1 肝 2 脾 3 肾"],
            ["009–024 / 测试", "1 双肾  2 脾  3 肝", "1 肝 2 脾 3 肾"]]
    t = b.table(cellText=rows, loc="upper center", cellLoc="center", colWidths=[0.42, 0.36, 0.26])
    t.auto_set_font_size(False)
    t.set_fontsize(9.5)
    t.scale(1, 2.1)
    for (r, c), cell in t.get_celld().items():
        cell.set_edgecolor(GRID)
        if r == 0:
            cell.set_facecolor(TEAL)
            cell.get_text().set_color("white")
            cell.get_text().set_fontweight("bold")
    steps = ["① 单位方向规范网格（LPS），CT 界外填 −1024 HU",
             "② 分割：重采样 1.5×1.5×3 mm；配准：2 / 4 / 8 mm 金字塔",
             "③ 逐图强度归一化：CT 腹窗 [−200, 300] HU；\n    MR 前景 0.5–99.5 百分位（无跨病例统计）",
             "④ 标签语义统一（仅用于训练分割；评分按官方编号）"]
    for i, s in enumerate(steps):
        b.text(0.0, 0.6 - i * 0.14, s, fontsize=9.5, color=INK, transform=b.transAxes, va="top")
    b.set_title("(b) 标签语义统一与预处理步骤", fontsize=11.5, loc="left", color=INK)
    fig.suptitle("图2  预处理：发现并处理「标签语义不一致」与「大尺度世界坐标偏移」", fontsize=12.5,
                 color=INK, x=0.01, ha="left")
    fig.tight_layout()
    fig.savefig(OUT / "fig2_preprocess.png", bbox_inches="tight")
    plt.close(fig)


# ----------------------------------------------------------------------------- 图3 总体流程
def fig_pipeline():
    fig, ax = plt.subplots(figsize=(13.5, 4.8))
    ax.set_xlim(0, 27)
    ax.set_ylim(0, 10)
    ax.axis("off")
    box(ax, 0.3, 6.6, 3.0, 1.6, "CT（固定图）", fc="white", bold=True)
    box(ax, 0.3, 1.8, 3.0, 1.6, "MR（浮动图）", fc="white", bold=True)
    box(ax, 4.2, 6.6, 3.6, 1.6, "CT 器官分割\n3D U-Net", fc=TEAL_L)
    box(ax, 4.2, 1.8, 3.6, 1.6, "MR 器官分割\n3D U-Net", fc=TEAL_L)
    box(ax, 8.8, 4.0, 4.6, 2.2, "① 器官质心平移初始化\n（解决 200–750 mm 偏移）", fc=SAND, fs=9.5)
    box(ax, 14.1, 4.0, 5.0, 2.2, "② 凸离散搜索\nMIND-SSC ⊕ 器官概率\n控制网格 8 mm，±48 mm", fc=SAND, fs=9.5)
    box(ax, 19.8, 4.0, 3.4, 2.2, "③ Adam 实例优化\n+ 扩散正则", fc=SAND, fs=9.5)
    box(ax, 23.9, 4.0, 3.0, 2.2, "④ 毫米位移场\nCT 原生网格", fc=TEAL, color="white", bold=True, fs=9.5)
    arrow(ax, 3.3, 7.4, 4.2, 7.4)
    arrow(ax, 3.3, 2.6, 4.2, 2.6)
    arrow(ax, 7.8, 7.0, 8.9, 5.9)
    arrow(ax, 7.8, 3.0, 8.9, 4.3)
    arrow(ax, 13.4, 5.1, 14.1, 5.1)
    arrow(ax, 19.1, 5.1, 19.8, 5.1)
    arrow(ax, 23.2, 5.1, 23.9, 5.1)
    ax.text(4.2, 9.1, "学习部分：仅分割（~70 例/模态，强增强，4 折）", fontsize=10.5, color=TEAL, fontweight="bold")
    ax.text(8.8, 8.0, "逐例优化部分：无可学习配准参数，≤5 个标量超参", fontsize=10.5, color=CORAL, fontweight="bold")
    ax.text(8.8, 1.2, "MIND-SSC：模态无关自相似描述子（12 通道）；器官概率 3 通道按权重 w 拼接；"
                      "位移场经 TransformToDisplacementField 输出", fontsize=9.5, color=MUTED)
    ax.set_title("图3  方法总体流程：学习放在分割上，配准交给逐例优化", fontsize=12.5, color=INK, loc="left")
    fig.savefig(OUT / "fig3_pipeline.png", bbox_inches="tight")
    plt.close(fig)


# ----------------------------------------------------------------------------- 图4 U-Net
def fig_unet():
    widths = [32, 64, 128, 256, 320]
    strides = ["1", "(1,2,2)", "2", "2", "2"]
    sizes = ["64×160×160", "64×80×80", "32×40×40", "16×20×20", "8×10×10"]
    fig, ax = plt.subplots(figsize=(12, 5.6))
    ax.set_xlim(0, 24)
    ax.set_ylim(-2.2, 11)
    ax.axis("off")
    enc, dec = [], []  # (x, y_center, h)
    for i, (w, s, sz) in enumerate(zip(widths, strides, sizes)):
        h = 0.9 + w / 320 * 1.6
        x, y = 1.0 + i * 2.2, 9.0 - i * 1.9
        enc.append((x, y, h))
        box(ax, x, y - h / 2, 1.8, h, f"{w}", fc=TEAL_L if i < 4 else TEAL, color=INK if i < 4 else "white", bold=True)
        if i < 4:
            xd = 20.6 - i * 2.2
            dec.append((xd, y, h))
            box(ax, xd, y - h / 2, 1.8, h, f"{w}", fc=SAND, bold=True)
            ax.add_patch(FancyArrowPatch((x + 1.8, y), (xd, y), arrowstyle="-|>", mutation_scale=10, lw=1,
                                         color=MUTED, linestyle=(0, (4, 3))))
    for i in range(4):  # 编码器下采样：本层底 -> 下一层顶
        (x0, y0, h0), (x1, y1, h1) = enc[i], enc[i + 1]
        arrow(ax, x0 + 0.9, y0 - h0 / 2, x1 + 0.9, y1 + h1 / 2)
    for i in range(4):  # 解码器上采样：瓶颈/下一层顶 -> 本层底
        (x0, y0, h0) = enc[4] if i == 3 else dec[i + 1]
        (x1, y1, h1) = dec[i]
        if i == 3:
            arrow(ax, x0 + 1.8, y0, x1 + 0.9, y1 - h1 / 2)
        else:
            arrow(ax, x0 + 0.9, y0 + h0 / 2, x1 + 0.9, y1 - h1 / 2)
    box(ax, 20.2, 10.1, 3.4, 0.7, "1×1×1 卷积 → 4 类", fc="white", fs=8.5)
    arrow(ax, dec[0][0] + 0.9, dec[0][1] + dec[0][2] / 2, dec[0][0] + 0.9, 10.1)
    levels = "  →  ".join(f"{w}@{sz}（步长 {s}）" for w, s, sz in zip(widths, strides, sizes))
    ax.text(0.3, -0.6, "编码器各层（通道@体素尺寸）：" + levels, fontsize=8.6, color=MUTED)
    ax.text(0.3, -1.9, "每个块：Conv3d 3³ → InstanceNorm → LeakyReLU ×2；虚线为跳跃连接；"
                       "首次下采样只在 H/W（层厚 3 mm vs 1.5 mm）\n"
                       "输入块 64×160×160 体素 = 192×240×240 mm；参数 16.5 M；从零训练（无任何预训练权重）；"
                       "损失 = CE + soft Dice；SGD-Nesterov，poly 学习率，100×250 迭代",
            fontsize=9.3, color=INK)
    ax.set_title("图4  器官分割网络：各向异性 3D U-Net（CT、MR 各一个，结构相同）", fontsize=12.5, color=INK, loc="left")
    fig.savefig(OUT / "fig4_unet.png", bbox_inches="tight")
    plt.close(fig)


# ----------------------------------------------------------------------------- 图5 结果
def fig_results():
    cases = ["017", "018", "019", "020", "021", "022", "023", "024"]
    e1 = [0.783, 0.730, 0.836, 0.898, 0.860, 0.896, 0.874, 0.502]
    e5 = [0.880, 0.835, 0.855, 0.912, 0.880, 0.901, 0.893, 0.816]
    e4 = [0.956, 0.939, 0.943, 0.947, 0.940, 0.953, 0.934, 0.850]
    fig, (a, b) = plt.subplots(1, 2, figsize=(12.5, 4.6), gridspec_kw={"width_ratios": [1.8, 1]})
    x = range(len(cases))
    a.bar([i - 0.27 for i in x], e1, width=0.26, color=GREY, label="基线：MIND 逐例优化（无分割）")
    a.bar(list(x), e5, width=0.26, color=TEAL, label="本方法：分割引导（折外预测）")
    a.bar([i + 0.27 for i in x], e4, width=0.26, color=TEAL_L, label="上限：GT 标签引导（仅分析）")
    for i, v in enumerate(e5):
        a.text(i, v + 0.012, f"{v:.2f}", ha="center", fontsize=8, color=TEAL)
    a.set_xticks(list(x), cases)
    a.set_ylim(0.4, 1.0)
    a.set_ylabel("病例 DSC（肝/脾/肾均值）")
    a.spines[["top", "right"]].set_visible(False)
    a.yaxis.grid(True, color=GRID)
    a.set_axisbelow(True)
    a.legend(fontsize=8.8, frameon=False, loc="upper center", bbox_to_anchor=(0.5, -0.1), ncol=3)
    a.set_title("(a) 自采验证集 017–024 逐例 DSC（留出口径）", fontsize=11.5, loc="left", color=INK)

    names = ["基线", "本方法", "上限"]
    dsc = [0.797, 0.872, 0.933]
    d30 = [0.672, 0.835, 0.908]
    xi = range(3)
    b.bar([i - 0.18 for i in xi], dsc, width=0.34, color=[GREY, TEAL, TEAL_L], label="DSC")
    b.bar([i + 0.18 for i in xi], d30, width=0.34, color=[GREY, TEAL, TEAL_L], alpha=0.55, hatch="//",
          edgecolor="white", label="DSC30")
    for i in xi:
        b.text(i - 0.18, dsc[i] + 0.01, f"{dsc[i]:.3f}", ha="center", fontsize=8.8, color=INK)
        b.text(i + 0.18, d30[i] + 0.01, f"{d30[i]:.3f}", ha="center", fontsize=8.8, color=INK)
    b.set_xticks(list(xi), names)
    b.set_ylim(0.5, 1.0)
    b.spines[["top", "right"]].set_visible(False)
    b.yaxis.grid(True, color=GRID)
    b.set_axisbelow(True)
    b.legend(fontsize=9, frameon=False, loc="upper left")
    b.set_title("(b) 汇总：DSC（实心）/ DSC30（斜线）", fontsize=11.5, loc="left", color=INK)
    fig.suptitle("图5  验证结果：分割引导使 DSC +0.075、DSC30 +0.163；最差病例 024 由 0.50 升至 0.82",
                 fontsize=12.5, color=INK, x=0.01, ha="left")
    fig.tight_layout()
    fig.savefig(OUT / "fig5_results.png", bbox_inches="tight")
    plt.close(fig)


if __name__ == "__main__":
    fig_split()
    fig_preprocess()
    fig_pipeline()
    fig_unet()
    fig_results()
    print("\n".join(str(p) for p in sorted(OUT.glob("*.png"))))
