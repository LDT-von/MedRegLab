"""开发说明文档（匿名）：正文小四（12pt）、1.5 倍行距、≤12 页。

用法::

    python docs/report/build_doc.py   # -> docs/report/开发说明文档.docx（再用 LibreOffice 转 PDF）

封面只放项目名称、赛道、团队编码与队员的专业/年级/学历层次；不得出现姓名、导师、学校。
"""
from __future__ import annotations

from pathlib import Path

from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor

HERE = Path(__file__).parent
FIG = HERE / "figs"
OUT = HERE / "开发说明文档.docx"

# ---- 封面信息（待团队确认后填写；不得填写姓名/学校/导师）
INFO = {
    "项目名称": "基于分割引导逐例优化的跨模态 CT–MR 腹部图像配准",
    "参赛赛道": "智能医学算法挑战赛",
    "团队名称与编码": "高手队（团队编码 H3lzihNk）",
}
PDF_NAME = "智能医学算法挑战赛+高手队H3lzihNk.pdf"  # 命名规则：[赛道]+[团队名称和团队编码]
DEGREE = "研究生"
MEMBERS = [  # (角色, 专业, 年级, 学历层次)
    ("队员 1", "计算机技术", "2026 级", DEGREE),
    ("队员 2", "人工智能", "2026 级", DEGREE),
    ("队员 3", "软件工程", "2026 级", DEGREE),
]

BODY_PT, CN_BODY, CN_HEAD, EN = 12, "宋体", "黑体", "Times New Roman"

# 同一套内容同时写 docx 与 HTML（HTML 经 WeasyPrint 出 PDF；本机无 LibreOffice）
HTML: list[str] = []
CSS = """
@page { size: A4; margin: 2.4cm 2.5cm; @bottom-center { content: counter(page); font-size: 10pt; color: #555; } }
@page:first { @bottom-center { content: none; } }
body { font-family: "Times New Roman", "Noto Serif CJK SC", "Noto Sans CJK SC", serif; font-size: 12pt; line-height: 1.5; color: #111; }
p { margin: 0; text-align: justify; }
p.b { text-indent: 2em; }
h1 { font-family: "Noto Sans CJK SC", sans-serif; font-size: 15pt; margin: 8pt 0 3pt; line-height: 1.5; page-break-after: avoid; }
h2 { font-family: "Noto Sans CJK SC", sans-serif; font-size: 13pt; margin: 4pt 0 2pt; line-height: 1.5; page-break-after: avoid; }
figure { margin: 4pt 0 6pt; text-align: center; page-break-inside: avoid; }
figure img { display: block; margin: 0 auto; }
figcaption { font-size: 10.5pt; line-height: 1.5; }
table { border-collapse: collapse; margin: 4pt auto 8pt; font-size: 10.5pt; line-height: 1.3; page-break-inside: avoid; }
td { border: 0.6pt solid #444; padding: 3pt 6pt; text-align: center; }
tr.h td { font-weight: bold; background: #EEF5F4; }
.cover { page-break-after: always; text-align: center; padding-top: 4cm; }
.cover .t1 { font-family: "Noto Sans CJK SC", sans-serif; font-size: 18pt; font-weight: bold; }
.cover .t2 { font-family: "Noto Sans CJK SC", sans-serif; font-size: 26pt; font-weight: bold; margin: 6pt 0 30pt; }
.cover table { font-size: 13pt; line-height: 1.6; }
.cover .note { font-family: "Noto Sans CJK SC", sans-serif; margin: 18pt 0 4pt; }
"""


def esc(s: str) -> str:
    import html

    return html.escape(s)


def html_table(rows, widths_cm, header=True, size=None):
    style = f' style="font-size:{size}pt"' if size else ""
    out = [f"<table{style}>"]
    for i, row in enumerate(rows):
        cls = ' class="h"' if header and i == 0 else ""
        out.append(f"<tr{cls}>" + "".join(f'<td style="width:{w}cm">{esc(str(v))}</td>' for v, w in zip(row, widths_cm)) + "</tr>")
    out.append("</table>")
    return "".join(out)


def set_font(run, size=BODY_PT, cn=CN_BODY, bold=False, color=None):
    run.font.size = Pt(size)
    run.font.name = EN
    run.font.bold = bold
    run._element.rPr.rFonts.set(qn("w:eastAsia"), cn)
    if color:
        run.font.color.rgb = RGBColor.from_string(color)


def para(doc, text="", size=BODY_PT, cn=CN_BODY, bold=False, align=None, indent=True, space_after=0, html=True):
    if html and text:
        HTML.append(f'<p class="{"b" if indent else ""}">{esc(text)}</p>')
    p = doc.add_paragraph()
    pf = p.paragraph_format
    pf.line_spacing = 1.5
    pf.space_after = Pt(space_after)
    pf.space_before = Pt(0)
    if indent:
        pf.first_line_indent = Pt(size * 2)
    if align:
        p.alignment = align
    if text:
        set_font(p.add_run(text), size, cn, bold)
    return p


def rich(doc, parts, indent=True):
    """parts: [(text, bold)]"""
    HTML.append(f'<p class="{"b" if indent else ""}">' +
                "".join(f"<b>{esc(t)}</b>" if b else esc(t) for t, b in parts) + "</p>")
    p = para(doc, indent=indent)
    for t, b in parts:
        set_font(p.add_run(t), bold=b)
    return p


def heading(doc, text, level=1):
    size = {1: 15, 2: 13}[level]  # 小三 / 四号偏小，正文仍为小四
    HTML.append(f"<h{level}>{esc(text)}</h{level}>")
    p = para(doc, text, size=size, cn=CN_HEAD, bold=True, indent=False, space_after=2, html=False)
    p.paragraph_format.space_before = Pt(6 if level == 1 else 3)
    p.paragraph_format.keep_with_next = True
    return p


def figure(doc, name, caption, width_cm=15.5):
    HTML.append(f'<figure><img src="{(FIG / name).as_uri()}" style="width:{width_cm}cm">'
                f"<figcaption>{esc(caption)}</figcaption></figure>")
    p = para(doc, indent=False, align=WD_ALIGN_PARAGRAPH.CENTER, html=False)
    p.paragraph_format.line_spacing = 1.0
    p.add_run().add_picture(str(FIG / name), width=Cm(width_cm))
    c = para(doc, caption, size=10.5, indent=False, align=WD_ALIGN_PARAGRAPH.CENTER, html=False)
    c.paragraph_format.space_after = Pt(4)


def table(doc, rows, widths_cm, header=True, size=10.5, html=True):
    if html:
        HTML.append(html_table(rows, widths_cm, header))
    t = doc.add_table(rows=len(rows), cols=len(rows[0]))
    t.style = "Table Grid"
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    for i, row in enumerate(rows):
        for j, val in enumerate(row):
            cell = t.cell(i, j)
            cell.width = Cm(widths_cm[j])
            cell.text = ""
            p = cell.paragraphs[0]
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            p.paragraph_format.line_spacing = 1.15
            set_font(p.add_run(str(val)), size=size, bold=header and i == 0)
    para(doc, indent=False).paragraph_format.line_spacing = 0.6
    return t


def build():
    doc = Document()
    sec = doc.sections[0]
    sec.page_height, sec.page_width = Cm(29.7), Cm(21.0)
    for side in ("left_margin", "right_margin"):
        setattr(sec, side, Cm(2.5))
    sec.top_margin = sec.bottom_margin = Cm(2.4)
    normal = doc.styles["Normal"]
    normal.font.size = Pt(BODY_PT)
    normal.font.name = EN
    normal.element.rPr.rFonts.set(qn("w:eastAsia"), CN_BODY)

    # ------------------------------------------------------------------ 封面
    note = "参赛队员基本信息（按赛事要求匿名，不含姓名、学校、指导老师）"
    member_rows = [["", "专业", "年级", "学历层次"], *MEMBERS]
    HTML.append('<div class="cover"><div class="t1">跨模态图像配准算法挑战赛</div><div class="t2">开发说明文档</div>'
                + html_table([[k, v] for k, v in INFO.items()], [4.5, 10.5], header=False)
                + f'<div class="note">{esc(note)}</div>' + html_table(member_rows, [2.5, 5.5, 3.0, 4.0]) + "</div>")
    for _ in range(4):
        para(doc, indent=False, html=False)
    para(doc, "跨模态图像配准算法挑战赛", size=18, cn=CN_HEAD, bold=True, indent=False, align=WD_ALIGN_PARAGRAPH.CENTER, html=False)
    para(doc, "开发说明文档", size=26, cn=CN_HEAD, bold=True, indent=False, align=WD_ALIGN_PARAGRAPH.CENTER, space_after=30, html=False)
    table(doc, [[k, v] for k, v in INFO.items()], [4.5, 10.5], header=False, size=13, html=False)
    para(doc, note, size=12, cn=CN_HEAD, indent=False, align=WD_ALIGN_PARAGRAPH.CENTER, space_after=4, html=False)
    table(doc, member_rows, [2.5, 5.5, 3.0, 4.0], size=12, html=False)
    doc.add_paragraph().add_run().add_break(WD_BREAK.PAGE)

    # ------------------------------------------------------------------ 1
    heading(doc, "1  任务与核心难点")
    para(doc, "本赛题为腹部 CT–MR 跨模态配准：固定图像为 CT、浮动图像为 MR，对 8 例测试病例提交物理毫米单位的相对位移场"
              "（p_mr = p_ct + D(p_ct)，几何与原始 CT 完全一致），以肝、脾、肾三器官 Dice 的病例均值（DSC）为主指标、"
              "最差 30% 病例均值（DSC30）为次指标。我们在动手建模前对官方数据做了逐例体检，归纳出四个决定方案走向的难点：")
    for t in ["（1）真实配对极少：24 对配对数据中 009–016 为由 CT 合成的伪 MR，与 CT 同网格、标签几乎相同，是零形变对；"
              "真正带形变的只有 16 对，其中与测试集同源的仅 017–024 共 8 对。直接训练配准网络极易过拟合，"
              "往届学习型方案在严格留出口径下最高仅约 0.80 / 0.71。",
              "（2）标签语义不一致：001–008 中 1 = 肝、3/4 = 左右肾，而 009–024 中 1 = 双肾、3 = 肝（按器官体积核验）。"
              "官方评分按编号分组、CT/MR 同口径，评分不受影响，但任何跨组训练都必须先统一语义。",
              "（3）大尺度世界坐标偏移：自采病例 CT 与 MR 的器官质心在世界坐标中相差 220–750 mm（测试集最大约 2000 mm），"
              "且三个器官偏移一致，几乎全在 z 向，属于检查床位置差。全局平移一旦估错，病例 DSC 接近 0，是 DSC30 的主要风险。",
              "（4）厚层 CT：测试集 8 例中 5 例 CT 层厚 5 mm、仅 35–46 层，z 向覆盖 175–230 mm，器官可能被视野截断。"]:
        para(doc, t)

    # ------------------------------------------------------------------ 2
    heading(doc, "2  数据训练拆分与切分")
    para(doc, "数据全部来自主办方：24 例配对（含肝/脾/肾标注）、辅助未配对 CT 50 例（BCV）与 MR 40 例（CHAOS T2-SPIR，均带标注）、"
              "测试 8 例（无标注）。其中 001 的 MR 标注文件为空、BCV 第 36 例在原压缩包内即 CRC 损坏，二者均已剔除。"
              "我们的拆分原则是：可学习参数只放在单模态器官分割上（CT 73 例、MR 63 例），配对数据主要留给验证。")
    figure(doc, "fig1_data_split.png", "图1  数据构成与 4 折划分（配对病例的 CT 与 MR 位于同一折）")
    para(doc, "具体做法：各组按编号轮转分为 4 折，每折含 TCIA、伪 MR、自采各 2 例及约 1/4 的 BCV/CHAOS；同一配对病例的 CT 与 MR "
              "必在同一折。因此对任意验证病例，生成其 CT、MR 器官概率的两个分割模型都没有见过它。验证集分三层使用："
              "017–024 为唯一主验证集（测试代理）；001–008 只用于选择超参；009–016 不进入任何验证。测试集 025–032 只在定版后推理一次。")

    # ------------------------------------------------------------------ 3
    heading(doc, "3  预处理")
    figure(doc, "fig2_preprocess.png", "图2  （a）配对病例 CT/MR 世界坐标偏移；（b）标签语义统一与预处理步骤")
    para(doc, "所有图像先重采样到方向为单位阵（LPS 对齐）、覆盖原图物理范围的规范网格，CT 界外以 −1024 HU（空气）填充，"
              "避免 0 HU 被误认为软组织。分割使用 1.5×1.5×3 mm（贴合 3–5 mm 层厚），配准使用 8 / 4 / 2 mm 三级金字塔。"
              "强度逐图归一化，不使用任何跨病例或测试集统计：CT 取腹窗 [−200, 300] HU 线性映射，MR 取前景 0.5–99.5 百分位。"
              "标签按第 1 节的映射统一为 1 肝、2 脾、3 肾，仅用于训练分割与按器官加权；评分始终按官方原始编号。")

    # ------------------------------------------------------------------ 4
    heading(doc, "4  模型架构")
    heading(doc, "4.1  总体流程", 2)
    figure(doc, "fig3_pipeline.png", "图3  方法总体流程")
    para(doc, "方法分两阶段：先用 CT、MR 各自的 3D U-Net 预测肝/脾/肾概率图；再在每个病例上做无可学习参数的逐例优化配准，"
              "以模态无关的 MIND-SSC 描述子与器官概率共同驱动。该设计把「学习」放在数据充足（约 70 例/模态）且不需要配对的分割任务上，"
              "把「配准」交给只有少量标量超参的优化过程，从结构上避免在 16 对真实配对上过拟合。")
    heading(doc, "4.2  器官分割网络", 2)
    figure(doc, "fig4_unet.png", "图4  各向异性 3D U-Net（CT、MR 各一个，结构相同）", width_cm=14.5)
    para(doc, "网络为 5 级编码器–解码器（通道 32/64/128/256/320），每级两个 3³ 卷积 + InstanceNorm + LeakyReLU；"
              "首次下采样只在平面内进行，以适配 3 mm 与 1.5 mm 的各向异性。输入块 64×160×160 体素（192×240×240 mm），"
              "前景过采样 2/3。增强在 GPU 上完成：轴位面内旋转 ±15°、其余 ±5°、缩放 0.85–1.2、平移，以及对比度、亮度、gamma、"
              "噪声、模糊；MR 额外叠加低频乘性偏置场以模拟线圈不均匀。损失为交叉熵 + soft Dice，SGD-Nesterov（动量 0.99），"
              "poly 学习率，固定 100×250 次迭代。模型从零训练，不使用任何预训练权重；每折只保存最后一个 checkpoint，不按验证集挑选。"
              "推理采用 50% 重叠滑窗。")
    heading(doc, "4.3  逐例优化配准", 2)
    for parts in [
        [("① 器官质心平移初始化。", True), ("分别计算 CT、MR 预测概率加权的三器官质心，取平均偏移作为全局平移。该步骤与强度无关，"
                                         "一步跨过数百至上千毫米的检查床偏移；在 E4 上限实验中，修正后的质心初始化比 MIND 平移穷举的 DSC30 更高。", False)],
        [("② 凸离散搜索。", True), ("特征为 MIND-SSC（12 通道）与 √(4w)·器官概率（3 通道）拼接，代价为通道平方差，使 MIND 部分取均值、概率部分权重为 w。"
                                  "特征平均池化到 8 mm 控制网格，在 ±6 格（±48 mm）内穷举计算代价体，再以 6 级递增系数与平滑后的位移耦合迭代求解，"
                                  "得到全局一致的粗位移。", False)],
        [("③ Adam 实例优化。", True), ("以半分辨率稠密位移为参数，经两次 3³ 平均平滑后上采样，最小化特征平方差 + λ·扩散正则（λ = 10），"
                                     "迭代 100 次。只在「CT 体部 ∩ MR 视野」的包围盒（外扩 40 mm）内计算，盒外取平移，"
                                     "既节省显存，也避免在无信息区域产生虚假形变；折叠率约 0.1%。", False)],
        [("④ 位移场生成。", True), ("将映射 T(x) 写为规范网格上的位移 D(x) = T(x) − x，经 SimpleITK DisplacementFieldTransform 与 "
                                  "TransformToDisplacementField 重采样到原始 CT 网格，输出 float32、毫米单位，并自检 size/spacing/origin/"
                                  "direction 与 NaN/Inf。", False)],
    ]:
        rich(doc, parts)

    # ------------------------------------------------------------------ 5
    heading(doc, "5  验证与测试方法")
    para(doc, "评分器严格复现官方口径：原生 MR 标签经位移场以最近邻插值采样到原生 CT 网格，按 1/2/(3,4) 分组计算 Dice，"
              "CT 中缺失的器官记 1.0，DSC30 取最差 ⌈0.3N⌉ 例均值。我们发现并修正了早期脚手架中「先把 MR 标签无变换重采样到 CT 网格」"
              "的做法——它会截掉 CT 视野外的 MR 内容，与官方不一致。")
    para(doc, "实验纪律：（1）每轮实验在运行前把超参网格写入实验计划，跑完不追加；（2）只按 TCIA 002–008 的 DSC 选择配置，"
              "差异小于 0.02 视为噪声、取更简单者；（3）在 017–024 上报告折外 mean ± std、DSC30 与逐器官结果；"
              "（4）测试集只在定版后用全量数据重训的分割模型推理一次。由于测试集无标签，我们定义无标签代理分——"
              "预测 MR 器官图经位移场与预测 CT 器官图的 Dice——用于发现失败病例；在验证集上代理分与真实分同序，约高 0.03–0.07。")

    # ------------------------------------------------------------------ 6
    heading(doc, "6  实验结果")
    figure(doc, "fig5_results.png", "图5  自采验证集 017–024 逐例 DSC 与汇总（4 折留出口径）")
    table(doc, [["实验", "配置（在 002–008 上选定）", "002–008 DSC / DSC30", "017–024 DSC / DSC30"],
                ["E1 基线（无分割）", "MIND 平移穷举，无仿射，λ = 10", "0.772 / 0.631", "0.797 / 0.672"],
                ["E5 本方法", "质心初始化，w = 1，λ = 10", "0.854 / 0.792", "0.872 / 0.835"],
                ["E4 上限（GT 标签）", "MIND 初始化，w = 4（仅分析）", "0.930 / 0.894", "0.933 / 0.908"]],
          [3.6, 5.4, 3.3, 3.3])
    table(doc, [["分割折外 Dice（017–024）", "肝", "脾", "肾"],
                ["CT", "0.906", "0.907", "0.912"], ["MR", "0.887", "0.872", "0.876"]], [6.0, 3.0, 3.0, 3.0])
    para(doc, "E1 网格比较了无仿射/刚体/仿射与 λ ∈ {1, 10}：仿射在多数病例上反而降低精度，λ = 1 折叠率达 3–6%，故选无仿射、λ = 10。"
              "E5 网格比较了 MIND / 质心两种初始化与 w ∈ {1, 4, 8}：质心初始化全面领先，w 的差异小于 0.003，按规则取 w = 1。"
              "相对基线，本方法 DSC 提升 0.075、DSC30 提升 0.163，最差病例 024 由 0.50 升至 0.82，所有自采病例均超过 0.81。"
              "E4 表明当分割完美时同一配准框架可达 0.933，剩余差距主要来自 MR 分割最弱的病例（018 肝 0.74、019 肾 0.72）。")
    para(doc, "测试集 8 例的代理分中 7 例为 0.92–0.95；032 为 0.68，经逐器官分析其肝、肾代理分为 0.95、0.93，"
              "低分来自脾脏（CT 中仅预测出约 5 ml），属于小/缺失器官的分割不确定性而非配准失败，按官方规则 CT 缺失器官记 1.0。")

    # ------------------------------------------------------------------ 7
    heading(doc, "7  合规说明与可复现性")
    para(doc, "仅使用主办方提供的训练数据（含其提供的 BCV、CHAOS 辅助数据）；未使用任何第三方医学数据或医学预训练权重，"
              "分割网络从零训练；未在测试集 025–032 上做任何调参、选型或统计。配准阶段对每个测试病例仅使用其 CT 与 MR 图像本身"
              "进行逐例优化，与经典配准方法同类，不使用任何测试标签。全部代码以 Python/PyTorch 实现：数据准备 ctmr.v2.prep、"
              "分割 ctmr.v2.seg（train / predict）、配准与评分 ctmr.v2.register、打包自检 ctmr.utils.submit；"
              "单例配准在 RTX 5090 上约 2–8 秒，每折分割训练约 50 分钟。")

    # ------------------------------------------------------------------ 8
    heading(doc, "8  结论与后续工作")
    para(doc, "在配对数据极少、且存在标签语义不一致与大尺度坐标偏移的条件下，「学习分割 + 逐例优化配准」在严格留出口径下取得 "
              "DSC 0.872 / DSC30 0.835。后续将从三方面提升：分割多种子集成以加强 MR 弱例；多起点初始化并以代理分选优以进一步保障 DSC30；"
              "在新的预登记实验中细化器官权重与正则强度。")

    doc.save(OUT)
    print(OUT)
    # PDF：命名规则 [赛道]+[团队名称和团队编码]
    pdf = HERE / PDF_NAME
    page = f'<html><head><meta charset="utf-8"><style>{CSS}</style></head><body>{"".join(HTML)}</body></html>'
    (HERE / "开发说明文档.html").write_text(page, encoding="utf-8")
    try:
        from weasyprint import HTML as WHTML

        rendered = WHTML(string=page, base_url=str(HERE)).render()
        rendered.write_pdf(pdf)
        print(pdf, f"{len(rendered.pages)} pages")
    except ImportError:
        print("weasyprint 未安装：只生成了 docx 与 html")


if __name__ == "__main__":
    build()
