# 实验记录（EXPERIMENTS）

> 本文件由 `ctmr/utils/tracker.py` 自动追加：每跑完一个方案/变体并执行
> `python -m ctmr.eval.evaluate ... --record`，就会在下方「分数记录」表新增一行，
> 同时在 `experiments.csv` 留一条机器可读记录。
>
> 手动补结论：
> ```python
> from ctmr.utils.tracker import ExperimentTracker
> ExperimentTracker("docs").note("2026-10-23：方案二 CycleGAN 100 epoch，DSC 0.81")
> ```

## 方案登记

| 编号 | 方案 | 状态 | 备注 |
|---|---|---|---|
| 方案二 | CycleGAN 翻译 + VoxelMorph 配准 | 脚手架就绪 | 主线；待真实数据训练 |
| 方案一 | MIND/结构描述子 + 学习配准 | 未开始 | 可作对照 |
| 方案五 | 由粗到细 Transformer | 未开始 | 针对 DSC30 |
| 方案六 | deedsBCV + 深度集成 | 未开始 | 兜底/提升尾部 |
| 方案三 | 扩散/分数式配准 | 未开始 | 备选 |
| 方案四 | 基础模型特征 | 未开始 | 备选 |

## 分数记录

| 时间 | 方案 | run_id | 数据集 | 病例数 | DSC | DSC30 | 备注 |
|---|---|---|---|---|---|---|---|
