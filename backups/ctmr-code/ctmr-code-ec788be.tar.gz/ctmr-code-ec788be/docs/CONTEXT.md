# 跨模态图像配准算法挑战赛 — 上下文

> 归档时间：2026-10-22（Asia/Shanghai）
> 本文件保存赛题要点、提交规范、评分方式与候选方案，供后续实验对照。

---

## 1. 原始文档位置

两份 PDF 均为本地文件，位于 macOS「腾讯 QQ」沙盒容器的下载目录：

| 文档 | 绝对路径 | 页数 |
|---|---|---|
| 《跨模态图像配准算法挑战赛》 | `/Users/philopatrick/Library/Containers/com.tencent.qq/Data/Downloads/跨模态图像配准算法挑战赛.pdf` | 3 |
| 《跨模态图像配准算法创新挑战赛测试集提交规范与评分说明》 | `/Users/philopatrick/Library/Containers/com.tencent.qq/Data/Downloads/跨模态图像配准算法创新挑战赛测试集提交规范与评分说明.pdf` | 7 |

---

## 2. 赛事概况

- **任务**：跨模态图像配准，把不同成像模态变换到同一空间坐标系；本次限定 **CT–MR**，场景为**腹部**。
- **固定图（Fixed）= CT，浮动图（Moving）= MR**；需计算变形场（Displacement Field），把 MR 配准到 CT 空间。
- **目标**：提升配准的精度、泛化性与鲁棒性。

---

## 3. 三项任务

| 任务 | 要求 |
|---|---|
| 模型开发 | 用官方数据训练/验证，提交 8 例测试集的变形场 |
| 技术报告 | 阐述核心难题、解决方案、网络架构如何用于配准、验证集性能 |
| 在线打榜 | 2026-10-20 起，每天最多 1 次；按 DSC、DSC30 排名，是决赛入围重要依据 |
| 决赛 | 获推荐队伍须在 **2026-11-10 24:00 前** 完成最后一次测试集变形场提交 |

---

## 4. 数据集

网盘：`https://pan.baidu.com/s/1j-COKoMeQs4Xgcf1WV-11Q?pwd=h76d`，提取码 `h76d`。

| 类别 | 构成 | 标注 | 用途 |
|---|---|---|---|
| 配对训练（24 例） | 8 公开（001–008）+ 8 伪 MR（009–016）+ 8 自采真实配对（017–024） | 肝/脾/肾分割 | 有监督配准 |
| 辅助未配对（90 例） | CT 约 50、MR 约 40 | 肝/脾/肾分割 | 无监督/自监督、图像翻译、域自适应 |
| 测试（8 例） | 自采配对（025–032） | 标签不公开 | 最终排名 |

---

## 5. 提交规范

```
submission.zip
└── submission/
    ├── 025/displacement_field.nii.gz
    ├── ...
    └── 032/displacement_field.nii.gz
```

| 属性 | 要求 |
|---|---|
| 格式 | NIfTI `.nii.gz`（gzip） |
| 类型 | float32（推荐）或 float64 |
| 单位 | **物理坐标（毫米）**，非体素索引 |
| 语义 | **相对位移**：`p_mr = p_ct + D(p_ct)` |
| 生成 | 推荐 `sitk.TransformToDisplacementField`，不要用 nibabel 手工拼四维数组 |

- 空间几何（size/spacing/origin/direction）必须与原始 `ct.nii` **完全一致**；
- 训练/推理可任意预处理，但**最终变形场必须能直接作用于原始测试数据**；若预处理改变了几何，必须转换回原空间；
- 每例目录只放一个 `displacement_field.nii.gz`，zip ≤ 4GB。

> 坐标系：NIfTI 用 RAS，SimpleITK 内部 LPS；用 SimpleITK 读写会自动换算。

---

## 6. 评分

标签：0 背景 / 1 肝 / 2 脾 / 3 肾（001–008 双肾为 3 和 4）。

```
DSC_organ = 2|A∩B| / (|A| + |B|)
DSC_case  = (DSC_liver + DSC_spleen + DSC_kidney) / 3
```

- `A`：CT 标签中该器官体素；`B`：变形场映射后 MR 标签体素；
- **空器官**：CT 中不存在该器官（|A|=0）时，该器官 DSC 记 **1.0**；
- **DSC30**：所有病例按 DSC 升序，取最低 30%（向上取整）的均值；8 例时 N30=⌈2.4⌉=**3**；
- **排名**：主指标 DSC，次指标 DSC30；
- 只评器官 Dice，不单独评折叠率/平滑性；float32 会自动转 float64 计算。

---

## 7. 规则与时间

- 公平诚信，违规取消资格；
- **仅允许使用主办方提供的训练数据**；禁止使用第三方医学影像数据集做额外训练/微调；允许 ImageNet 预训练骨干（如 ResNet），须在报告披露；
- 自采数据未经允许不得另作他用；
- 时间：2026-10-20 开榜（每日 1 次）；2026-11-10 24:00 决赛截止。

---

## 8. 研究趋势（2024–2025）

从单纯基于强度的 `VoxelMorph` 式 UNet，转向：

- **模态无关特征描述子**（MIND、LBP、边缘图）；
- **图像翻译作为桥梁**（CycleGAN / CUT / MITIA）；
- **扩散 / 分数式配准**（DiffuseMorph 等）；
- **基础模型特征**（DINOv2、SAM 蒸馏）；
- **Transformer / 由粗到细金字塔**；
- 明确强调**鲁棒性**（对应 DSC30）。

---

## 9. 六个候选方案

### 方案一：免翻译 — 模态无关描述子 + 学习

- 用 MIND / LBP / 边缘图替换原始强度，输入 VoxelMorph 或 Transformer UNet；可加表征解耦头。
- 契合：直接用 24 例配对；90 例未配对可预训练描述子。
- 提升 DSC30：结构描述子对 CT-MR 外观差异更稳。

### 方案二：先翻译后配准 — CycleGAN + 配准（**本仓库主线**）

- 用 90 例未配对训练 CycleGAN / CUT / MITIA，把 MR 合成伪 CT，再在单模态空间配准；可加器官标签弱监督。
- 契合：未配对数据 + 标签适合训练合成网络；24 例配对提供像素级弱监督。
- 提升 DSC30：单模态空间配准更可靠。

### 方案三：扩散 / 分数式配准

- DiffuseMorph 式迭代细化变形场，或用分数匹配做迭代对齐 + 器官先验。

### 方案四：基础模型特征（DINO-Reg / SAM 蒸馏）

- 冻结基础模型特征蒸馏进轻量配准头，或用 SAM 注入器官结构先验。

### 方案五：鲁棒的由粗到细 Transformer / 金字塔

- 多分辨率/递归金字塔 + Transformer 长程建模 + 困难样本挖掘，显式优化最差 30% 病例。

### 方案六：集成 — deedsBCV + 深度模型 + 变形场融合

- 保留 `deedsBCV`（MIND + 离散优化）作为强经典锚点，与深度模型输出融合并逐例回退校验。

---

## 10. 推荐组合（务实路线）

1. **预处理**：MR 重采样到 CT 网格（或最后把变形场映射回原空间），强度归一化、N4 校正；
2. **主干**：方案一（MIND）+ 方案五（由粗到细 Transformer）；
3. **扩充配对**：方案二（MR→CT 合成 + 90 例未配对）生成伪配对；
4. **损失**：局部 NCC / MIND + 扩散正则 + 器官标签弱监督 + 模仿 DSC30 的困难样本损失；
5. **集成回退**：方案六（deedsBCV）兜底 + 逐例合理性校验；
6. **输出**：

```python
disp_field = sitk.TransformToDisplacementField(
    transform, sitk.sitkVectorFloat32,
    ct.GetSize(), ct.GetOrigin(), ct.GetSpacing(), ct.GetDirection()
)
sitk.WriteImage(disp_field, "displacement_field.nii.gz")
```

**务必记住**：

- float32、毫米、几何与 `ct.nii` 完全一致；
- 预处理若改了空间几何，必须把变形场转回原空间；
- 空器官规则（CT 缺某器官时该器官 DSC=1.0），不要对缺肾病例过拟合。

---

## 11. 联系信息

- 赛事咨询：文老师 13022388326
- 算法命题赛道 QQ 群：1101385600
- 提交平台：华为云 OBS
- 数据集网盘：`https://pan.baidu.com/s/1j-COKoMeQs4Xgcf1WV-11Q?pwd=h76d`（`h76d`）
