# audit/ 模板说明

本目录是发给学生的**最小审计包模板**。每个学生/方案建一个目录：

```text
audit/
├── <student>_<scheme>/
│   ├── run_manifest.json        # 从 run_manifest_template.json 复制填写
│   ├── split.json               # 从 split_template.json 复制填写
│   ├── config.yaml              # 实际训练配置
│   ├── per_case_metrics.csv     # 从 per_case_metrics_template.csv 复制填写
│   ├── per_epoch_metrics.csv    # 训练/验证曲线
│   ├── eval.py                  # 实际用的评估脚本
│   ├── eval_config.json         # 口径声明
│   ├── README.md                # 如何复现“那个数字”
│   ├── fields/                  # Tier 2：3 例位移场
│   │   └── <case_id>/displacement_field.nii.gz
│   └── warped/                  # Tier 2：017–024 形变后标签
│       └── <case_id>/label_mr_warped.nii.gz
└── ...
```

## 填写要点

### run_manifest.json

- `data.train_cases` / `val_cases`：写**精确 case id**，不要写“随机 80%”。
- `pseudo_mr_009_016_in_train` / `_in_val`：必须明确 `true` / `false`。
- `used_test_images_025_032`：包括无标签图像做归一化/自监督/测试时适配。
- `pretrained_weights`：只允许通用预训练（如 ImageNet ResNet），写清来源。
- `reported.aggregation`：写清楚是「单折」「k 折均值」还是「最好一折」。

### per_case_metrics.csv

- `source_group`：`public`（001–008）/ `pseudo`（009–016）/ `self`（017–024）。
- `*_present`：该器官在 **CT GT** 中是否存在（0/1）。
- `*_voxels`：CT GT 中该器官体素数。
- `*_dsc`：按官方口径算的器官 Dice；空器官填 1.0。
- `case_dsc`：三器官算术平均。

### split.json

- 每个 fold 的 `train` / `val` 必须列出全部 case id。
- `model_selection` 写 `val` 还是 `train`（早停用哪一折）。

## 体积控制

| 层级 | 内容 | 目标体积 |
|---|---|---|
| Tier 1 | manifest / split / csv / eval.py / config | < 20MB |
| Tier 2 | 8 例 warped label + 3 例位移场 | < 200MB |
| Tier 3 | 现场复跑，不传文件 | — |

> **不要传**原始 24 例 NIfTI、全部 checkpoint、训练中间可视化。
> GT 标签导师手上有，学生只需要传「输出 + split + 评估脚本」。

## 独立复算

导师侧用官方 24 例标签 + `ctmr.eval.evaluate` 重算：

```bash
python -m ctmr.eval.evaluate \
  --pred-root audit/<student>_<scheme>/fields \
  --data-root audit_data/paired \
  --cases 017 018 019 020 021 022 023 024 \
  --output-csv audit/<student>_<scheme>/recomputed.csv
```

逐例差值 > 0.01 → 先查口径，不要先改模型。
