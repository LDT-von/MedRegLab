# 自检报告（SELF CHECK REPORT）

| 项 | 内容 |
|---|---|
| 学生 |  |
| 方案 |  |
| run_id |  |
| 日期 |  |
| 协议版本 | v1 |
| 审计人 | AI Agent |

---

## 1. 执行摘要（≤ 5 行）

> 只写有证据的结论；没有证据的写 UNVERIFIED。

---

## 2. 数字对照

| claim | 来源（文件/命令） | verified | diff | verdict |
|---|---|---|---|---|
| 0.791 |  |  |  | PASS / FAIL / UNVERIFIED |
| 0.804 |  |  |  |  |
| 0.8093 |  |  |  |  |
| 0.82（已提交） |  |  |  |  |

---

## 3. 四轴结论

| 轴 | 结论 | 依据 |
|---|---|---|
| 可复现 | PASS / FAIL / UNVERIFIED |  |
| 干净（无泄漏/无混用） | PASS / FAIL / UNVERIFIED |  |
| 口径一致（官方） | PASS / FAIL / UNVERIFIED |  |
| 提交正确（zip ↔ ckpt） | PASS / FAIL / UNVERIFIED |  |

---

## 4. 问题清单（按严重度）

| 级别 | 问题 | 证据 | 影响 |
|---|---|---|---|
| P0 |  |  |  |
| P1 |  |  |  |
| P2 |  |  |  |

> P0：导致数字无效/违规；P1：影响可比性；P2：记录/规范问题。

---

## 5. 下次提交前必须修（≤ 5 条）

1. 
2. 
3. 
4. 
5. 

---

## 6. 下一个实验（只允许一个变量）

- **假设**：
- **改动**：
- **预期**：
- **判定标准**：
- **回滚条件**：

---

## 7. 证据索引

| 文件 | 说明 |
|---|---|
| `metrics/per_case_metrics.csv` | 逐例逐器官 DSC |
| `metrics/group_summary.csv` | 按 public / pseudo / self 分组 |
| `reports/discrepancies.csv` | 自报 vs 复算 |
| `reports/leakage_report.md` | 泄漏检查 |
| `reports/loss_audit.md` | loss 曲线判读 |
| `reports/drift_report.md` | 版本漂移 |
| `submission/submission_manifest.json` | zip ↔ checkpoint |
| `repro/checksums.sha256` | 文件校验 |

---

> 禁止在没有证据时写“达到 0.8”“应该没问题”。
> 不确定的结论一律标 `UNVERIFIED`，并写清缺什么。
